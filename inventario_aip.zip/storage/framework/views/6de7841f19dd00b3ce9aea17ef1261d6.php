

<?php $__env->startSection('title', 'Persona - Show'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>Persona <?php echo e($people->id); ?></h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <div class="card">
        <div class="card-header text-right">
            <a href="<?php echo e(route('personas.create')); ?>" class="btn btn-primary flex-wrap">
                <i class="fas fa-plus"></i>
                Nuevo
            </a>
            <a href="<?php echo e(route('personas.edit', $people)); ?>" class="btn btn-primary flex-wrap">
                <i class="fas fa-edit"></i>
                Editar
            </a>
            <a href="<?php echo e(route('personas.create')); ?>" class="btn btn-primary flex-wrap">
                <i class="fas fa-trash"></i>
                Eliminar
            </a>
        </div>


        <form>
            <div class="card-body">
                <div class="form-group">
                    <label>Id</label>
                    <input type="text" class="form-control" value="<?php echo e($people->id); ?>" disabled>
                </div>
                <div class="form-group">
                    <label>Nombre (s)</label>
                    <input type="text" class="form-control" value="<?php echo e($people->name); ?>" disabled>
                </div>
                <div class="form-group">
                    <label>Apellido (s)</label>
                    <input type="text" class="form-control" value="<?php echo e($people->last_name); ?>" disabled>
                </div>
                <div class="form-group">
                    <label>Puesto</label>
                    <input type="text" class="form-control" value="<?php echo e($people->position); ?>" disabled>
                </div>
                <div class="form-group">
                    <label>Teléfono de Oficina</label>
                    <input type="text" class="form-control" value="<?php echo e($people->tel1); ?>" disabled>
                </div>
                <div class="form-group">
                    <label>Teléfono Celular</label>
                    <input type="text" class="form-control" value="<?php echo e($people->tel2); ?>" disabled>
                </div>
                <div class="form-group">
                    <label>Email</label>
                    <input type="text" class="form-control" value="<?php echo e($people->mail); ?>" disabled>
                </div>
                <div class="form-group">
                    <label>Observaciones</label>
                    <textarea class="form-control" rows="3" disabled><?php echo e($people->obs); ?></textarea>
                </div>
                <div class="form-group">
                    <label>Fecha de Creación</label>
                    <input type="text" class="form-control" value="<?php echo e($people->created_at); ?>" disabled>
                </div>
                <div class="form-group">
                    <label>Fecha de Actualización</label>
                    <input type="text" class="form-control" value="<?php echo e($people->updated_at); ?>" disabled>
                </div>

            </div>

            <div class="card-footer">
                <!-- <button type="hidden" class="btn btn-primary">Guardar</button> -->
            </div>
        </form>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\inventario\resources\views/catalogos/personas/show.blade.php ENDPATH**/ ?>