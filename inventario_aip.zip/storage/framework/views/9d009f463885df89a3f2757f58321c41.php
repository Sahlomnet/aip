

<?php $__env->startSection('title', 'Software - Show'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>Software <?php echo e($license->id); ?></h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <div class="card">
        <div class="card-header text-right">
            <a href="<?php echo e(route('software.create')); ?>" class="btn btn-primary flex-wrap">
                <i class="fas fa-plus"></i>
                Nuevo
            </a>
            <a href="<?php echo e(route('software.edit', $license)); ?>" class="btn btn-primary flex-wrap">
                <i class="fas fa-edit"></i>
                Editar
            </a>
            <a href="<?php echo e(route('software.create')); ?>" class="btn btn-primary flex-wrap">
                <i class="fas fa-trash"></i>
                Eliminar
            </a>
        </div>


        <form>
            <div class="card-body">
                <div class="form-group">
                    <label>Id</label>
                    <input type="text" class="form-control" value="<?php echo e($license->id); ?>" disabled>
                </div>
                <div class="form-group">
                    <label>Descripción</label>
                    <input type="text" class="form-control" value="<?php echo e($license->des); ?>" disabled>
                </div>
                <div class="form-group">
                    <label>Serie</label>
                    <input type="text" class="form-control" value="<?php echo e($license->serial); ?>" disabled>
                </div>
                <div class="form-group">
                    <label>Vigencia</label>
                    <input type="text" class="form-control" value="<?php echo e($license->expiration_date); ?>" disabled>
                </div>
                <div class="form-group">
                    <label>Activo</label>
                    <input type="text" class="form-control" value="<?php echo e($consulta_activo); ?>" disabled>
                </div>
                <div class="form-group">
                    <label>Fabricante</label>
                    <input type="text" class="form-control" value="<?php echo e($consulta_manufacturer); ?>" disabled>
                </div>
                <div class="form-group">
                    <label>Observaciones</label>
                    <textarea name="obs" class="form-control" rows="5" disabled><?php echo e($license->obs); ?></textarea>
                </div>
                <div class="form-group">
                    <label>Fecha de Creación</label>
                    <input type="text" class="form-control" value="<?php echo e($license->created_at); ?>" disabled>
                </div>
                <div class="form-group">
                    <label>Fecha de Actualización</label>
                    <input type="text" class="form-control" value="<?php echo e($license->updated_at); ?>" disabled>
                </div>
            </div>

            <div class="card-footer">
                <!-- <button type="hidden" class="btn btn-primary">Guardar</button> -->
            </div>
        </form>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\inventario\resources\views/computo/software/show.blade.php ENDPATH**/ ?>