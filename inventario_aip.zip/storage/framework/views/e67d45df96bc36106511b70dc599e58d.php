

<?php $__env->startSection('title', 'Personas - Edit'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>Editar Persona</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <div class="card">
        <!-- <div class="card-header">
            <h3 class="card-title">Quick Example</h3>
        </div> -->

        
        <form action="<?php echo e(route('personas.update', $people)); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <?php echo method_field('put'); ?>
            <div class="card-body">
                <div class="form-group">
                    <label>Id</label>
                    <input type="text" name="id" class="form-control" value="<?php echo e($people->id); ?>" disabled>
                </div>
                <div class="form-group">
                    <label>Nombre (s)</label>
                    <input type="text" name="name" class="form-control" value="<?php echo e($people->name); ?>">
                </div>
                <div class="form-group">
                    <label>Apellido (s)</label>
                    <input type="text" name="last_name" class="form-control" value="<?php echo e($people->last_name); ?>">
                </div>
                <div class="form-group">
                    <label>Puesto</label>
                    <input type="text" name="position" class="form-control" value="<?php echo e($people->position); ?>">
                </div>
                <div class="form-group">
                    <label>Teléfono de Oficina</label>
                    <input type="text" name="tel1" class="form-control" value="<?php echo e($people->tel1); ?>">
                </div>
                <div class="form-group">
                    <label>Teléfono Celular</label>
                    <input type="text" name="tel2" class="form-control" value="<?php echo e($people->tel2); ?>">
                </div>
                <div class="form-group">
                    <label>Email</label>
                    <input type="text" name="mail" class="form-control" value="<?php echo e($people->mail); ?>">
                </div>
                <div class="form-group">
                    <label>Observaciones</label>
                    <textarea name="obs" class="form-control" rows="5"><?php echo e($people->obs); ?></textarea>
                </div>
                <div class="form-group">
                    <label>Fecha de Creación</label>
                    <input type="text" name="created_at" class="form-control" value="<?php echo e($people->created_at); ?>" disabled>
                </div>
                <div class="form-group">
                    <label>Fecha de Actualización</label>
                    <input type="text" name="updated_at" class="form-control" value="<?php echo e($people->updated_at); ?>" disabled>
                </div>

            </div>

            <div class="card-footer">
                <button type="submit" class="btn btn-primary">Guardar</button>
            </div>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\inventario\resources\views/catalogos/personas/edit.blade.php ENDPATH**/ ?>