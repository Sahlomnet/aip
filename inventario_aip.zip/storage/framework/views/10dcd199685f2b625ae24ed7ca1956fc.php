

<?php $__env->startSection('title', 'Direcciones - Show'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>Dirección <?php echo e($address->id); ?></h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <div class="card">
        <div class="card-header text-right">
            <a href="<?php echo e(route('direcciones.create')); ?>" class="btn btn-primary flex-wrap">
                <i class="fas fa-plus"></i>
                Nuevo
            </a>
            <a href="<?php echo e(route('direcciones.edit', $address)); ?>" class="btn btn-primary flex-wrap">
                <i class="fas fa-edit"></i>
                Editar
            </a>
            <a href="<?php echo e(route('direcciones.create')); ?>" class="btn btn-primary flex-wrap">
                <i class="fas fa-trash"></i>
                Eliminar
            </a>
        </div>


        <form>
            <div class="card-body">
            <div class="form-group">
                    <label>Id</label>
                    <input type="text" class="form-control" value="<?php echo e($address->id); ?>" disabled>
                </div>
                <div class="form-group">
                    <label>Calle</label>
                    <input type="text" class="form-control" value="<?php echo e($address->street); ?>" disabled>
                </div>
                <div class="form-group">
                    <label>Número Exterior</label>
                    <input type="text" class="form-control" value="<?php echo e($address->ext_number); ?>" disabled>
                </div>
                <div class="form-group">
                    <label>Número Interior</label>
                    <input type="text" class="form-control" value="<?php echo e($address->int_number); ?>" disabled>
                </div>
                <div class="form-group">
                    <label>Colonia</label>
                    <input type="text" class="form-control" value="<?php echo e($address->col); ?>" disabled>
                </div>
                <div class="form-group">
                    <label>Ciudad</label>
                    <input type="text" class="form-control" value="<?php echo e($address->city); ?>" disabled>
                </div>
                <div class="form-group">
                    <label>Municipio</label>
                    <input type="text" class="form-control" value="<?php echo e($address->mun); ?>" disabled>
                </div>
                <div class="form-group">
                    <label>Estado</label>
                    <input type="text" class="form-control" value="<?php echo e($address->state); ?>" disabled>
                </div>
                <div class="form-group">
                    <label>País</label>
                    <input type="text" class="form-control" value="<?php echo e($address->country); ?>" disabled>
                </div>
                <div class="form-group">
                    <label>Código Postal</label>
                    <input type="text" class="form-control" value="<?php echo e($address->zip_code); ?>" disabled>
                </div>
                <div class="form-group">
                    <label>Teléfono</label>
                    <input type="text" class="form-control" value="<?php echo e($address->tel); ?>" disabled>
                </div>
                <div class="form-group">
                    <label>Observaciones</label>
                    <textarea class="form-control" rows="3" disabled><?php echo e($address->obs); ?></textarea>
                </div>
                <div class="form-group">
                    <label>Fecha de Creación</label>
                    <input type="text" class="form-control" value="<?php echo e($address->created_at); ?>" disabled>
                </div>
                <div class="form-group">
                    <label>Fecha de Actualización</label>
                    <input type="text" class="form-control" value="<?php echo e($address->updated_at); ?>" disabled>
                </div>

            </div>

            <div class="card-footer">
                <!-- <button type="hidden" class="btn btn-primary">Guardar</button> -->
            </div>
        </form>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\inventario\resources\views/catalogos/direcciones/show.blade.php ENDPATH**/ ?>