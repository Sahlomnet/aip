

<?php $__env->startSection('title', 'Persona - Create'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>Nueva Persona</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <div class="card">
        <!-- <div class="card-header">
            <h3 class="card-title">Quick Example</h3>
        </div> -->

        
        <form action="<?php echo e(route('personas.store')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <div class="card-body">
            <div class="form-group">
                    <label>Nombre (s)</label>
                    <input type="text" name="name" class="form-control" placeholder="Nombre (s) ...">
                </div>
                <div class="form-group">
                    <label>Apellido (s)</label>
                    <input type="text" name="last_name" class="form-control" placeholder="Apellido (s) ...">
                </div>
                <div class="form-group">
                    <label>Puesto</label>
                    <input type="text" name="position" class="form-control" placeholder="Puesto ...">
                </div>
                <div class="form-group">
                    <label>Teléfono de Oficina</label>
                    <input type="text" name="tel1" class="form-control" placeholder="Teléfono de oficina ...">
                </div>
                <div class="form-group">
                    <label>Teléfono Celular</label>
                    <input type="text" name="tel2" class="form-control" placeholder="Teléfono Celular ...">
                </div>
                <div class="form-group">
                    <label>Email</label>
                    <input type="text" name="mail" class="form-control" placeholder="Email ...">
                </div>
                <div class="form-group">
                    <label>Observaciones</label>
                    <textarea name="obs" class="form-control" rows="5" placeholder="Observaciones ..."></textarea>
                </div>
            </div>

            <div class="card-footer">
                <button type="submit" class="btn btn-primary">Guardar</button>
            </div>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\inventario\resources\views/catalogos/personas/create.blade.php ENDPATH**/ ?>