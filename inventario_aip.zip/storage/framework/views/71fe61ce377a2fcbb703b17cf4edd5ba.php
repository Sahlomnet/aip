

<?php $__env->startSection('title', 'Activo - Show'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>Activo <?php echo e($asset->id); ?></h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <div class="card card-solid">

        <div class="card-header text-right">
            <a href="<?php echo e(route('activos.create')); ?>" class="btn btn-primary flex-wrap">
                <i class="fas fa-plus"></i>
                Nuevo
            </a>
            <a href="<?php echo e(route('activos.edit', $asset)); ?>" class="btn btn-primary flex-wrap">
                <i class="fas fa-edit"></i>
                Editar
            </a>
            <a href="<?php echo e(route('activos.create')); ?>" class="btn btn-primary flex-wrap">
                <i class="fas fa-trash"></i>
                Eliminar
            </a>
        </div>

        <div class="card-body">
            <div class="row">
                <div class="col-12 col-sm-6">
                    <h3 class="d-inline-block d-sm-none"><?php echo e($asset->cod); ?></h3>
                    <div class="col-12">
                        <img src="<?php echo e(asset('img/assets/'.$asset->cod.'.png')); ?>" class="product-image" alt="Product Image">
                    </div>
                    <!-- <div class="col-12 product-image-thumbs">
                        <div class="product-image-thumb active"><img src="../../dist/img/prod-1.jpg" alt="Product Image"></div>
                        <div class="product-image-thumb" ><img src="../../dist/img/prod-2.jpg" alt="Product Image"></div>
                        <div class="product-image-thumb" ><img src="../../dist/img/prod-3.jpg" alt="Product Image"></div>
                        <div class="product-image-thumb" ><img src="../../dist/img/prod-4.jpg" alt="Product Image"></div>
                        <div class="product-image-thumb" ><img src="../../dist/img/prod-5.jpg" alt="Product Image"></div>
                    </div> -->
                </div>
                <div class="col-12 col-sm-6">
                    <h3 class="my-3 text-center">Código: <?php echo e($asset->cod); ?></h3>

                    <div class="table-responsive">
                        <table class="table">
                            <tbody>
                                <tr><th style="width:40%">Descripción:</th><td><?php echo e($asset->des); ?></td></tr>
                                <tr><th>Modelo:</th><td><?php echo e($asset->model); ?></td></tr>
                                <tr><th>Fabricante:</th><td><?php echo e($asset->manufacturer->des ?? ''); ?></td></tr>
                                <tr><th>Categoría:</th><td><?php echo e($asset->category->des ?? ''); ?></td></tr>
                                <tr><th>Estatus:</th><td><?php echo e($asset->status->des ?? ''); ?></td></tr>
                                <tr><th>Serie:</th><td><?php echo e($asset->serial); ?></td></tr>
                                <tr><th style="width:40%">Locación:</th><td><?php echo e($asset->placement->location->name ?? ''); ?></td></tr>
                                <tr><th>Ubicación:</th><td><?php echo e($asset->placement->name ?? ''); ?></td></tr>
                                <tr><th>Responsable:</th><td><?php echo e($asset->placement->people->name ?? ''); ?><?php echo e(' '); ?><?php echo e($asset->placement->people->last_name ?? ''); ?></td></tr>
                                <tr><th>Uso:</th><td><?php echo e($asset->usage->des ?? ''); ?></td></tr>
                                <tr><th>Observaciones:</th><td><?php echo e($asset->obs); ?></td></tr>
                            </tbody>
                        </table>
                    </div>

                    <!-- <h4>Available Colors</h4>
                    <div class="btn-group btn-group-toggle" data-toggle="buttons">
                        <label class="btn btn-default text-center active">
                            <input type="radio" name="color_option" id="color_option_a1" autocomplete="off" checked>
                            Green
                            <br>
                            <i class="fas fa-circle fa-2x text-green"></i>
                        </label>
                        <label class="btn btn-default text-center">
                            <input type="radio" name="color_option" id="color_option_a2" autocomplete="off">
                            Blue
                            <br>
                            <i class="fas fa-circle fa-2x text-blue"></i>
                        </label>
                        <label class="btn btn-default text-center">
                            <input type="radio" name="color_option" id="color_option_a3" autocomplete="off">
                            Purple
                            <br>
                            <i class="fas fa-circle fa-2x text-purple"></i>
                        </label>
                        <label class="btn btn-default text-center">
                            <input type="radio" name="color_option" id="color_option_a4" autocomplete="off">
                            Red
                            <br>
                            <i class="fas fa-circle fa-2x text-red"></i>
                        </label>
                        <label class="btn btn-default text-center">
                            <input type="radio" name="color_option" id="color_option_a5" autocomplete="off">
                            Orange
                            <br>
                            <i class="fas fa-circle fa-2x text-orange"></i>
                        </label>
                    </div>

                    <h4 class="mt-3">Size <small>Please select one</small></h4>
                    <div class="btn-group btn-group-toggle" data-toggle="buttons">
                        <label class="btn btn-default text-center">
                            <input type="radio" name="color_option" id="color_option_b1" autocomplete="off">
                            <span class="text-xl">S</span>
                            <br>
                            Small
                        </label>
                        <label class="btn btn-default text-center">
                            <input type="radio" name="color_option" id="color_option_b2" autocomplete="off">
                            <span class="text-xl">M</span>
                            <br>
                            Medium
                        </label>
                        <label class="btn btn-default text-center">
                            <input type="radio" name="color_option" id="color_option_b3" autocomplete="off">
                            <span class="text-xl">L</span>
                            <br>
                            Large
                        </label>
                        <label class="btn btn-default text-center">
                            <input type="radio" name="color_option" id="color_option_b4" autocomplete="off">
                            <span class="text-xl">XL</span>
                            <br>
                            Xtra-Large
                        </label>
                    </div>

                    <div class="bg-gray py-2 px-3 mt-4">
                        <h2 class="mb-0">
                        $80.00
                        </h2>
                        <h4 class="mt-0">
                        <small>Ex Tax: $80.00 </small>
                        </h4>
                    </div>

                    <div class="mt-4">
                        <div class="btn btn-primary btn-lg btn-flat">
                            <i class="fas fa-cart-plus fa-lg mr-2"></i>
                            Add to Cart
                        </div>

                        <div class="btn btn-default btn-lg btn-flat">
                            <i class="fas fa-heart fa-lg mr-2"></i>
                            Add to Wishlist
                        </div>
                    </div>

                    <div class="mt-4 product-share">
                        <a href="#" class="text-gray">
                        <i class="fab fa-facebook-square fa-2x"></i>
                        </a>
                        <a href="#" class="text-gray">
                        <i class="fab fa-twitter-square fa-2x"></i>
                        </a>
                        <a href="#" class="text-gray">
                        <i class="fas fa-envelope-square fa-2x"></i>
                        </a>
                        <a href="#" class="text-gray">
                        <i class="fas fa-rss-square fa-2x"></i>
                        </a>
                    </div> -->

                </div>
            </div>





            <div class="row">
                <div class="col-12" id="accordion">
                    <div class="card card-primary card-tabs">
                        <div class="card-header p-0 pt-1">
                            <ul class="nav nav-tabs" id="asset-tab" role="tablist">
                                <li class="nav-item">
                                    <a class="nav-link active" id="asset-features-tab" data-toggle="pill" href="#features-tab" role="tab" aria-controls="features-tab" aria-selected="false">Características</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" id="asset-maintenance-tab" data-toggle="pill" href="#maintenance-tab" role="tab" aria-controls="maintenance-tab" aria-selected="false">Mantenimiento</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" id="asset-purchase-tab" data-toggle="pill" href="#purchase-tab" role="tab" aria-controls="purchase-tab" aria-selected="false">Compra</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" id="asset-movements-tab" data-toggle="pill" href="#movements-tab" role="tab" aria-controls="movements-tab" aria-selected="false">Movimientos</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" id="asset-qr-tab" data-toggle="pill" href="#qr-tab" role="tab" aria-controls="qr-tab" aria-selected="false">QR</a>
                                </li>
                            </ul>
                        </div>
                        <div class="card-body">
                            <div class="tab-content" id="tabContent">
                                <div class="tab-pane fade show active" id="features-tab" role="tabpanel" aria-labelledby="asset-features-tab">
                                    <?php if(!$processors->isEmpty()): ?>
                                        <div class="card">
                                            <a class="d-block w-100" data-toggle="collapse" href="#collapseProcessors">
                                                <div class="card-header">
                                                    <h4 class="card-title w-100">
                                                        Procesador
                                                    </h4>
                                                </div>
                                            </a>
                                            <div id="collapseProcessors" class="collapse show" data-parent="#accordion">
                                                <div class="card-body">
                                                    <table class="table table-striped table-bordered shadow-lg mt-4" style="width:100%">
                                                        <thead class="bg-secondary text-white">
                                                            <tr>
                                                                <th class="text-center">Id</th>
                                                                <th class="text-center">Fabricante</th>
                                                                <th class="text-center">Descripción</th>
                                                                <th class="text-center">Frecuencia</th>
                                                                <th class="text-center">Observaciones</th>
                                                            </tr>
                                                        </thead>
                                                        <tbody>
                                                            <?php $__currentLoopData = $processors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $processor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <tr>
                                                                    <td  class="text-center list-link"><a href="<?php echo e(route('procesador.show', $processor->id)); ?>"><?php echo e($processor->id ?? ''); ?></a></td>
                                                                    <td  class="text-center list-link"><a href="<?php echo e(route('procesador.show', $processor->id)); ?>"><?php echo e($processor->manufacturer->des ?? ''); ?></a></td>
                                                                    <td  class="text-center list-link"><a href="<?php echo e(route('procesador.show', $processor->id)); ?>"><?php echo e($processor->des ?? ''); ?></a></td>
                                                                    <td  class="text-center list-link"><a href="<?php echo e(route('procesador.show', $processor->id)); ?>"><?php echo e($processor->frequency ?? ''); ?></a></td>
                                                                    <td  class="text-center list-link"><a href="<?php echo e(route('procesador.show', $processor->id)); ?>"><?php echo e($processor->obs ?? ''); ?></a></td>
                                                                </tr>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        </tbody>
                                                    </table>    
                                                </div>
                                            </div>
                                        </div>
                                    <?php endif; ?>
                                    <?php if(!$rams->isEmpty()): ?>
                                        <div class="card">
                                            <a class="d-block w-100" data-toggle="collapse" href="#collapseRam">
                                                <div class="card-header">
                                                    <h4 class="card-title w-100">
                                                        Ram
                                                    </h4>
                                                </div>
                                            </a>
                                            <div id="collapseRam" class="collapse show" data-parent="#accordion">
                                                <div class="card-body">
                                                    <table class="table table-striped table-bordered shadow-lg mt-4" style="width:100%">
                                                        <thead class="bg-secondary text-white">
                                                            <tr>
                                                                <th class="text-center">Id</th>
                                                                <th class="text-center">Fabricante</th>
                                                                <th class="text-center">Interfaz</th>
                                                                <th class="text-center">Velocidad</th>
                                                                <th class="text-center">Capacidad</th>
                                                                <th class="text-center">Observaciones</th>
                                                            </tr>
                                                        </thead>
                                                        <tbody>
                                                            <?php $__currentLoopData = $rams; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ram): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <tr>
                                                                    <td  class="text-center list-link"><a href="<?php echo e(route('ram.show', $ram->id)); ?>"><?php echo e($ram->id ?? ''); ?></a></td>
                                                                    <td  class="text-center list-link"><a href="<?php echo e(route('ram.show', $ram->id)); ?>"><?php echo e($ram->manufacturer->des ?? ''); ?></a></td>
                                                                    <td  class="text-center list-link"><a href="<?php echo e(route('ram.show', $ram->id)); ?>"><?php echo e($ram->interface ?? ''); ?></a></td>
                                                                    <td  class="text-center list-link"><a href="<?php echo e(route('ram.show', $ram->id)); ?>"><?php echo e($ram->speed ?? ''); ?></a></td>
                                                                    <td  class="text-center list-link"><a href="<?php echo e(route('ram.show', $ram->id)); ?>"><?php echo e($ram->capacity ?? ''); ?></a></td>
                                                                    <td  class="text-center list-link"><a href="<?php echo e(route('ram.show', $ram->id)); ?>"><?php echo e($ram->obs ?? ''); ?></a></td>
                                                                </tr>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        </tbody>
                                                    </table>    
                                                </div>
                                            </div>
                                        </div>
                                    <?php endif; ?>
                                    <?php if(!$storages->isEmpty()): ?>
                                        <div class="card">
                                            <a class="d-block w-100" data-toggle="collapse" href="#collapseStorage">
                                                <div class="card-header">
                                                    <h4 class="card-title w-100">
                                                        Almacenamiento
                                                    </h4>
                                                </div>
                                            </a>
                                            <div id="collapseStorage" class="collapse show" data-parent="#accordion">
                                                <div class="card-body">
                                                    <table class="table table-striped table-bordered shadow-lg mt-4" style="width:100%">
                                                        <thead class="bg-secondary text-white">
                                                            <tr>
                                                                <th class="text-center">Id</th>
                                                                <th class="text-center">Fabricante</th>
                                                                <th class="text-center">Tipo</th>
                                                                <th class="text-center">Interfaz</th>
                                                                <th class="text-center">Capacidad</th>
                                                                <th class="text-center">Observaciones</th>
                                                            </tr>
                                                        </thead>
                                                        <tbody>
                                                            <?php $__currentLoopData = $storages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $storage): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <tr>
                                                                    <td  class="text-center list-link"><a href="<?php echo e(route('almacenamiento.show', $storage->id)); ?>"><?php echo e($storage->id ?? ''); ?></a></td>
                                                                    <td  class="text-center list-link"><a href="<?php echo e(route('almacenamiento.show', $storage->id)); ?>"><?php echo e($storage->manufacturer->des ?? ''); ?></a></td>
                                                                    <td  class="text-center list-link"><a href="<?php echo e(route('almacenamiento.show', $storage->id)); ?>"><?php echo e($storage->type ?? ''); ?></a></td>
                                                                    <td  class="text-center list-link"><a href="<?php echo e(route('almacenamiento.show', $storage->id)); ?>"><?php echo e($storage->interface ?? ''); ?></a></td>
                                                                    <td  class="text-center list-link"><a href="<?php echo e(route('almacenamiento.show', $storage->id)); ?>"><?php echo e($storage->capacity ?? ''); ?></a></td>
                                                                    <td  class="text-center list-link"><a href="<?php echo e(route('almacenamiento.show', $storage->id)); ?>"><?php echo e($storage->obs ?? ''); ?></a></td>
                                                                </tr>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        </tbody>
                                                    </table>    
                                                </div>
                                            </div>
                                        </div>
                                    <?php endif; ?>
                                    <?php if(!$networks->isEmpty()): ?>
                                        <div class="card">
                                            <a class="d-block w-100" data-toggle="collapse" href="#collapseNetwork">
                                                <div class="card-header">
                                                    <h4 class="card-title w-100">
                                                        Red
                                                    </h4>
                                                </div>
                                            </a>
                                            <div id="collapseNetwork" class="collapse show" data-parent="#accordion">
                                                <div class="card-body">
                                                    <table class="table table-striped table-bordered shadow-lg mt-4" style="width:100%">
                                                        <thead class="bg-secondary text-white">
                                                            <tr>
                                                                <th class="text-center">Id</th>
                                                                <th class="text-center">Fabricante</th>
                                                                <th class="text-center">Tipo</th>
                                                                <th class="text-center">Dirección MAC</th>
                                                                <th class="text-center">Dirección IP</th>
                                                                <th class="text-center">Observaciones</th>
                                                            </tr>
                                                        </thead>
                                                        <tbody>
                                                            <?php $__currentLoopData = $networks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $network): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <tr>
                                                                    <td  class="text-center list-link"><a href="<?php echo e(route('red.show', $network->id)); ?>"><?php echo e($network->id ?? ''); ?></a></td>
                                                                    <td  class="text-center list-link"><a href="<?php echo e(route('red.show', $network->id)); ?>"><?php echo e($network->manufacturer->des ?? ''); ?></a></td>
                                                                    <td  class="text-center list-link"><a href="<?php echo e(route('red.show', $network->id)); ?>"><?php echo e($network->type ?? ''); ?></a></td>
                                                                    <td  class="text-center list-link"><a href="<?php echo e(route('red.show', $network->id)); ?>"><?php echo e($network->mac ?? ''); ?></a></td>
                                                                    <td  class="text-center list-link"><a href="<?php echo e(route('red.show', $network->id)); ?>"><?php echo e($network->ip ?? ''); ?></a></td>
                                                                    <td  class="text-center list-link"><a href="<?php echo e(route('red.show', $network->id)); ?>"><?php echo e($network->obs ?? ''); ?></a></td>
                                                                </tr>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        </tbody>
                                                    </table>    
                                                </div>
                                            </div>
                                        </div>
                                    <?php endif; ?>
                                    <?php if(!$licenses->isEmpty()): ?>
                                        <div class="card">
                                            <a class="d-block w-100" data-toggle="collapse" href="#collapseSoftware">
                                                <div class="card-header">
                                                    <h4 class="card-title w-100">
                                                        Software
                                                    </h4>
                                                </div>
                                            </a>
                                            <div id="collapseSoftware" class="collapse show" data-parent="#accordion">
                                                <div class="card-body">
                                                    <table class="table table-striped table-bordered shadow-lg mt-4" style="width:100%">
                                                        <thead class="bg-secondary text-white">
                                                            <tr>
                                                                <th class="text-center">Id</th>
                                                                <th class="text-center">Fabricante</th>
                                                                <th class="text-center">Descripción</th>
                                                                <th class="text-center">Serie</th>
                                                                <th class="text-center">Vigencia</th>
                                                                <th class="text-center">Observaciones</th>
                                                            </tr>
                                                        </thead>
                                                        <tbody>
                                                            <?php $__currentLoopData = $licenses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $license): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <tr>
                                                                    <td  class="text-center list-link"><a href="<?php echo e(route('software.show', $license->id)); ?>"><?php echo e($license->id ?? ''); ?></a></td>
                                                                    <td  class="text-center list-link"><a href="<?php echo e(route('software.show', $license->id)); ?>"><?php echo e($license->manufacturer->des ?? ''); ?></a></td>
                                                                    <td  class="text-center list-link"><a href="<?php echo e(route('software.show', $license->id)); ?>"><?php echo e($license->des ?? ''); ?></a></td>
                                                                    <td  class="text-center list-link"><a href="<?php echo e(route('software.show', $license->id)); ?>"><?php echo e($license->serial ?? ''); ?></a></td>
                                                                    <td  class="text-center list-link"><a href="<?php echo e(route('software.show', $license->id)); ?>"><?php echo e($license->expiration_date ?? ''); ?></a></td>
                                                                    <td  class="text-center list-link"><a href="<?php echo e(route('software.show', $license->id)); ?>"><?php echo e($license->obs ?? ''); ?></a></td>
                                                                </tr>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        </tbody>
                                                    </table>    
                                                </div>
                                            </div>
                                        </div>
                                    <?php endif; ?>
                                    <?php if(!$environments->isEmpty()): ?>
                                        <div class="card">
                                            <a class="d-block w-100" data-toggle="collapse" href="#collapseEnvironment">
                                                <div class="card-header">
                                                    <h4 class="card-title w-100">
                                                        Entorno
                                                    </h4>
                                                </div>
                                            </a>
                                            <div id="collapseEnvironment" class="collapse" data-parent="#accordion">
                                                <div class="card-body">
                                                    <table class="table table-striped table-bordered shadow-lg mt-4" style="width:100%">
                                                        <thead class="bg-secondary text-white">
                                                            <tr>
                                                                <th class="text-center">Id</th>
                                                                <th class="text-center">Nombre</th>
                                                                <th class="text-center">Grupo / Dominio</th>
                                                                <th class="text-center">Usuario</th>
                                                                <th class="text-center">Contraseña</th>
                                                                <th class="text-center">Puerto RDP</th>
                                                                <th class="text-center">Observaciones</th>
                                                            </tr>
                                                        </thead>
                                                        <tbody>
                                                            <?php $__currentLoopData = $environments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $environment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <tr>
                                                                    <td  class="text-center list-link"><a href="<?php echo e(route('entorno.show', $environment->id)); ?>"><?php echo e($environment->id ?? ''); ?></a></td>
                                                                    <td  class="text-center list-link"><a href="<?php echo e(route('entorno.show', $environment->id)); ?>"><?php echo e($environment->name ?? ''); ?></a></td>
                                                                    <td  class="text-center list-link"><a href="<?php echo e(route('entorno.show', $environment->id)); ?>"><?php echo e($environment->domain_group ?? ''); ?></a></td>
                                                                    <td  class="text-center list-link"><a href="<?php echo e(route('entorno.show', $environment->id)); ?>"><?php echo e($environment->user ?? ''); ?></a></td>
                                                                    <td  class="text-center list-link"><a href="<?php echo e(route('entorno.show', $environment->id)); ?>"><?php echo e($environment->password ?? ''); ?></a></td>
                                                                    <!-- <td  class="text-center list-link"><a href="<?php echo e(asset('rdp/'.$asset->cod.'.zip')); ?>" download></a></td> -->
                                                                    <td  class="text-center list-link"><a href="<?php echo e(route('entorno.show', $environment->id)); ?>" ><?php echo e($environment->rdp_port ?? ''); ?></a></td>
                                                                    <td  class="text-center list-link"><a href="<?php echo e(route('entorno.show', $environment->id)); ?>"><?php echo e($environment->obs ?? ''); ?></a></td>
                                                                </tr>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        </tbody>
                                                    </table>    
                                                </div>
                                            </div>
                                        </div>
                                    <?php endif; ?>
                                </div>
                                <div class="tab-pane fade" id="maintenance-tab" role="tabpanel" aria-labelledby="asset-maintenance-tab">
                                    <?php if(!$asset->last_maintenance_date || !$asset->frequency || !$asset->next_maintenance_date): ?>
                                        <div class="row">
                                            <div class="col-12 col-sm-6 mx-auto">
                                                <div class="table-responsive">
                                                    <table class="table">
                                                        <tbody>
                                                            <tr><th>Último Mantenimiento:</th><td><?php echo e($asset->last_maintenance_date); ?></td></tr>
                                                            <tr><th>Frecuencia de Mantenimiento:</th><td><?php echo e($asset->maintenance_frequency); ?> meses</td></tr>
                                                            <tr><th>Próximo Mantenimiento:</th><td><?php echo e($asset->next_maintenance_date); ?></td></tr>
                                                        </tbody>
                                                    </table>
                                                </div>
                                            </div>
                                        </div>
                                    <?php endif; ?>
                                </div>
                                <div class="tab-pane fade" id="purchase-tab" role="tabpanel" aria-labelledby="asset-purchase-tab">
                                    <?php if(!empty($asset->purchase_date) || !empty($asset->invoice) || !empty($asset->cost)): ?>
                                        <div class="row">
                                            <div class="col-12 col-sm-6 mx-auto">
                                                <div class="table-responsive">
                                                    <table class="table">
                                                        <tbody>
                                                            <tr><th>Fecha de Compra:</th><td><?php echo e($asset->purchase_date); ?></td></tr>
                                                            <tr><th>Factura:</th><td><a href="<?php echo e(asset($asset->invoice)); ?>" target="_blank" rel="noopener noreferrer"><?php echo e($asset->invoice); ?></a></td></tr>
                                                            <tr><th>Costo:</th><td><?php echo e($asset->cost); ?></td></tr>
                                                        </tbody>
                                                    </table>
                                                </div>
                                            </div>
                                        </div>
                                    <?php endif; ?>
                                </div>
                                <div class="tab-pane fade" id="movements-tab" role="tabpanel" aria-labelledby="asset-movements-tab">
                                    <table class="table table-striped table-bordered shadow-lg mt-4" style="width:100%">
                                        <thead class="bg-secondary text-white">
                                            <tr>
                                                <th class="text-center">Id</th>
                                                <th class="text-center">Descripción</th>
                                                <th class="text-center">Asignación</th>
                                                <th class="text-center">Ubicación</th>
                                                <th class="text-center">Activo</th>
                                                <th class="text-center">Observaciones</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <!-- var_dump () -->
                                            <?php $__currentLoopData = $movements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $movement): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr>
                                                    <td  class="text-center list-link"><a href="<?php echo e(route('movimientos.show', $movement->id)); ?>"><?php echo e($movement->id ?? ''); ?></a></td>
                                                    <td  class="text-center list-link"><a href="<?php echo e(route('movimientos.show', $movement->id)); ?>"><?php echo e($movement->des ?? ''); ?></a></td>
                                                    <td  class="text-center list-link"><a href="<?php echo e(route('movimientos.show', $movement->id)); ?>"><?php echo e($movement->movement_date ?? ''); ?></a></td>
                                                    <td  class="text-center list-link"><a href="<?php echo e(route('movimientos.show', $movement->id)); ?>"><?php echo e($movement->placement->name ?? ''); ?></a></td>
                                                    <td  class="text-center list-link"><a href="<?php echo e(route('movimientos.show', $movement->id)); ?>"><?php echo e($movement->asset->des ?? ''); ?></a></td>
                                                    <td  class="text-center list-link"><a href="<?php echo e(route('movimientos.show', $movement->id)); ?>"><?php echo e($movement->obs ?? ''); ?></a></td>
                                                </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                    </table>    
                                </div>
                                <div class="tab-pane fade" id="qr-tab" role="tabpanel" aria-labelledby="asset-qr-tab">
                                    <div id="qr_code" class="visible-print text-center">
                                        <?php echo QrCode::size(200)
                                            ->errorCorrection('H')
                                            ->generate(Request::url()); ?>

                                    </div>
                                    <p class="text-center mt-4">
                                        <a href="javascript:imprSelec('qr_code')" >Imprimir</a>
                                    </p>
                                </div>

                            </div>
                        </div>
                    </div>
                </div>
            </div>






        </div>
        <!-- /.card-body -->
    </div>



<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script language="Javascript">
        function imprSelec(name) {
        var ficha = document.getElementById(name);
        var ventimp = window.open(' ', 'popimpr');
        ventimp.document.write( ficha.innerHTML );
        ventimp.document.close();
        ventimp.print( );
        ventimp.close();
        }
	</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\inventario\resources\views/activos/show.blade.php ENDPATH**/ ?>