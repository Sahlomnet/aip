

<?php $__env->startSection('title', 'Ubicación - Create'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>Nueva Ubicación</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <div class="card">
        <!-- <div class="card-header">
            <h3 class="card-title">Quick Example</h3>
        </div> -->

        
        <form action="<?php echo e(route('ubicaciones.store')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <div class="card-body">
                <div class="form-group">
                    <label>Nombre</label>
                    <input type="text" name="name" class="form-control" placeholder="Nombre ...">
                </div>
                <div class="form-group">
                    <label>Locación</label>
                    <input type="text" name="id_location" class="form-control" placeholder="Locación ...">
                </div>
                <div class="form-group">
                    <label>Persona</label>
                    <input type="text" name="id_people" class="form-control" placeholder="Persona ...">
                </div>
                <div class="form-group">
                    <label>Observaciones</label>
                    <textarea name="obs" class="form-control" rows="5" placeholder="Observaciones ..."></textarea>
                </div>
            </div>

            <div class="card-footer">
                <button type="submit" class="btn btn-primary">Guardar</button>
            </div>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\inventario\resources\views/catalogos/ubicaciones/create.blade.php ENDPATH**/ ?>