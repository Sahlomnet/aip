

<?php $__env->startSection('title', 'Configuración'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>Configuración</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed pellentesque ex non est sagittis ornare. Suspendisse quis vehicula orci. Fusce rutrum lacus in libero ullamcorper, sit amet varius massa congue. Aliquam ac enim ut lectus rutrum accumsan. Suspendisse potenti. Donec tempus augue ut neque pulvinar, id lacinia neque dignissim. Donec bibendum, sem a vestibulum efficitur, arcu massa aliquet nisi, nec fringilla dolor ante vitae nulla. Maecenas venenatis diam et nisl consectetur, vitae mattis ligula pharetra. Vestibulum vulputate auctor ornare.</p>
    <p>Suspendisse semper tellus eget mattis porta. Nulla facilisi. Praesent vulputate hendrerit maximus. Praesent convallis nisl sed sollicitudin scelerisque. Maecenas velit quam, egestas ut aliquam eget, ullamcorper nec risus. Aenean elementum tincidunt orci, eu faucibus risus tristique vitae. Pellentesque sed odio molestie, dignissim orci ac, sollicitudin lorem. Aenean mattis mauris vitae felis dapibus ullamcorper. Integer facilisis tortor id ligula rutrum, eget viverra orci elementum. Sed posuere, ex id efficitur euismod, erat lacus malesuada leo, nec tristique velit odio tincidunt arcu. Donec eget massa id neque malesuada lacinia. Quisque tempus vestibulum nunc, at venenatis massa bibendum sit amet. Quisque elementum sed odio id euismod.</p>
    <p>Maecenas placerat vitae mi fermentum ultricies. Suspendisse cursus nulla quis euismod placerat. Aenean eu tristique nisl. Nullam venenatis quam a neque lacinia, a blandit odio porttitor. Vestibulum posuere augue sit amet justo viverra tincidunt. Nunc sollicitudin est ante, consequat mollis lectus tristique nec. Maecenas maximus rutrum pretium. Proin hendrerit mi vel nunc venenatis aliquet. Pellentesque luctus fermentum magna, ut sodales sapien venenatis sit amet. Integer mi ipsum, porta eu risus et, condimentum semper urna. Fusce lobortis dolor vel nunc ullamcorper fringilla.</p>
    <p>Integer vehicula convallis porta. Cras id efficitur dui. Donec euismod velit nec velit convallis efficitur. Phasellus facilisis ligula vehicula orci tempor, dictum feugiat sapien lacinia. In tincidunt elit sem, vel suscipit nunc luctus a. Sed dapibus orci ipsum, id congue justo venenatis at. Duis ex nisi, malesuada eget iaculis imperdiet, pellentesque vel ex. Mauris tempor, tortor ut fringilla volutpat, lacus metus pharetra diam, et sodales metus elit vel arcu. Maecenas cursus rutrum est, et tincidunt sapien dignissim ac. Aliquam a felis tincidunt, sollicitudin purus eget, ullamcorper orci. Phasellus risus nunc, fermentum et nisi vitae, malesuada malesuada ante. Aenean nec tincidunt eros, luctus convallis leo. In at odio condimentum, blandit nisi id, condimentum risus. Aliquam eget sagittis diam.</p>
    <p>Donec ornare odio augue, id blandit mauris dignissim a. Duis ornare maximus nulla quis tincidunt. Cras eget sapien a purus pretium sagittis. Sed vel nunc in diam faucibus efficitur quis sit amet ipsum. Nullam sagittis felis eu ex lobortis, at posuere lorem ullamcorper. Nam libero nibh, sagittis a tempor ut, aliquet et massa. Etiam vitae velit tellus.</p>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="/css/admin_custom.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script> console.log('Hi!'); </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\inventario\resources\views/configuracion.blade.php ENDPATH**/ ?>