

<?php $__env->startSection('title', 'Entorno - Show'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>Entorno <?php echo e($environment->id); ?></h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <div class="card">
        <div class="card-header text-right">
            <a href="<?php echo e(route('entorno.create')); ?>" class="btn btn-primary flex-wrap">
                <i class="fas fa-plus"></i>
                Nuevo
            </a>
            <a href="<?php echo e(route('entorno.edit', $environment)); ?>" class="btn btn-primary flex-wrap">
                <i class="fas fa-edit"></i>
                Editar
            </a>
            <a href="<?php echo e(route('entorno.create')); ?>" class="btn btn-primary flex-wrap">
                <i class="fas fa-trash"></i>
                Eliminar
            </a>
        </div>


        <form>
            <div class="card-body">
                <div class="form-group">
                    <label>Id</label>
                    <input type="text" class="form-control" value="<?php echo e($environment->id); ?>" disabled>
                </div>
                <div class="form-group">
                    <label>Nombre</label>
                    <input type="text" class="form-control" value="<?php echo e($environment->name); ?>" disabled>
                </div>
                <div class="form-group">
                    <label>Grupo / Dominio</label>
                    <input type="text" class="form-control" value="<?php echo e($environment->domain_group); ?>" disabled>
                </div>
                <div class="form-group">
                    <label>Usuario</label>
                    <input type="text" class="form-control" value="<?php echo e($environment->user); ?>" disabled>
                </div>
                <div class="form-group">
                    <label>Contraseña</label>
                    <input type="text" class="form-control" value="<?php echo e($environment->password); ?>" disabled>
                </div>
                <div class="form-group">
                    <label>Puerto RDP</label>
                    <input type="text" class="form-control" value="<?php echo e($environment->rdp_port); ?>" disabled>
                </div>
                <div class="form-group">
                    <label>Activo</label>
                    <input type="text" class="form-control" value="<?php echo e($consulta_activo); ?>" disabled>
                </div>
                <div class="form-group">
                    <label>Observaciones</label>
                    <textarea name="obs" class="form-control" rows="5" disabled><?php echo e($environment->obs); ?></textarea>
                </div>
                <div class="form-group">
                    <label>Fecha de Creación</label>
                    <input type="text" class="form-control" value="<?php echo e($environment->created_at); ?>" disabled>
                </div>
                <div class="form-group">
                    <label>Fecha de Actualización</label>
                    <input type="text" class="form-control" value="<?php echo e($environment->updated_at); ?>" disabled>
                </div>
            </div>

            <div class="card-footer">
                <!-- <button type="hidden" class="btn btn-primary">Guardar</button> -->
            </div>
        </form>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\inventario\resources\views/computo/entorno/show.blade.php ENDPATH**/ ?>