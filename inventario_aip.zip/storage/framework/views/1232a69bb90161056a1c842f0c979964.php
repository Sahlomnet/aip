

<?php $__env->startSection('title', 'Locación - Show'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>Locación <?php echo e($location->id); ?></h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <div class="card">
        <div class="card-header text-right">
            <a href="<?php echo e(route('locaciones.create')); ?>" class="btn btn-primary flex-wrap">
                <i class="fas fa-plus"></i>
                Nuevo
            </a>
            <a href="<?php echo e(route('locaciones.edit', $location)); ?>" class="btn btn-primary flex-wrap">
                <i class="fas fa-edit"></i>
                Editar
            </a>
            <a href="<?php echo e(route('locaciones.create')); ?>" class="btn btn-primary flex-wrap">
                <i class="fas fa-trash"></i>
                Eliminar
            </a>
        </div>
        <div class="card-body">
            <div class="row">
                <div class="col-12 col-sm-4 text-center">
                    <img src="<?php echo e(asset('img/locations/no_image_500.png')); ?>" alt="user-avatar" class="img-circle img-fluid" style="max-width: 300px;">
                </div>
                <div class="col-12 col-sm-8">
                    <h3 class="my-3"><?php echo e($location->name); ?></h3>
                    <div class="table-responsive">
                        <table class="table">
                            <tbody>
                                <tr><th style="width:25%">Dirección:</th><td>
                                    <?php echo e($location->street); ?>

                                    <?php echo e(" "); ?>

                                    <?php echo e($location->ext_number); ?>

                                    <?php if($location->int_number != null): ?>
                                        <?php echo e("Interior "); ?><?php echo e($location->int_number); ?> 
                                    <?php endif; ?>
                                    <br>
                                    <?php echo e("Col. "); ?><?php echo e($location->col); ?>

                                    <br>
                                    <?php if($location->city != null): ?>
                                        <?php echo e($location->city); ?><?php echo e(", "); ?>

                                    <?php endif; ?>
                                    <?php if($location->mun != null): ?>
                                        <?php echo e($location->mun); ?><?php echo e(", "); ?>

                                    <?php endif; ?>
                                    <?php if($location->state != null): ?>
                                        <?php echo e($location->state); ?><?php echo e(", "); ?>

                                    <?php endif; ?>
                                    <?php if($location->country != null): ?>
                                        <?php echo e($location->country); ?>

                                    <?php endif; ?>
                                    <?php if($location->zip_code != null): ?>
                                        <br>
                                        <?php echo e("CP. "); ?><?php echo e($location->zip_code); ?>

                                    <?php endif; ?>
                                    
                                </td></tr>
                                <tr><th>Teléfono:</th><td><?php echo e($location->tel); ?></td></tr>
                                <tr><th>IP Pública:</th><td><?php echo e($location->public_ip); ?></td></tr>
                                <tr><th>DNS Público:</th><td><?php echo e($location->public_dns); ?></td></tr>
                                <tr><th>Observaciones:</th><td><?php echo e($location->obs); ?></td></tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-12" id="accordion">
                    <div class="card card-primary card-tabs">
                        <div class="card-header p-0 pt-1">
                            <ul class="nav nav-tabs" id="locations-tab" role="tablist">
                                <li class="nav-item">
                                    <a class="nav-link active" id="locations-assets-tab" data-toggle="pill" href="#assets-tab" role="tab" aria-controls="assets-tab" aria-selected="false">Activos</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" id="locations-placements-tab" data-toggle="pill" href="#placements-tab" role="tab" aria-controls="placements-tab" aria-selected="false">Ubicaciones</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" id="locations-people-tab" data-toggle="pill" href="#people-tab" role="tab" aria-controls="people-tab" aria-selected="false">Personas</a>
                                </li>
                            </ul>
                        </div>
                        <div class="card-body">
                            <div class="tab-content" id="tabContent">
                                <div class="tab-pane fade show active" id="assets-tab" role="tabpanel" aria-labelledby="locations-assets-tab">
                                    <table class="table table-striped table-bordered shadow-lg mt-4" style="width:100%">
                                        <thead class="bg-secondary text-white">
                                            <tr>
                                                <th class="text-center">Id</th>
                                                <th class="text-center">Código</th>
                                                <th class="text-center">Descripción</th>
                                                <th class="text-center">Modelo</th>
                                                <th class="text-center">Serie</th>
                                                <th class="text-center">Ubicación</th>
                                                <th class="text-center">Observaciones</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <!-- var_dump () -->
                                            <?php $__currentLoopData = $all_assets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $asset): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr>
                                                    <td  class="text-center list-link"><a href="<?php echo e(route('activos.show', $asset->id)); ?>"><?php echo e($asset->id ?? ''); ?></a></td>
                                                    <td  class="text-center list-link"><a href="<?php echo e(route('activos.show', $asset->id)); ?>"><?php echo e($asset->cod ?? ''); ?></a></td>
                                                    <td  class="text-center list-link"><a href="<?php echo e(route('activos.show', $asset->id)); ?>"><?php echo e($asset->des ?? ''); ?></a></td>
                                                    <td  class="text-center list-link"><a href="<?php echo e(route('activos.show', $asset->id)); ?>"><?php echo e($asset->model ?? ''); ?></a></td>
                                                    <td  class="text-center list-link"><a href="<?php echo e(route('activos.show', $asset->id)); ?>"><?php echo e($asset->serial ?? ''); ?></a></td>
                                                    <td  class="text-center list-link"><a href="<?php echo e(route('activos.show', $asset->id)); ?>"><?php echo e($asset->placement->name ?? ''); ?></a></td>
                                                    <td  class="text-center list-link"><a href="<?php echo e(route('activos.show', $asset->id)); ?>"><?php echo e($asset->obs ?? ''); ?></a></td>
                                                </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                    </table>    
                                </div>
                                <div class="tab-pane fade" id="placements-tab" role="tabpanel" aria-labelledby="locations-placements-tab">
                                    <table class="table table-striped table-bordered shadow-lg mt-4" style="width:100%">
                                        <thead class="bg-secondary text-white">
                                            <tr>
                                                <th class="text-center">Id</th>
                                                <th class="text-center">Nombre</th>
                                                <th class="text-center">Locación</th>
                                                <th class="text-center">Persona</th>
                                                <th class="text-center">Observaciones</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php $__currentLoopData = $placements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $placement): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr>
                                                    <td  class="text-center list-link"><a href="<?php echo e(route('ubicaciones.show', $placement->id)); ?>"><?php echo e($placement->id ?? ''); ?></a></td>
                                                    <td  class="text-center list-link"><a href="<?php echo e(route('ubicaciones.show', $placement->id)); ?>"><?php echo e($placement->name ?? ''); ?></a></td>
                                                    <td  class="text-center list-link"><a href="<?php echo e(route('ubicaciones.show', $placement->id)); ?>"><?php echo e($placement->location->name ?? ''); ?></a></td>
                                                    <td  class="text-center list-link"><a href="<?php echo e(route('ubicaciones.show', $placement->id)); ?>"><?php echo e($placement->people->name ?? ''); ?><?php echo e(' '); ?><?php echo e($placement->people->last_name ?? ''); ?></a></td>
                                                    <td  class="text-center list-link"><a href="<?php echo e(route('ubicaciones.show', $placement->id)); ?>"><?php echo e($placement->obs ?? ''); ?></a></td>
                                                </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                    </table>    
                                </div>
                                <div class="tab-pane fade" id="people-tab" role="tabpanel" aria-labelledby="locations-people-tab">
                                    <table class="table table-striped table-bordered shadow-lg mt-4" style="width:100%">
                                        <thead class="bg-secondary text-white">
                                            <tr>
                                                <th class="text-center">Id</th>
                                                <th class="text-center">Nombre</th>
                                                <th class="text-center">Apellido</th>
                                                <th class="text-center">Puesto</th>
                                                <th class="text-center">Teléfono</th>
                                                <th class="text-center">Email</th>
                                                <th class="text-center">Observaciones</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php $__currentLoopData = $all_persons; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $person): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr>
                                                    <td  class="text-center list-link"><a href="<?php echo e(route('personas.show', $person->id)); ?>"><?php echo e($person->id ?? ''); ?></a></td>
                                                    <td  class="text-center list-link"><a href="<?php echo e(route('personas.show', $person->id)); ?>"><?php echo e($person->name ?? ''); ?></a></td>
                                                    <td  class="text-center list-link"><a href="<?php echo e(route('personas.show', $person->id)); ?>"><?php echo e($person->last_name ?? ''); ?></a></td>
                                                    <td  class="text-center list-link"><a href="<?php echo e(route('personas.show', $person->id)); ?>"><?php echo e($person->position ?? ''); ?></a></td>
                                                    <td  class="text-center list-link"><a href="<?php echo e(route('personas.show', $person->id)); ?>"><?php echo e($person->tel ?? ''); ?></a></td>
                                                    <td  class="text-center list-link"><a href="<?php echo e(route('personas.show', $person->id)); ?>"><?php echo e($person->mail ?? ''); ?></a></td>
                                                    <td  class="text-center list-link"><a href="<?php echo e(route('personas.show', $person->id)); ?>"><?php echo e($person->obs ?? ''); ?></a></td>
                                                </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                    </table>
                                </div>


                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\inventario\resources\views/empresa/locaciones/show.blade.php ENDPATH**/ ?>