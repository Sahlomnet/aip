

<?php $__env->startSection('title', 'Almacenamiento - Edit'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>Editar Almacenamiento</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <div class="card">
        <!-- <div class="card-header">
            <h3 class="card-title">Quick Example</h3>
        </div> -->

        
        <form action="<?php echo e(route('almacenamiento.update', $storage)); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <?php echo method_field('put'); ?>
            <div class="card-body">
                <div class="form-group">
                    <label>Id</label>
                    <input type="text" name="id" class="form-control" value="<?php echo e($storage->id); ?>" disabled>
                </div>

                <div class="form-group">
                    <label>Tipo</label>
                    <input type="text" name="type" class="form-control" value="<?php echo e($storage->type); ?>">
                </div>
                <div class="form-group">
                    <label>Interfaz</label>
                    <input type="text" name="interface" class="form-control" value="<?php echo e($storage->interface); ?>">
                </div>
                <div class="form-group">
                    <label>Capacidad</label>
                    <input type="text" name="capacity" class="form-control" value="<?php echo e($storage->capacity); ?>">
                </div>
                <div class="form-group">
                    <label>Activo / <?php echo e($storage->id_asset); ?></label>
                    <select class="form-control" name="id_asset">
                        <option value=""></option>
                        <?php $__currentLoopData = $assets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $asset): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($asset->id === $storage->id_asset): ?>
                        <option value="<?php echo e($asset->id); ?>" selected><?php echo e($asset->cod); ?></option>
                        <?php else: ?>
                        <option value="<?php echo e($asset->id); ?>"><?php echo e($asset->cod); ?></option>
                        <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div class="form-group">
                    <label>Fabricante / <?php echo e($storage->id_manufacturer); ?></label>
                    <select class="form-control" name="id_manufacturer">
                        <?php $__currentLoopData = $manufacturers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $manufacturer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($manufacturer->id === $storage->id_manufacturer): ?>
                                <option value="<?php echo e($manufacturer->id); ?>" selected><?php echo e($manufacturer->des); ?></option>
                            <?php else: ?>
                                <option value="<?php echo e($manufacturer->id); ?>"><?php echo e($manufacturer->des); ?></option>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div class="form-group">
                    <label>Observaciones</label>
                    <textarea name="obs" class="form-control" rows="5"><?php echo e($storage->obs); ?></textarea>
                </div>


                <div class="form-group">
                    <label>Fecha de Creación</label>
                    <input type="text" name="created_at" class="form-control" value="<?php echo e($storage->created_at); ?>" disabled>
                </div>
                <div class="form-group">
                    <label>Fecha de Actualización</label>
                    <input type="text" name="updated_at" class="form-control" value="<?php echo e($storage->updated_at); ?>" disabled>
                </div>

            </div>

            <div class="card-footer">
                <button type="submit" class="btn btn-primary">Guardar</button>
            </div>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('plugins/tempusdominus-bootstrap-4/css/tempusdominus-bootstrap-4.min.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <!-- jQuery -->
    <script type="text/javascript"  src="<?php echo e(asset('plugins/jquery/jquery-3.5.1.js')); ?>"></script>
    <!-- InputMask -->
    <script type="text/javascript" src="<?php echo e(asset('plugins/moment/moment.min.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('plugins/inputmask/jquery.inputmask.min.js')); ?>"></script>
    <!-- Tempusdominus Bootstrap 4 -->
    <script type="text/javascript" src="<?php echo e(asset('plugins/tempusdominus-bootstrap-4/js/tempusdominus-bootstrap-4.min.js')); ?>"></script>
    <!-- Custom File Input -->
    <script type="text/javascript" src="<?php echo e(asset('plugins/bs-custom-file-input/bs-custom-file-input.min.js')); ?>"></script>
    <!-- Bootstrap Switch -->
    <script type="text/javascript" src="<?php echo e(asset('plugins/bootstrap-switch/js/bootstrap-switch.min.js')); ?>"></script>
    <script>
        //Date picker
        $('#purchase_date').datetimepicker({
            format: 'DD/MM/YYYY'
        });
        $('#inventory_date').datetimepicker({
            format: 'DD/MM/YYYY'
        });

        $(function () {
            bsCustomFileInput.init();
        });

        //Bootstrap Switch
        $("input[data-bootstrap-switch]").each(function(){
            $(this).bootstrapSwitch('state', $(this).prop('checked'));
        });
        
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\inventario\resources\views/computo/almacenamiento/edit.blade.php ENDPATH**/ ?>