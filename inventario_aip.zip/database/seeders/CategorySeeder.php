<?php

namespace Database\Seeders;

use App\Models\Category;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class CategorySeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run()
    {
        $category01 = new Category();
        $category01->cod = "DES";
        $category01->des = "Computadora de Escritorio (DeskTop)";
        $category01->obs = "Una computadora de escritorio es un equipo informático de tamaño mediano diseñado para su uso en un escritorio. Se compone de una torre que contiene los componentes principales, como la CPU, memoria, disco duro, etc. y un monitor, teclado y ratón para interactuar con el usuario.";
        $category01->save();

        $category02 = new Category();
        $category02->cod = "AIO";
        $category02->des = "Computadora Todo en Uno (All In One)";
        $category02->obs = "Una computadora todo en uno es un equipo informático que integra todos los componentes principales, como la CPU, memoria, disco duro, etc. en la misma carcasa que el monitor. Este diseño compacto y eficiente ocupa menos espacio en el escritorio y reduce el número de cables y conexiones necesarias.";
        $category02->save();

        $category03 = new Category();
        $category03->cod = "LAP";
        $category03->des = "Computadora Portátil (LapTop)";
        $category03->obs = "Una computadora portátil es un equipo informático compacto y ligero que se puede transportar con facilidad. Cuenta con una pantalla, teclado, batería, y todos los componentes principales integrados en una sola unidad. Las laptops suelen ser utilizadas para trabajar o estudiar en movimiento o en lugares donde no hay una conexión fija.";
        $category03->save();

        $category04 = new Category();
        $category04->cod = "SER";
        $category04->des = "Servidor";
        $category04->obs = "Un servidor es un equipo informático que proporciona servicios a otros dispositivos o programas, como el almacenamiento y distribución de archivos, el alojamiento de sitios web, el correo electrónico y la administración de bases de datos. Los servidores están diseñados para funcionar de manera constante y ofrecer un alto rendimiento y disponibilidad.";
        $category04->save();

        $category05 = new Category();
        $category05->cod = "TAB";
        $category05->des = "Tablet";
        $category05->obs = "Una tablet es un dispositivo electrónico portátil que combina las funciones de un ordenador y un smartphone. Normalmente cuentan con pantalla táctil, conexión Wi-Fi o 4G, cámara, micrófono y altavoces, y permiten navegar por Internet, enviar correos electrónicos, reproducir contenido multimedia, realizar videoconferencias y utilizar aplicaciones.";
        $category05->save();

        $category06 = new Category();
        $category06->cod = "CEL";
        $category06->des = "Celular";
        $category06->obs = "Un celular o teléfono móvil es un dispositivo electrónico portátil que permite la comunicación por voz y mensajes de texto, y que incluye otras funciones como acceso a Internet, cámaras, reproductores de música y GPS. Los celulares son indispensables en la vida cotidiana de muchas personas y se han convertido en una herramienta esencial de comunicación y entretenimiento.";
        $category06->save();

        $category07 = new Category();
        $category07->cod = "IMP";
        $category07->des = "Impresora / Multifuncional";
        $category07->obs = "Una impresora es un dispositivo que permite imprimir texto o imágenes en papel. Una multifuncional, además de imprimir, puede realizar otras funciones como escanear, copiar y enviar fax. Ambas se conectan a una computadora o red y utilizan tinta o tóner para imprimir en diferentes formatos y tamaños de papel.";
        $category07->save();

        $category08 = new Category();
        $category08->cod = "USB";
        $category08->des = "Memoria USB";
        $category08->obs = "Una memoria USB es un dispositivo de almacenamiento portátil que utiliza memoria flash para guardar y transferir datos entre diferentes dispositivos. Se conecta a través de un puerto USB y puede contener desde unos pocos megabytes hasta varios gigabytes de información. Son comúnmente utilizadas para transportar y respaldar archivos importantes.";
        $category08->save();

        $category09 = new Category();
        $category09->cod = "ROU";
        $category09->des = "Router";
        $category09->obs = "Un router es un dispositivo que se utiliza para interconectar redes informáticas. Actúa como punto de entrada y salida de paquetes de datos entre diferentes redes y se encarga de enviarlos a su destino correcto. También puede actuar como cortafuegos y permitir la configuración de redes privadas y públicas.";
        $category09->save();

        $category10 = new Category();
        $category10->cod = "SWI";
        $category10->des = "Switch";
        $category10->obs = "Un switch es un dispositivo que se utiliza para interconectar dispositivos dentro de una red informática local. Permite la transmisión de paquetes de datos entre ellos a través de una conexión de alta velocidad y determina el destino correcto de los paquetes en función de la dirección MAC de los dispositivos conectados.";
        $category10->save();

        $category11 = new Category();
        $category11->cod = "DVR";
        $category11->des = "DVR / XVR / NVR";
        $category11->obs = "Un DVR (Digital Video Recorder) es un dispositivo electrónico que permite grabar y almacenar video en formato digital en un disco duro interno o externo. Se utiliza comúnmente en sistemas de seguridad para grabar y almacenar imágenes de cámaras de seguridad y permitir su reproducción y análisis en un momento posterior.";
        $category11->save();

        $category12 = new Category();
        $category12->cod = "UPS";
        $category12->des = "NoBreak";
        $category12->obs = "Un NoBreak (también conocido como UPS, Uninterruptible Power Supply) es un dispositivo que proporciona energía eléctrica continua y sin interrupciones a los dispositivos electrónicos en caso de una interrupción de energía eléctrica. Utiliza baterías recargables para proporcionar energía de respaldo y permitir el apagado seguro de los dispositivos conectados.";
        $category12->save();

        $category13 = new Category();
        $category13->cod = "RCK";
        $category13->des = "Rack";
        $category13->obs = "Un rack es una estructura metálica diseñada para organizar y almacenar equipos electrónicos, como servidores, switches y equipos de red, de manera eficiente. Proporciona un espacio físico y una gestión adecuada de cables, facilitando el acceso y la administración de los dispositivos en un entorno tecnológico.";
        $category13->save();

        $category14 = new Category();
        $category14->cod = "PRY";
        $category14->des = "Proyector";
        $category14->obs = "Un proyector es un dispositivo audiovisual que utiliza una fuente de luz para proyectar imágenes o videos en una superficie grande, como una pantalla o una pared. Se utiliza principalmente en presentaciones, conferencias y entretenimiento, ofreciendo una experiencia visual inmersiva y de alta calidad.";
        $category14->save();

        $category15 = new Category();
        $category15->cod = "DDE";
        $category15->des = "Disco Duro Externo";
        $category15->obs = "Un disco duro externo es un dispositivo de almacenamiento portátil que se conecta a una computadora mediante cables, como USB o Thunderbolt. Permite almacenar y respaldar datos, como archivos, documentos y medios, proporcionando capacidad adicional y facilitando el transporte y acceso a la información en diferentes dispositivos.";
        $category15->save();

        $category16 = new Category();
        $category16->cod = "MON";
        $category16->des = "Monitor";
        $category16->obs = "Un monitor es un dispositivo de salida visual que muestra información gráfica generada por una computadora. Utiliza una pantalla para proyectar imágenes, textos y gráficos, permitiendo al usuario interactuar y visualizar el contenido de manera clara y en tiempo real.";
        $category16->save();

        $category17 = new Category();
        $category17->cod = "TLV";
        $category17->des = "Televisor o Pantalla";
        $category17->obs = "Un televisor o pantalla es un dispositivo electrónico que muestra imágenes en movimiento y transmite contenido audiovisual. Utiliza una superficie plana, como un panel LCD o LED, para proyectar programas de televisión, películas y otro tipo de contenido, brindando entretenimiento y una experiencia visual inmersiva en el hogar o en entornos públicos.";
        $category17->save();

        $category18 = new Category();
        $category18->cod = "SCA";
        $category18->des = "Scanner";
        $category18->obs = "Un scanner es un dispositivo electrónico que permite convertir documentos físicos, como fotografías o páginas impresas, en imágenes digitales. Utiliza un sensor óptico para capturar la información y la transfiere a la computadora, donde puede ser almacenada, editada o compartida electrónicamente, facilitando la gestión de documentos.";
        $category18->save();

        $category19 = new Category();
        $category19->cod = "FCP";
        $category19->des = "Fotocopiadora";
        $category19->obs = "Una fotocopiadora es un dispositivo de reproducción que utiliza tecnología de impresión para hacer copias físicas de documentos o imágenes. Escanea el original y luego imprime una réplica en papel, ofreciendo una forma rápida y conveniente de duplicar documentos en entornos de oficina y negocios.";
        $category19->save();

        $category20 = new Category();
        $category20->cod = "CTL";
        $category20->des = "Central Telefónica";
        $category20->obs = "Una central telefónica, también conocida como PBX (Private Branch Exchange), es un sistema de telecomunicaciones que facilita la gestión de llamadas telefónicas en una organización. Permite la interconexión de líneas telefónicas internas y externas, así como funciones como transferencia de llamadas, conferencias y correo de voz, optimizando la comunicación empresarial.";
        $category20->save();

        $category21 = new Category();
        $category21->cod = "BIO";
        $category21->des = "Checador Biométrico";
        $category21->obs = "Un checador biométrico es un dispositivo de control de asistencia que utiliza características físicas únicas de una persona, como huellas dactilares, reconocimiento facial o iris, para verificar la identidad y registrar la entrada y salida de empleados. Proporciona un registro preciso y seguro de la asistencia laboral.";
        $category21->save();

        $category22 = new Category();
        $category22->cod = "AAC";
        $category22->des = "Aire Acondicionado";
        $category22->obs = "Un aire acondicionado es un sistema que regula la temperatura, humedad y calidad del aire en un espacio cerrado. Enfría el ambiente mediante la extracción del calor y lo distribuye, proporcionando confort térmico y mejorando la calidad del aire interior en hogares, oficinas y otros entornos.";
        $category22->save();
    }
}
