<?php

namespace Database\Seeders;

use App\Models\Status;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class StatusSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run()
    {
        $status1 = new Status();
        $status1->des = "Productivo";
        $status1->obs = "El estatus productivo de un activo se refiere a su capacidad actual para producir o generar ingresos, y si se encuentra en condiciones óptimas para su uso y funcionamiento.";
        $status1->save();
        
        $status2 = new Status();
        $status2->des = "No Productivo";
        $status2->obs = "El estatus no productivo de un activo se refiere a su incapacidad actual para producir o generar ingresos, debido a que se encuentra en bodega o no se ha asignado a un usuario.";
        $status2->save();

        $status3 = new Status();
        $status3->des = "Reparación";
        $status3->obs = "El estatus en reparación de un activo se refiere a que el mismo se encuentra en proceso de reparación o mantenimiento para restaurar su capacidad productiva o su óptimo funcionamiento.";
        $status3->save();

        $status4 = new Status();
        $status4->des = "Baja";
        $status4->obs = "El estatus baja de un activo se refiere a que el mismo ha sido retirado o dado de baja del inventario, ya sea por obsolescencia, desgaste o por no ser rentable.";
        $status4->save();

    }

}
