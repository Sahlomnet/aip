<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use App\Models\Movement;

class ZMovementSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $movement01 = new Movement();
        $movement01->des = "Asignación Servidor Contabilidad";
        $movement01->movement_date = "2023-01-01";
        $movement01->placement_id = 17;
        $movement01->asset_id = 1;
        $movement01->obs = "";
        $movement01->save();

        $movement02 = new Movement();
        $movement02->des = "Asignación Servidor Nóminas";
        $movement02->movement_date = "2023-01-01";
        $movement02->placement_id = 17;
        $movement02->asset_id = 2;
        $movement02->obs = "";
        $movement02->save();

        $movement03 = new Movement();
        $movement03->des = "Asignación Computadora All In One Recepción";
        $movement03->movement_date = "2023-01-01";
        $movement03->placement_id = 16;
        $movement03->asset_id = 3;
        $movement03->obs = "";
        $movement03->save();

        $movement04 = new Movement();
        $movement04->des = "Asignación Computadora All In One Recursos Humanos 01";
        $movement04->movement_date = "2023-01-01";
        $movement04->placement_id = 15;
        $movement04->asset_id = 4;
        $movement04->obs = "";
        $movement04->save();

        $movement05 = new Movement();
        $movement05->des = "Asignación Computadora All In One Recursos Humanos 02";
        $movement05->movement_date = "2023-01-01";
        $movement05->placement_id = 13;
        $movement05->asset_id = 5;
        $movement05->obs = "";
        $movement05->save();

        $movement06 = new Movement();
        $movement06->des = "Asignación Computadora All In One Contabilidad 01";
        $movement06->movement_date = "2023-01-01";
        $movement06->placement_id = 9;
        $movement06->asset_id = 6;
        $movement06->obs = "";
        $movement06->save();

        $movement07 = new Movement();
        $movement07->des = "Asignación Computadora All In One Contabilidad 03";
        $movement07->movement_date = "2023-01-01";
        $movement07->placement_id = 10;
        $movement07->asset_id = 7;
        $movement07->obs = "";
        $movement07->save();

        $movement08 = new Movement();
        $movement08->des = "Asignación Computadora All In One Gerente General";
        $movement08->movement_date = "2023-01-01";
        $movement08->placement_id = 11;
        $movement08->asset_id = 8;
        $movement08->obs = "";
        $movement08->save();

        $movement09 = new Movement();
        $movement09->des = "Asignación Computadora All In One Asistente de Dirección";
        $movement09->movement_date = "2023-01-01";
        $movement09->placement_id = 8;
        $movement09->asset_id = 9;
        $movement09->obs = "";
        $movement09->save();

        $movement10 = new Movement();
        $movement10->des = "Asignación Computadora All In One Dirección";
        $movement10->movement_date = "2023-01-01";
        $movement10->placement_id = 2;
        $movement10->asset_id = 10;
        $movement10->obs = "";
        $movement10->save();

        $movement11 = new Movement();
        $movement11->des = "Asignación Computadora All In One Gerente Comercial";
        $movement11->movement_date = "2023-01-01";
        $movement11->placement_id = 4;
        $movement11->asset_id = 11;
        $movement11->obs = "";
        $movement11->save();

        $movement12 = new Movement();
        $movement12->des = "Asignación Laptop Sala de Juntas";
        $movement12->movement_date = "2023-01-01";
        $movement12->placement_id = 3;
        $movement12->asset_id = 12;
        $movement12->obs = "";
        $movement12->save();


    }
}
