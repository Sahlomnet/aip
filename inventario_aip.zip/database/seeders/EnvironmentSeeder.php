<?php

namespace Database\Seeders;

use App\Models\Environment;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class EnvironmentSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $environment01 = new Environment();
        $environment01->name = "AIPOFSER091";
        $environment01->domain_group = "AIPOF";
        $environment01->user = "Administrador";
        $environment01->password = "@LosPinos2021.";
        $environment01->rdp_port = 50091;
        $environment01->asset_id = 1;
        $environment01->obs = "";
        $environment01->save();

        $environment02 = new Environment();
        $environment02->name = "AIPOFSER091";
        $environment02->domain_group = "AIPOF";
        $environment02->user = "Direccion01";
        $environment02->password = "Pinos*DirG01.";
        $environment02->rdp_port = 50091;
        $environment02->asset_id = 1;
        $environment02->obs = "";
        $environment02->save();

        $environment03 = new Environment();
        $environment03->name = "AIPOFSER091";
        $environment03->domain_group = "AIPOF";
        $environment03->user = "Proyectos01";
        $environment03->password = "Pinos*Proy01.";
        $environment03->rdp_port = 50091;
        $environment03->asset_id = 1;
        $environment03->obs = "";
        $environment03->save();

        $environment04 = new Environment();
        $environment04->name = "AIPOFSER091";
        $environment04->domain_group = "AIPOF";
        $environment04->user = "Proyectos02";
        $environment04->password = "Pinos*Proy02.";
        $environment04->rdp_port = 50091;
        $environment04->asset_id = 1;
        $environment04->obs = "";
        $environment04->save();

        $environment05 = new Environment();
        $environment05->name = "AIPOFSER091";
        $environment05->domain_group = "AIPOF";
        $environment05->user = "Proyectos03";
        $environment05->password = "Pinos*Proy03.";
        $environment05->rdp_port = 50091;
        $environment05->asset_id = 1;
        $environment05->obs = "";
        $environment05->save();

        $environment06 = new Environment();
        $environment06->name = "AIPOFSER091";
        $environment06->domain_group = "AIPOF";
        $environment06->user = "Comunicacion01";
        $environment06->password = "Pinos*Comu01.";
        $environment06->rdp_port = 50091;
        $environment06->asset_id = 1;
        $environment06->obs = "";
        $environment06->save();

        $environment07 = new Environment();
        $environment07->name = "AIPOFSER091";
        $environment07->domain_group = "AIPOF";
        $environment07->user = "Procuracion01";
        $environment07->password = "Pinos*Procu01.";
        $environment07->rdp_port = 50091;
        $environment07->asset_id = 1;
        $environment07->obs = "";
        $environment07->save();

        $environment08 = new Environment();
        $environment08->name = "AIPOFSER091";
        $environment08->domain_group = "AIPOF";
        $environment08->user = "Recoleccion01";
        $environment08->password = "Pinos*Recol01.";
        $environment08->rdp_port = 50091;
        $environment08->asset_id = 1;
        $environment08->obs = "";
        $environment08->save();

        $environment09 = new Environment();
        $environment09->name = "AIPOFSER091";
        $environment09->domain_group = "AIPOF";
        $environment09->user = "Captacion01";
        $environment09->password = "Pinos*Captac01.";
        $environment09->rdp_port = 50091;
        $environment09->asset_id = 1;
        $environment09->obs = "";
        $environment09->save();

        $environment10 = new Environment();
        $environment10->name = "AIPOFSER091";
        $environment10->domain_group = "AIPOF";
        $environment10->user = "Captacion02";
        $environment10->password = "Pinos*Captac02.";
        $environment10->rdp_port = 50091;
        $environment10->asset_id = 1;
        $environment10->obs = "";
        $environment10->save();

        $environment11 = new Environment();
        $environment11->name = "AIPOFSER091";
        $environment11->domain_group = "AIPOF";
        $environment11->user = "Contabilidad01";
        $environment11->password = "Pinos*Conta01.";
        $environment11->rdp_port = 50091;
        $environment11->asset_id = 1;
        $environment11->obs = "";
        $environment11->save();

        $environment12 = new Environment();
        $environment12->name = "AIPOFSER091";
        $environment12->domain_group = "AIPOF";
        $environment12->user = "Promotora01";
        $environment12->password = "Pinos*Promo01.";
        $environment12->rdp_port = 50091;
        $environment12->asset_id = 1;
        $environment12->obs = "";
        $environment12->save();

        $environment13 = new Environment();
        $environment13->name = "AIPOFSER091";
        $environment13->domain_group = "AIPOF";
        $environment13->user = "Promotora02";
        $environment13->password = "Pinos*Promo02.";
        $environment13->rdp_port = 50091;
        $environment13->asset_id = 1;
        $environment13->obs = "";
        $environment13->save();

        $environment14 = new Environment();
        $environment14->name = "AIPOFSER091";
        $environment14->domain_group = "AIPOF";
        $environment14->user = "Promotora03";
        $environment14->password = "Pinos*Promo03.";
        $environment14->rdp_port = 50091;
        $environment14->asset_id = 1;
        $environment14->obs = "";
        $environment14->save();

        $environment15 = new Environment();
        $environment15->name = "AIPOFSER092";
        $environment15->domain_group = "AIPOF";
        $environment15->user = "Administrador";
        $environment15->password = "@AipOfAdmin2021.";
        $environment15->rdp_port = 50192;
        $environment15->asset_id = 2;
        $environment15->obs = "";
        $environment15->save();

        $environment16 = new Environment();
        $environment16->name = "AIPOFSER092";
        $environment16->domain_group = "AIPOF";
        $environment16->user = "Contabilidad01";
        $environment16->password = "AipOf@Conta01.";
        $environment16->rdp_port = 50192;
        $environment16->asset_id = 2;
        $environment16->obs = "";
        $environment16->save();

        $environment17 = new Environment();
        $environment17->name = "AIPOFSER092";
        $environment17->domain_group = "AIPOF";
        $environment17->user = "Contabilidad02";
        $environment17->password = "AipOf@Conta02.";
        $environment17->rdp_port = 50192;
        $environment17->asset_id = 2;
        $environment17->obs = "";
        $environment17->save();

        $environment18 = new Environment();
        $environment18->name = "AIPOFSER092";
        $environment18->domain_group = "AIPOF";
        $environment18->user = "Contabilidad03";
        $environment18->password = "AipOf@Conta03.";
        $environment18->rdp_port = 50192;
        $environment18->asset_id = 2;
        $environment18->obs = "";
        $environment18->save();

        $environment19 = new Environment();
        $environment19->name = "AIPOFSER092";
        $environment19->domain_group = "AIPOF";
        $environment19->user = "Recoleccion01";
        $environment19->password = "AipOf@Recol01.";
        $environment19->rdp_port = 50192;
        $environment19->asset_id = 2;
        $environment19->obs = "";
        $environment19->save();

        $environment20 = new Environment();
        $environment20->name = "AIPOFSER092";
        $environment20->domain_group = "AIPOF";
        $environment20->user = "Almacen01";
        $environment20->password = "AipOf@Almac01.";
        $environment20->rdp_port = 50192;
        $environment20->asset_id = 2;
        $environment20->obs = "";
        $environment20->save();

        $environment21 = new Environment();
        $environment21->name = "AIPOFSER092";
        $environment21->domain_group = "AIPOF";
        $environment21->user = "Medicos01";
        $environment21->password = "AipOf@Medic01.";
        $environment21->rdp_port = 50192;
        $environment21->asset_id = 2;
        $environment21->obs = "";
        $environment21->save();

        $environment22 = new Environment();
        $environment22->name = "AIPOFSER092";
        $environment22->domain_group = "AIPOF";
        $environment22->user = "Nutricion01";
        $environment22->password = "AipOf@Nutric01.";
        $environment22->rdp_port = 50192;
        $environment22->asset_id = 2;
        $environment22->obs = "";
        $environment22->save();

        $environment23 = new Environment();
        $environment23->name = "AIPOFSER092";
        $environment23->domain_group = "AIPOF";
        $environment23->user = "Sistemas01";
        $environment23->password = "@AipOfS2021.";
        $environment23->rdp_port = 50192;
        $environment23->asset_id = 2;
        $environment23->obs = "";
        $environment23->save();

        $environment24 = new Environment();
        $environment24->name = "AIPOFSER092";
        $environment24->domain_group = "AIPOF";
        $environment24->user = "Nutricion02";
        $environment24->password = "AipOf@Nutric02.";
        $environment24->rdp_port = 50192;
        $environment24->asset_id = 2;
        $environment24->obs = "";
        $environment24->save();

        $environment25 = new Environment();
        $environment25->name = "AIPOFDESDIRG01";
        $environment25->domain_group = "AIPOF";
        $environment25->user = "AIP";
        $environment25->password = "aip";
        $environment25->rdp_port = 50001;
        $environment25->asset_id = 3;
        $environment25->obs = "";
        $environment25->save();

        $environment26 = new Environment();
        $environment26->name = "AIPOFLAPDIRG01";
        $environment26->domain_group = "AIPOF";
        $environment26->user = "AIP";
        $environment26->password = "aip";
        $environment26->rdp_port = 50002;
        $environment26->asset_id = 4;
        $environment26->obs = "";
        $environment26->save();

        $environment27 = new Environment();
        $environment27->name = "PINOSOFDESDH01";
        $environment27->domain_group = "AIPOF";
        $environment27->user = "AIP";
        $environment27->password = "aip";
        $environment27->rdp_port = 50003;
        $environment27->asset_id = 5;
        $environment27->obs = "";
        $environment27->save();

        $environment28 = new Environment();
        $environment28->name = "AIPOFDESCAPT04";
        $environment28->domain_group = "AIPOF";
        $environment28->user = "AIP";
        $environment28->password = "aip";
        $environment28->rdp_port = 50004;
        $environment28->asset_id = 6;
        $environment28->obs = "";
        $environment28->save();

        $environment29 = new Environment();
        $environment29->name = "AIPOFDESCAPT03";
        $environment29->domain_group = "AIPOF";
        $environment29->user = "AIP";
        $environment29->password = "aip";
        $environment29->rdp_port = 50005;
        $environment29->asset_id = 7;
        $environment29->obs = "";
        $environment29->save();

        $environment30 = new Environment();
        $environment30->name = "AIPOFDESPROC01";
        $environment30->domain_group = "AIPOF";
        $environment30->user = "AIP";
        $environment30->password = "aip";
        $environment30->rdp_port = 50006;
        $environment30->asset_id = 8;
        $environment30->obs = "";
        $environment30->save();

        $environment31 = new Environment();
        $environment31->name = "AIPOFLAPPROC01";
        $environment31->domain_group = "AIPOF";
        $environment31->user = "AIP";
        $environment31->password = "aip";
        $environment31->rdp_port = 50007;
        $environment31->asset_id = 9;
        $environment31->obs = "";
        $environment31->save();

        $environment32 = new Environment();
        $environment32->name = "AIPOFDESCAPT02";
        $environment32->domain_group = "AIPOF";
        $environment32->user = "AIP";
        $environment32->password = "aip";
        $environment32->rdp_port = 50008;
        $environment32->asset_id = 10;
        $environment32->obs = "";
        $environment32->save();

        $environment33 = new Environment();
        $environment33->name = "AIPOFDESCAPT01";
        $environment33->domain_group = "AIPOF";
        $environment33->user = "AIP";
        $environment33->password = "aip";
        $environment33->rdp_port = 50009;
        $environment33->asset_id = 11;
        $environment33->obs = "";
        $environment33->save();

        $environment34 = new Environment();
        $environment34->name = "AIPOFDESPROY01";
        $environment34->domain_group = "AIPOF";
        $environment34->user = "AIP";
        $environment34->password = "aip";
        $environment34->rdp_port = 50010;
        $environment34->asset_id = 12;
        $environment34->obs = "";
        $environment34->save();

        $environment35 = new Environment();
        $environment35->name = "AIPOFDESSEG01";
        $environment35->domain_group = "AIPOF";
        $environment35->user = "AIP";
        $environment35->password = "aip";
        $environment35->rdp_port = 50011;
        $environment35->asset_id = 13;
        $environment35->obs = "";
        $environment35->save();

        $environment36 = new Environment();
        $environment36->name = "AIPOFLAPSEG01";
        $environment36->domain_group = "AIPOF";
        $environment36->user = "AIP";
        $environment36->password = "aip";
        $environment36->rdp_port = 50012;
        $environment36->asset_id = 14;
        $environment36->obs = "";
        $environment36->save();

        $environment37 = new Environment();
        $environment37->name = "AIPOFDESCONTA03";
        $environment37->domain_group = "AIPOF";
        $environment37->user = "AIP";
        $environment37->password = "aip";
        $environment37->rdp_port = 50013;
        $environment37->asset_id = 15;
        $environment37->obs = "";
        $environment37->save();

        $environment38 = new Environment();
        $environment38->name = "AIPOFDESRECOL01";
        $environment38->domain_group = "AIPOF";
        $environment38->user = "AIP";
        $environment38->password = "aip";
        $environment38->rdp_port = 50014;
        $environment38->asset_id = 16;
        $environment38->obs = "";
        $environment38->save();

        $environment39 = new Environment();
        $environment39->name = "AIPOFDESCONTA02";
        $environment39->domain_group = "AIPOF";
        $environment39->user = "AIP";
        $environment39->password = "aip";
        $environment39->rdp_port = 50015;
        $environment39->asset_id = 17;
        $environment39->obs = "";
        $environment39->save();

        $environment40 = new Environment();
        $environment40->name = "AIPOFLAPCONTA02";
        $environment40->domain_group = "AIPOF";
        $environment40->user = "AIP";
        $environment40->password = "aip";
        $environment40->rdp_port = 50016;
        $environment40->asset_id = 18;
        $environment40->obs = "";
        $environment40->save();

        $environment41 = new Environment();
        $environment41->name = "AIPCNSER091";
        $environment41->domain_group = "AIPCN";
        $environment41->user = "Administrador";
        $environment41->password = "@LosPinos2021.";
        $environment41->rdp_port = 50091;
        $environment41->asset_id = 19;
        $environment41->obs = "";
        $environment41->save();

        $environment42 = new Environment();
        $environment42->name = "AIPCNSER091";
        $environment42->domain_group = "AIPCN";
        $environment42->user = "Consultorio01";
        $environment42->password = "Pinos*CO01.";
        $environment42->rdp_port = 50091;
        $environment42->asset_id = 19;
        $environment42->obs = "";
        $environment42->save();

        $environment43 = new Environment();
        $environment43->name = "AIPCNSER091";
        $environment43->domain_group = "AIPCN";
        $environment43->user = "DEducativa01";
        $environment43->password = "Pinos*DE01.";
        $environment43->rdp_port = 50091;
        $environment43->asset_id = 19;
        $environment43->obs = "";
        $environment43->save();

        $environment44 = new Environment();
        $environment44->name = "AIPCNSER091";
        $environment44->domain_group = "AIPCN";
        $environment44->user = "DHumano01";
        $environment44->password = "Pinos*DH01.";
        $environment44->rdp_port = 50091;
        $environment44->asset_id = 19;
        $environment44->obs = "";
        $environment44->save();

        $environment45 = new Environment();
        $environment45->name = "AIPCNSER091";
        $environment45->domain_group = "AIPCN";
        $environment45->user = "EEspecial01";
        $environment45->password = "Pinos*EE01.";
        $environment45->rdp_port = 50091;
        $environment45->asset_id = 19;
        $environment45->obs = "";
        $environment45->save();

        $environment46 = new Environment();
        $environment46->name = "AIPCNSER091";
        $environment46->domain_group = "AIPCN";
        $environment46->user = "FFamiliar01";
        $environment46->password = "Pinos*FF01.";
        $environment46->rdp_port = 50091;
        $environment46->asset_id = 19;
        $environment46->obs = "";
        $environment46->save();

        $environment47 = new Environment();
        $environment47->name = "AIPCNSER091";
        $environment47->domain_group = "AIPCN";
        $environment47->user = "FFamiliar02";
        $environment47->password = "Pinos*FF02.";
        $environment47->rdp_port = 50091;
        $environment47->asset_id = 19;
        $environment47->obs = "";
        $environment47->save();

        $environment48 = new Environment();
        $environment48->name = "AIPCNSER091";
        $environment48->domain_group = "AIPCN";
        $environment48->user = "FFamiliar03";
        $environment48->password = "Pinos*FF03.";
        $environment48->rdp_port = 50091;
        $environment48->asset_id = 19;
        $environment48->obs = "";
        $environment48->save();

        $environment49 = new Environment();
        $environment49->name = "AIPCNSER091";
        $environment49->domain_group = "AIPCN";
        $environment49->user = "FFamiliar04";
        $environment49->password = "Pinos*FF04.";
        $environment49->rdp_port = 50091;
        $environment49->asset_id = 19;
        $environment49->obs = "";
        $environment49->save();

        $environment50 = new Environment();
        $environment50->name = "AIPCNSER091";
        $environment50->domain_group = "AIPCN";
        $environment50->user = "FFamiliar05";
        $environment50->password = "Pinos*FF05.";
        $environment50->rdp_port = 50091;
        $environment50->asset_id = 19;
        $environment50->obs = "";
        $environment50->save();

        $environment51 = new Environment();
        $environment51->name = "AIPCNSER091";
        $environment51->domain_group = "AIPCN";
        $environment51->user = "FFamiliar06";
        $environment51->password = "Pinos*FF06.";
        $environment51->rdp_port = 50091;
        $environment51->asset_id = 19;
        $environment51->obs = "";
        $environment51->save();

        $environment52 = new Environment();
        $environment52->name = "AIPCNSER091";
        $environment52->domain_group = "AIPCN";
        $environment52->user = "FInfantil01";
        $environment52->password = "Pinos*FI01.";
        $environment52->rdp_port = 50091;
        $environment52->asset_id = 19;
        $environment52->obs = "";
        $environment52->save();

        $environment53 = new Environment();
        $environment53->name = "AIPCNSER091";
        $environment53->domain_group = "AIPCN";
        $environment53->user = "FInfantil02";
        $environment53->password = "Pinos*FI02.";
        $environment53->rdp_port = 50091;
        $environment53->asset_id = 19;
        $environment53->obs = "";
        $environment53->save();

        $environment54 = new Environment();
        $environment54->name = "AIPCNSER091";
        $environment54->domain_group = "AIPCN";
        $environment54->user = "FInfantil03";
        $environment54->password = "Pinos*FI03.";
        $environment54->rdp_port = 50091;
        $environment54->asset_id = 19;
        $environment54->obs = "";
        $environment54->save();

        $environment55 = new Environment();
        $environment55->name = "AIPCNSER091";
        $environment55->domain_group = "AIPCN";
        $environment55->user = "FInfantil04";
        $environment55->password = "Pinos*FI04.";
        $environment55->rdp_port = 50091;
        $environment55->asset_id = 19;
        $environment55->obs = "";
        $environment55->save();

        $environment56 = new Environment();
        $environment56->name = "AIPCNSER091";
        $environment56->domain_group = "AIPCN";
        $environment56->user = "FInfantil05";
        $environment56->password = "Pinos*FI05.";
        $environment56->rdp_port = 50091;
        $environment56->asset_id = 19;
        $environment56->obs = "";
        $environment56->save();

        $environment57 = new Environment();
        $environment57->name = "AIPCNSER091";
        $environment57->domain_group = "AIPCN";
        $environment57->user = "FInfantil06";
        $environment57->password = "Pinos*FI06.";
        $environment57->rdp_port = 50091;
        $environment57->asset_id = 19;
        $environment57->obs = "";
        $environment57->save();

        $environment58 = new Environment();
        $environment58->name = "AIPCNSER091";
        $environment58->domain_group = "AIPCN";
        $environment58->user = "FInfantil07";
        $environment58->password = "Pinos*FI07.";
        $environment58->rdp_port = 50091;
        $environment58->asset_id = 19;
        $environment58->obs = "";
        $environment58->save();

        $environment59 = new Environment();
        $environment59->name = "AIPCNSER091";
        $environment59->domain_group = "AIPCN";
        $environment59->user = "FInfantil08";
        $environment59->password = "Pinos*FI08.";
        $environment59->rdp_port = 50091;
        $environment59->asset_id = 19;
        $environment59->obs = "";
        $environment59->save();

        $environment60 = new Environment();
        $environment60->name = "AIPCNSER091";
        $environment60->domain_group = "AIPCN";
        $environment60->user = "FInfantil09";
        $environment60->password = "Pinos*FI09.";
        $environment60->rdp_port = 50091;
        $environment60->asset_id = 19;
        $environment60->obs = "";
        $environment60->save();

        $environment61 = new Environment();
        $environment61->name = "AIPCNSER091";
        $environment61->domain_group = "AIPCN";
        $environment61->user = "FInfantil10";
        $environment61->password = "Pinos*FI10.";
        $environment61->rdp_port = 50091;
        $environment61->asset_id = 19;
        $environment61->obs = "";
        $environment61->save();

        $environment62 = new Environment();
        $environment62->name = "AIPCNSER091";
        $environment62->domain_group = "AIPCN";
        $environment62->user = "FJuvenil01";
        $environment62->password = "Pinos*FJ01.";
        $environment62->rdp_port = 50091;
        $environment62->asset_id = 19;
        $environment62->obs = "";
        $environment62->save();

        $environment63 = new Environment();
        $environment63->name = "AIPCNSER091";
        $environment63->domain_group = "AIPCN";
        $environment63->user = "FJuvenil02";
        $environment63->password = "Pinos*FJ02.";
        $environment63->rdp_port = 50091;
        $environment63->asset_id = 19;
        $environment63->obs = "";
        $environment63->save();

        $environment64 = new Environment();
        $environment64->name = "AIPCNSER091";
        $environment64->domain_group = "AIPCN";
        $environment64->user = "FJuvenil03";
        $environment64->password = "Pinos*FJ03.";
        $environment64->rdp_port = 50091;
        $environment64->asset_id = 19;
        $environment64->obs = "";
        $environment64->save();

        $environment65 = new Environment();
        $environment65->name = "AIPCNSER091";
        $environment65->domain_group = "AIPCN";
        $environment65->user = "FJuvenil04";
        $environment65->password = "Pinos*FJ04.";
        $environment65->rdp_port = 50091;
        $environment65->asset_id = 19;
        $environment65->obs = "";
        $environment65->save();

        $environment66 = new Environment();
        $environment66->name = "AIPCNSER091";
        $environment66->domain_group = "AIPCN";
        $environment66->user = "FJuvenil05";
        $environment66->password = "Pinos*FJ05.";
        $environment66->rdp_port = 50091;
        $environment66->asset_id = 19;
        $environment66->obs = "";
        $environment66->save();

        $environment67 = new Environment();
        $environment67->name = "AIPCNSER091";
        $environment67->domain_group = "AIPCN";
        $environment67->user = "FVIndependiente01";
        $environment67->password = "Pinos*VI01.";
        $environment67->rdp_port = 50091;
        $environment67->asset_id = 19;
        $environment67->obs = "";
        $environment67->save();

        $environment68 = new Environment();
        $environment68->name = "AIPCNSER091";
        $environment68->domain_group = "AIPCN";
        $environment68->user = "FVIndependiente02";
        $environment68->password = "Pinos*VI02.";
        $environment68->rdp_port = 50091;
        $environment68->asset_id = 19;
        $environment68->obs = "";
        $environment68->save();

        $environment69 = new Environment();
        $environment69->name = "AIPCNSER091";
        $environment69->domain_group = "AIPCN";
        $environment69->user = "Nutricion01";
        $environment69->password = "Pinos*NU01.";
        $environment69->rdp_port = 50091;
        $environment69->asset_id = 19;
        $environment69->obs = "";
        $environment69->save();

        $environment70 = new Environment();
        $environment70->name = "AIPCNSER091";
        $environment70->domain_group = "AIPCN";
        $environment70->user = "OCalidad01";
        $environment70->password = "Pinos*OC01.";
        $environment70->rdp_port = 50091;
        $environment70->asset_id = 19;
        $environment70->obs = "";
        $environment70->save();

        $environment71 = new Environment();
        $environment71->name = "AIPCNSER091";
        $environment71->domain_group = "AIPCN";
        $environment71->user = "Recepcion01";
        $environment71->password = "Pinos*RE01.";
        $environment71->rdp_port = 50091;
        $environment71->asset_id = 19;
        $environment71->obs = "";
        $environment71->save();

        $environment72 = new Environment();
        $environment72->name = "AIPCNSER091";
        $environment72->domain_group = "AIPCN";
        $environment72->user = "Talleres02";
        $environment72->password = "Pinos*TA02.";
        $environment72->rdp_port = 50091;
        $environment72->asset_id = 19;
        $environment72->obs = "";
        $environment72->save();

        $environment73 = new Environment();
        $environment73->name = "AIPCNSER091";
        $environment73->domain_group = "AIPCN";
        $environment73->user = "SoporteTI";
        $environment73->password = "@Soporte2021.";
        $environment73->rdp_port = 50091;
        $environment73->asset_id = 19;
        $environment73->obs = "";
        $environment73->save();

        $environment74 = new Environment();
        $environment74->name = "AIPCNSER091";
        $environment74->domain_group = "AIPCN";
        $environment74->user = "TSocial02";
        $environment74->password = "Pinos*TS02.";
        $environment74->rdp_port = 50091;
        $environment74->asset_id = 19;
        $environment74->obs = "";
        $environment74->save();

        $environment75 = new Environment();
        $environment75->name = "AIPCNSER091";
        $environment75->domain_group = "AIPCN";
        $environment75->user = "TSocial03";
        $environment75->password = "Pinos*TS03.";
        $environment75->rdp_port = 50091;
        $environment75->asset_id = 19;
        $environment75->obs = "";
        $environment75->save();

        $environment76 = new Environment();
        $environment76->name = "AIPCNSER091";
        $environment76->domain_group = "AIPCN";
        $environment76->user = "Mantenimiento01";
        $environment76->password = "Pinos*Mant01.";
        $environment76->rdp_port = 50091;
        $environment76->asset_id = 19;
        $environment76->obs = "";
        $environment76->save();

        // $environment04 = new Environment();
        // $environment04->name = "AIPCNLAPGIL";
        // $environment04->domain_group = "AIPCN";
        // $environment04->user = "AIP";
        // $environment04->password = NULL;
        // $environment04->rdp_port = NULL;
        // $environment04->asset_id = 4;
        // $environment04->obs = "Gil Laptop HP Nueva";
        // $environment04->save();
        
        $environment99 = new Environment();
        $environment99->name = "AIPCIDESALMAC02";
        $environment99->domain_group = "AIPCI";
        $environment99->user = "Almacen";
        $environment99->password = "";
        $environment99->rdp_port = 50101;
        $environment99->asset_id = 62;
        $environment99->obs = "";
        $environment99->save();


    }
}
