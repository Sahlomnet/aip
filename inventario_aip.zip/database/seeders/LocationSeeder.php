<?php

namespace Database\Seeders;

use App\Models\Location;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class LocationSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $location01 = new Location();
        $location01->name = "Oficinas Administrativas";
        $location01->tel = "+523336295000";
        $location01->public_ip = "187.189.79.31";
        $location01->public_dns = "oficinas.pinosac.org";
        $location01->street = "Av. Vallarta";
        $location01->ext_number = "5085";
        $location01->int_number = NULL;
        $location01->col = "Real Vallarta";
        $location01->city = "Zapopan";
        $location01->mun = "Zapopan";
        $location01->state = "Jalisco";
        $location01->country = "México";
        $location01->zip_code = "45020";
        $location01->obs = "Locación Oficinas Administrativas";
        $location01->save();

        $location02 = new Location();
        $location02->name = "Casa de Niños";
        $location02->tel = "+523336273196";
        $location02->public_ip = "187.188.199.151";
        $location02->public_dns = "ninos.pinosac.org";
        $location02->street = "Calzada de los Fresnos";
        $location02->ext_number = "47";
        $location02->int_number = NULL;
        $location02->col = "Ciudad Granja";
        $location02->city = "Zapopan";
        $location02->mun = "Zapopan";
        $location02->state = "Jalisco";
        $location02->country = "México";
        $location02->zip_code = "45010";
        $location02->obs = "Locación Casa de Niños";
        $location02->save();

        $location03 = new Location();
        $location03->name = "Casa de Jóvenes";
        $location03->tel = "+523321537291";
        $location03->public_ip = "N/A";
        $location03->public_dns = "N/A";
        $location03->street = "Calzada de los Ángeles";
        $location03->ext_number = "6917";
        $location03->int_number = NULL;
        $location03->col = "Ciudad Granja";
        $location03->city = "Zapopan";
        $location03->mun = "Zapopan";
        $location03->state = "Jalisco";
        $location03->country = "México";
        $location03->zip_code = "45010";
        $location03->obs = "Locación Casa de Jóvenes";
        $location03->save();

        $location04 = new Location();
        $location04->name = "Cipreses";
        $location04->tel = "+523336736736";
        $location04->public_ip = "N/A";
        $location04->public_dns = "N/A";
        $location04->street = "Calzada de los Cipreses";
        $location04->ext_number = "29";
        $location04->int_number = NULL;
        $location04->col = "Ciudad Granja";
        $location04->city = "Zapopan";
        $location04->mun = "Zapopan";
        $location04->state = "Jalisco";
        $location04->country = "México";
        $location04->zip_code = "45010";
        $location04->obs = "Locación Cipreses";
        $location04->save();


    }
}







