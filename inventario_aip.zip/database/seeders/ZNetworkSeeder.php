<?php

namespace Database\Seeders;

use App\Models\Network;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class ZNetworkSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $network01= new Network();
        $network01->type = "Ethernet";
        $network01->mac = "9C-B6-54-B3-58-88";
        $network01->ip = "192.168.1.91";
        $network01->asset_id = 1;
        $network01->manufacturer_id = 12;
        $network01->obs = "";
        $network01->save();

        $network02= new Network();
        $network02->type = "Ethernet";
        $network02->mac = "A0-B3-CC-E5-D2-F8";
        $network02->ip = "192.168.1.93";
        $network02->asset_id = 2;
        $network02->manufacturer_id = 12;
        $network02->obs = "";
        $network02->save();

        $network03= new Network();
        $network03->type = "Ethernet";
        $network03->mac = "A0-B3-CC-E5-D2-F9";
        $network03->ip = "192.168.1.94";
        $network03->asset_id = 2;
        $network03->manufacturer_id = 12;
        $network03->obs = "";
        $network03->save();

        // Diana
        $network04= new Network();
        $network04->type = "Ethernet";
        $network04->mac = "98:E7:F4:4D:82:B4";
        $network04->ip = "192.168.1.101";
        $network04->asset_id = 3;
        $network04->manufacturer_id = 21;
        $network04->obs = "";
        $network04->save();

        $network05= new Network();
        $network05->type = "WiFi";
        $network05->mac = "CC:B0:DA:7B:67:F5";
        $network05->ip = "192.168.1.201";
        $network05->asset_id = 3;
        $network05->manufacturer_id = 21;
        $network05->obs = "";
        $network05->save();

        // Gera
        $network06= new Network();
        $network06->type = "Ethernet";
        $network06->mac = "B0:0C:D1:56:FF:30";
        $network06->ip = "192.168.1.106";
        $network06->asset_id = 4;
        $network06->manufacturer_id = 21;
        $network06->obs = "";
        $network06->save();

        $network07= new Network();
        $network07->type = "WiFi";
        $network07->mac = "48:5F:99:07:C0:7F";
        $network07->ip = "192.168.1.206";
        $network07->asset_id = 4;
        $network07->manufacturer_id = 21;
        $network07->obs = "";
        $network07->save();

        // Valeria
        $network08= new Network();
        $network08->type = "Ethernet";
        $network08->mac = "98:E7:F4:4D:83:57";
        $network08->ip = "192.168.1.104";
        $network08->asset_id = 5;
        $network08->manufacturer_id = 21;
        $network08->obs = "";
        $network08->save();

        $network09= new Network();
        $network09->type = "WiFi";
        $network09->mac = "CC:B0:DA:7B:0E:13";
        $network09->ip = "192.168.1.204";
        $network09->asset_id = 5;
        $network09->manufacturer_id = 21;
        $network09->obs = "";
        $network09->save();

        // Janeth
        $network10= new Network();
        $network10->type = "Ethernet";
        $network10->mac = "80:CE:62:41:64:8E";
        $network10->ip = "192.168.1.107";
        $network10->asset_id = 6;
        $network10->manufacturer_id = 21;
        $network10->obs = "";
        $network10->save();

        $network11= new Network();
        $network11->type = "WiFi";
        $network11->mac = "98:22:EF:BD:E9:1D";
        $network11->ip = "192.168.1.207";
        $network11->asset_id = 6;
        $network11->manufacturer_id = 21;
        $network11->obs = "";
        $network11->save();

        // Caro
        $network12= new Network();
        $network12->type = "Ethernet";
        $network12->mac = "C8:D3:FF:DE:15:DA";
        $network12->ip = "192.168.1.108";
        $network12->asset_id = 7;
        $network12->manufacturer_id = 21;
        $network12->obs = "";
        $network12->save();

        $network13= new Network();
        $network13->type = "WiFi";
        $network13->mac = "3C:A0:67:67:E5:DA";
        $network13->ip = "192.168.1.208";
        $network13->asset_id = 7;
        $network13->manufacturer_id = 21;
        $network13->obs = "";
        $network13->save();
                
        // Valentín
        $network14= new Network();
        $network14->type = "Ethernet";
        $network14->mac = "60:02:92:57:2D:69";
        $network14->ip = "192.168.1.109";
        $network14->asset_id = 8;
        $network14->manufacturer_id = 21;
        $network14->obs = "";
        $network14->save();

        $network15= new Network();
        $network15->type = "WiFi";
        $network15->mac = "2C:33:7A:8A:E7:2D";
        $network15->ip = "192.168.1.209";
        $network15->asset_id = 8;
        $network15->manufacturer_id = 21;
        $network15->obs = "";
        $network15->save();
                
        // Gaby
        $network16= new Network();
        $network16->type = "Ethernet";
        $network16->mac = "0C:54:A5:00:17:50";
        $network16->ip = "192.168.1.113";
        $network16->asset_id = 9;
        $network16->manufacturer_id = 21;
        $network16->obs = "";
        $network16->save();

        $network17= new Network();
        $network17->type = "WiFi";
        $network17->mac = "A4:DB:30:3F:12:2F";
        $network17->ip = "192.168.1.213";
        $network17->asset_id = 9;
        $network17->manufacturer_id = 18;
        $network17->obs = "";
        $network17->save();

        // Paty
        $network18= new Network();
        $network18->type = "Ethernet";
        $network18->mac = "E8:40:F2:0E:BE:E2";
        $network18->ip = "192.168.1.115";
        $network18->asset_id = 9;
        $network18->manufacturer_id = 21;
        $network18->obs = "";
        $network18->save();

        $network19= new Network();
        $network19->type = "WiFi";
        $network19->mac = "9C:B7:0D:A4:BC:E7";
        $network19->ip = "192.168.1.215";
        $network19->asset_id = 10;
        $network19->manufacturer_id = 18;
        $network19->obs = "";
        $network19->save();

        // Ivan
        $network20= new Network();
        $network20->type = "Ethernet";
        $network20->mac = "C8:D3:FF:DE:1D:F8";
        $network20->ip = "192.168.1.116";
        $network20->asset_id = 11;
        $network20->manufacturer_id = 21;
        $network20->obs = "";
        $network20->save();

        $network21= new Network();
        $network21->type = "WiFi";
        $network21->mac = "3C:A0:67:67:93:69";
        $network21->ip = "192.168.1.216";
        $network21->asset_id = 11;
        $network21->manufacturer_id = 21;
        $network21->obs = "";
        $network21->save();

        // Juntas
        $network22= new Network();
        $network22->type = "Ethernet";
        $network22->mac = "48:9E:BD:F7:73:21";
        $network22->ip = "192.168.1.114";
        $network22->asset_id = 12;
        $network22->manufacturer_id = 21;
        $network22->obs = "";
        $network22->save();

        $network23= new Network();
        $network23->type = "WiFi";
        $network23->mac = "48:E7:DA:96:51:93";
        $network23->ip = "192.168.1.214";
        $network23->asset_id = 12;
        $network23->manufacturer_id = 21;
        $network23->obs = "";
        $network23->save();
        



    }
}
