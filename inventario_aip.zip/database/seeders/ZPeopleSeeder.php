<?php

namespace Database\Seeders;

use App\Models\People;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class ZPeopleSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $people01 = new People();
        $people01->name = "María Guadalupe Patricia";
        $people01->last_name = "Navarro Ibarra";
        $people01->position = "Dirección General";
        $people01->tel = "+523333595470";
        $people01->mail = "direccion@gruponovelty.com";
        $people01->obs = "";
        $people01->save();

        $people02 = new People();
        $people02->name = "Ivan";
        $people02->last_name = "Navarro Hernández";
        $people02->position = "Gerente Comercial";
        $people02->tel = "+523311104663";
        $people02->mail = "ivan.navarro@gruponovelty.com";
        $people02->obs = "";
        $people02->save();

        $people03 = new People();
        $people03->name = "Gabriela Salomé";
        $people03->last_name = "Sánchez Romero";
        $people03->position = "Asistente de Dirección";
        $people03->tel = "+523331506173";
        $people03->mail = "asistente.direccion@gruponovelty.com";
        $people03->obs = "";
        $people03->save();

        $people04 = new People();
        $people04->name = "Jorge Gabriel";
        $people04->last_name = "Ramírez González";
        $people04->position = "Gestoría";
        $people04->tel = "+523330342986";
        $people04->mail = "";
        $people04->obs = "";
        $people04->save();

        $people05 = new People();
        $people05->name = "Diana Laura";
        $people05->last_name = "Sánchez Romero";
        $people05->position = "Recepción";
        $people05->tel = "+523318883781";
        $people05->mail = "recepcion@gruponovelty.com";
        $people05->obs = "";
        $people05->save();

        $people06 = new People();
        $people06->name = "José Valentín";
        $people06->last_name = "Cárdenas Pérez";
        $people06->position = "Gerente General";
        $people06->tel = "+523323108544";
        $people06->mail = "auditoria@gruponovelty.com";
        $people06->obs = "";
        $people06->save();

        $people07 = new People();
        $people07->name = "Martha Carolina";
        $people07->last_name = "López Arellano";
        $people07->position = "Contabilidad 03";
        $people07->tel = "+52";
        $people07->mail = "contabilidad3@gruponovelty.com";
        $people07->obs = "";
        $people07->save();

        $people08 = new People();
        $people08->name = "Janeth Guadalupe";
        $people08->last_name = "Terrones Sánchez";
        $people08->position = "Contabilidad 01";
        $people08->tel = "+528713795288";
        $people08->mail = "contabilidad1@gruponovelty.com";
        $people08->obs = "";
        $people08->save();

        $people09 = new People();
        $people09->name = "José Benjamín";
        $people09->last_name = "Sahagún Lomelí";
        $people09->position = "Sistemas";
        $people09->tel = "+523323851005";
        $people09->mail = "benjamin@gruponovelty.com";
        $people09->obs = "";
        $people09->save();

        $people10 = new People();
        $people10->name = "Gerardo";
        $people10->last_name = "Santos Velarde";
        $people10->position = "Recursos Humanos 01";
        $people10->tel = "+523331056837";
        $people10->mail = "recursoshumanos@gruponovelty.com";
        $people10->obs = "";
        $people10->save();

        $people11 = new People();
        $people11->name = "Valeria Getsemani";
        $people11->last_name = "Gámez González";
        $people11->position = "Recursos Humanos 02";
        $people11->tel = "+523310693804";
        $people11->mail = "nominas1@gruponovelty.com";
        $people11->obs = "";
        $people11->save();

        // $people0 = new People();
        // $people0->name = "NOMBRES";
        // $people0->last_name = "APELLIDOS";
        // $people0->position = "PUESTO";
        // $people0->tel = "+52";
        // $people0->mail = "@gruponovelty.com";
        // $people0->obs = "";
        // $people0->save();

        // $people0 = new People();
        // $people0->name = "NOMBRES";
        // $people0->last_name = "APELLIDOS";
        // $people0->position = "PUESTO";
        // $people0->tel = "+52";
        // $people0->mail = "@gruponovelty.com";
        // $people0->obs = "";
        // $people0->save();
        
    }
}
