<?php

namespace Database\Seeders;

use App\Models\Manufacturer;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class ManufacturerSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run()
    {
        $manufacturer01 = new Manufacturer();
        $manufacturer01->des = "HP";
        $manufacturer01->obs = "HP es una empresa tecnológica estadounidense que fabrica y vende hardware, software y servicios informáticos a nivel mundial.";
        $manufacturer01->save();

        $manufacturer02 = new Manufacturer();
        $manufacturer02->des = "Lenovo";
        $manufacturer02->obs = "Lenovo es una empresa china de tecnología que fabrica y vende productos electrónicos, dispositivos móviles, servidores y servicios informáticos en todo el mundo.";
        $manufacturer02->save();

        $manufacturer03 = new Manufacturer();
        $manufacturer03->des = "Dell";
        $manufacturer03->obs = "Dell es una empresa estadounidense que fabrica y vende computadoras personales, servidores, almacenamiento de datos y soluciones de tecnología empresarial.";
        $manufacturer03->save();

        $manufacturer04 = new Manufacturer();
        $manufacturer04->des = "Tenda";
        $manufacturer04->obs = "Tenda es una marca china de dispositivos de red, incluyendo routers, extensores de rango, switches y adaptadores de red.";
        $manufacturer04->save();

        $manufacturer05 = new Manufacturer();
        $manufacturer05->des = "Cisco";
        $manufacturer05->obs = "Cisco es una empresa estadounidense de tecnología que fabrica y vende dispositivos de red, software y servicios para empresas y proveedores de servicios.";
        $manufacturer05->save();

        $manufacturer06 = new Manufacturer();
        $manufacturer06->des = "Linksys";
        $manufacturer06->obs = "Linksys es una empresa estadounidense que fabrica y vende productos de red para el hogar y pequeñas empresas, como routers, switches y extensores de rango inalámbricos.";
        $manufacturer06->save();

        $manufacturer07 = new Manufacturer();
        $manufacturer07->des = "Huawei";
        $manufacturer07->obs = "Huawei es una empresa china de tecnología que fabrica y vende dispositivos móviles, equipos de red, servidores, software y soluciones empresariales a nivel mundial.";
        $manufacturer07->save();

        $manufacturer08 = new Manufacturer();
        $manufacturer08->des = "Sony";
        $manufacturer08->obs = "Sony es una empresa japonesa de tecnología que fabrica y vende productos electrónicos de consumo, equipos de entretenimiento, productos de audio y video y servicios de entretenimiento.";
        $manufacturer08->save();

        $manufacturer09 = new Manufacturer();
        $manufacturer09->des = "Steren";
        $manufacturer09->obs = "Steren es una marca mexicana de productos electrónicos y accesorios, incluyendo cables, adaptadores, cargadores y sistemas de audio y video.";
        $manufacturer09->save();

        $manufacturer10 = new Manufacturer();
        $manufacturer10->des = "Dahua";
        $manufacturer10->obs = "Dahua es una empresa china que fabrica y vende sistemas de videovigilancia y seguridad, incluyendo cámaras, grabadores de video y software de gestión de seguridad.";
        $manufacturer10->save();

        $manufacturer11 = new Manufacturer();
        $manufacturer11->des = "Samsung";
        $manufacturer11->obs = "Samsung es una reconocida marca multinacional que ofrece una amplia gama de productos electrónicos, como teléfonos inteligentes, televisores, electrodomésticos y dispositivos innovadores con calidad, diseño y tecnología líderes en el mercado.";
        $manufacturer11->save();

        $manufacturer12 = new Manufacturer();
        $manufacturer12->des = "Intel";
        $manufacturer12->obs = "Intel es una destacada marca líder en el campo de los semiconductores y tecnología informática, conocida por sus procesadores innovadores, rendimiento confiable y contribuciones significativas al avance de la informática y la conectividad global.";
        $manufacturer12->save();

        $manufacturer13 = new Manufacturer();
        $manufacturer13->des = "AMD";
        $manufacturer13->obs = "AMD es una destacada marca en la industria de los procesadores y tarjetas gráficas, reconocida por su innovación, rendimiento superior y opciones accesibles que desafían a la competencia y satisfacen las necesidades de los usuarios exigentes.";
        $manufacturer13->save();

        $manufacturer14 = new Manufacturer();
        $manufacturer14->des = "Kingston";
        $manufacturer14->obs = "Kingston es una reconocida marca de tecnología que ofrece soluciones de almacenamiento confiables y de alto rendimiento para dispositivos electrónicos y computadoras.";
        $manufacturer14->save();

        $manufacturer15 = new Manufacturer();
        $manufacturer15->des = "Microsoft";
        $manufacturer15->obs = "Microsoft es una empresa líder en tecnología que desarrolla software, sistemas operativos y servicios en la nube, brindando soluciones innovadoras y herramientas para empresas y consumidores.";
        $manufacturer15->save();

        $manufacturer16 = new Manufacturer();
        $manufacturer16->des = "Kaspersky";
        $manufacturer16->obs = "Kaspersky es una destacada marca de seguridad cibernética, que ofrece soluciones y productos confiables para proteger dispositivos y datos contra amenazas y ataques informáticos.";
        $manufacturer16->save();

        $manufacturer17 = new Manufacturer();
        $manufacturer17->des = "Western Digital";
        $manufacturer17->obs = "Western Digital es una reconocida marca especializada en soluciones de almacenamiento, como discos duros, SSD y unidades flash, ofreciendo innovación, fiabilidad y rendimiento.";
        $manufacturer17->save();

        $manufacturer18 = new Manufacturer();
        $manufacturer18->des = "Broadcom";
        $manufacturer18->obs = "Broadcom es una compañía líder en tecnología y semiconductores, especializada en soluciones de conectividad inalámbrica, redes, almacenamiento y electrónica para diversas industrias.";
        $manufacturer18->save();

        $manufacturer19 = new Manufacturer();
        $manufacturer19->des = "Micron";
        $manufacturer19->obs = "Micron es una marca líder en semiconductores y tecnología de memoria. Ofrece soluciones innovadoras para almacenamiento y rendimiento, destacando en la industria tecnológica global.";
        $manufacturer19->save();

        $manufacturer20 = new Manufacturer();
        $manufacturer20->des = "SK Hynix";
        $manufacturer20->obs = "SK Hynix es una empresa líder en semiconductores, con sede en Corea del Sur. Se especializa en la fabricación de memorias y soluciones de almacenamiento innovadoras.";
        $manufacturer20->save();

        $manufacturer21 = new Manufacturer();
        $manufacturer21->des = "Realtek";
        $manufacturer21->obs = "Realtek es un fabricante de chips y componentes de audio y red. Sus productos se utilizan ampliamente en tarjetas de sonido y adaptadores Ethernet en computadoras y dispositivos electrónicos.";
        $manufacturer21->save();

        $manufacturer22 = new Manufacturer();
        $manufacturer22->des = "Patriot Signature";
        $manufacturer22->obs = "Patriot Signature es una marca reconocida por sus productos de memoria, almacenamiento y accesorios informáticos de calidad, ofreciendo soluciones confiables y de alto rendimiento para usuarios y entusiastas de la tecnología.";
        $manufacturer22->save();

        $manufacturer23 = new Manufacturer();
        $manufacturer23->des = "ADATA";
        $manufacturer23->obs = "ADATA es una marca líder en soluciones de almacenamiento y memoria, que ofrece productos innovadores como SSD, módulos de RAM y accesorios tecnológicos de alta calidad y rendimiento.";
        $manufacturer23->save();

        $manufacturer24 = new Manufacturer();
        $manufacturer24->des = "Ramaxel";
        $manufacturer24->obs = "Ramaxel es una marca especializada en la fabricación de módulos de memoria RAM confiables y de alto rendimiento, utilizados en computadoras y dispositivos electrónicos para mejorar su capacidad de procesamiento.";
        $manufacturer24->save();

        $manufacturer25 = new Manufacturer();
        $manufacturer25->des = "Google";
        $manufacturer25->obs = "Google es una destacada empresa tecnológica global, reconocida por su motor de búsqueda líder, servicios en la nube, Android y avances en IA, transformando la forma en que interactuamos con la información.";
        $manufacturer25->save();

        $manufacturer26 = new Manufacturer();
        $manufacturer26->des = "Hyundai Electronics";
        $manufacturer26->obs = "Hyundai Electronics es una división de Hyundai Corporation, un conglomerado surcoreano. Se especializa en la fabricación y distribución de productos electrónicos de consumo, como televisores, monitores, dispositivos de almacenamiento y electrodomésticos. Con una sólida reputación por la calidad y la innovación, Hyundai Electronics ofrece soluciones tecnológicas confiables a nivel global.";
        $manufacturer26->save();

        $manufacturer27 = new Manufacturer();
        $manufacturer27->des = "Seagate";
        $manufacturer27->obs = "Seagate es una marca líder en tecnología de almacenamiento. Ofrece discos duros y unidades de estado sólido confiables y de alto rendimiento para almacenar datos de consumidores y empresas. Con décadas de experiencia, Seagate es conocida por su innovación en soluciones de almacenamiento, respaldando la digitalización global.";
        $manufacturer27->save();

        $manufacturer28 = new Manufacturer();
        $manufacturer28->des = "Nanya";
        $manufacturer28->obs = "Nanya es una marca taiwanesa líder en la industria de la memoria y almacenamiento. Es conocida por fabricar módulos de memoria RAM y dispositivos de almacenamiento como SSD y tarjetas de memoria. Nanya se destaca por su calidad y tecnología innovadora en el mercado de la electrónica.";
        $manufacturer28->save();

        $manufacturer29 = new Manufacturer();
        $manufacturer29->des = "Hitachi";
        $manufacturer29->obs = "Hitachi es una destacada empresa japonesa con una amplia gama de productos y servicios, desde electrónica de consumo hasta infraestructura industrial. Reconocida por su innovación en tecnologías como la energía, ferrocarriles y electrónica, Hitachi es sinónimo de calidad, confiabilidad y contribución a la sociedad global.";
        $manufacturer29->save();

        $manufacturer30 = new Manufacturer();
        $manufacturer30->des = "Synchronous";
        $manufacturer30->obs = "Synchronous es una marca innovadora que se especializa en tecnología de comunicación y sincronización. Ofrecen productos y soluciones de vanguardia que conectan dispositivos y sistemas de manera eficiente, mejorando la colaboración y la eficiencia en entornos empresariales y de consumo. Su enfoque es la conectividad inteligente y la simplicidad.";
        $manufacturer30->save();
    }

}
