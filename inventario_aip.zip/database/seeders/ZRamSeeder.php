<?php

namespace Database\Seeders;

use App\Models\Ram;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class ZRamSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $ram01 = new Ram();
        $ram01->interface = "DDR3";
        $ram01->speed = "1333 MHz";
        $ram01->capacity = "4 GB";
        $ram01->asset_id = 1;
        $ram01->manufacturer_id = 11;
        $ram01->obs = "";
        $ram01->save();

        $ram02 = new Ram();
        $ram02->interface = "DDR3";
        $ram02->speed = "1600 MHz";
        $ram02->capacity = "8 GB";
        $ram02->asset_id = 1;
        $ram02->manufacturer_id = 20;
        $ram02->obs = "";
        $ram02->save();

        $ram03 = new Ram();
        $ram03->interface = "DDR3";
        $ram03->speed = "1333 MHz";
        $ram03->capacity = "4 GB";
        $ram03->asset_id = 2;
        $ram03->manufacturer_id = 11;
        $ram03->obs = "";
        $ram03->save();

        $ram04 = new Ram();
        $ram04->interface = "DDR3";
        $ram04->speed = "1600 MHz";
        $ram04->capacity = "2 GB";
        $ram04->asset_id = 2;
        $ram04->manufacturer_id = 14;
        $ram04->obs = "";
        $ram04->save();

        $ram05 = new Ram();
        $ram05->interface = "DDR3";
        $ram05->speed = "1333 MHz";
        $ram05->capacity = "2 GB";
        $ram05->asset_id = 2;
        $ram05->manufacturer_id = 11;
        $ram05->obs = "";
        $ram05->save();

        $ram06 = new Ram();
        $ram06->interface = "DDR3";
        $ram06->speed = "1333 MHz";
        $ram06->capacity = "2 GB";
        $ram06->asset_id = 2;
        $ram06->manufacturer_id = 28;
        $ram06->obs = "";
        $ram06->save();

        // Diana
        $ram07 = new Ram();
        $ram07->interface = "DDR4";
        $ram07->speed = "2400 MHz";
        $ram07->capacity = "8 GB";
        $ram07->asset_id = 3;
        $ram07->manufacturer_id = 26;
        $ram07->obs = "";
        $ram07->save();

        // Gera
        $ram08 = new Ram();
        $ram08->interface = "DDR4";
        $ram08->speed = "2666 MHz";
        $ram08->capacity = "8 GB";
        $ram08->asset_id = 4;
        $ram08->manufacturer_id = 11;
        $ram08->obs = "";
        $ram08->save();

        // Valeria
        $ram09 = new Ram();
        $ram09->interface = "DDR4";
        $ram09->speed = "2400 MHz";
        $ram09->capacity = "8 GB";
        $ram09->asset_id = 5;
        $ram09->manufacturer_id = 26;
        $ram09->obs = "";
        $ram09->save();

        // Janeth
        $ram10 = new Ram();
        $ram10->interface = "DDR4";
        $ram10->speed = "2400 MHz";
        $ram10->capacity = "8 GB";
        $ram10->asset_id = 6;
        $ram10->manufacturer_id = 11;
        $ram10->obs = "";
        $ram10->save();

        // Caro
        $ram11 = new Ram();
        $ram11->interface = "DDR4";
        $ram11->speed = "2400 MHz";
        $ram11->capacity = "8 GB";
        $ram11->asset_id = 7;
        $ram11->manufacturer_id = 19;
        $ram11->obs = "";
        $ram11->save();

        // Valentín
        $ram12 = new Ram();
        $ram12->interface = "DDR3";
        $ram12->speed = "1600 MHz";
        $ram12->capacity = "8 GB";
        $ram12->asset_id = 8;
        $ram12->manufacturer_id = 11;
        $ram12->obs = "";
        $ram12->save();

        // Gaby
        $ram13 = new Ram();
        $ram13->interface = "DDR3";
        $ram13->speed = "1600 MHz";
        $ram13->capacity = "8 GB";
        $ram13->asset_id = 9;
        $ram13->manufacturer_id = 26;
        $ram13->obs = "";
        $ram13->save();

        // Paty
        $ram14 = new Ram();
        $ram14->interface = "DDR3";
        $ram14->speed = "1334 MHz";
        $ram14->capacity = "4 GB";
        $ram14->asset_id = 10;
        $ram14->manufacturer_id = 19;
        $ram14->obs = "";
        $ram14->save();

        $ram15 = new Ram();
        $ram15->interface = "DDR3";
        $ram15->speed = "1334 MHz";
        $ram15->capacity = "2 GB";
        $ram15->asset_id = 10;
        $ram15->manufacturer_id = 11;
        $ram15->obs = "";
        $ram15->save();

        // Ivan
        $ram16 = new Ram();
        $ram16->interface = "DDR4";
        $ram16->speed = "2400 MHz";
        $ram16->capacity = "8 GB";
        $ram16->asset_id = 11;
        $ram16->manufacturer_id = 19;
        $ram16->obs = "";
        $ram16->save();

        // Juntas
        $ram17 = new Ram();
        $ram17->interface = "DDR4";
        $ram17->speed = "3200 MHz";
        $ram17->capacity = "8 GB";
        $ram17->asset_id = 12;
        $ram17->manufacturer_id = 30;
        $ram17->obs = "";
        $ram17->save();




    }
}
