<?php

namespace Database\Seeders;

use App\Models\Storage;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class ZStorageSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $storage01 = new Storage();
        $storage01->type = "SSD";
        $storage01->interface = "SATA";
        $storage01->capacity = "476 GB";
        $storage01->asset_id = 1;
        $storage01->manufacturer_id = 23;
        $storage01->obs = "Disco Local (C)";
        $storage01->save();

        $storage02 = new Storage();
        $storage02->type = "HDD";
        $storage02->interface = "SATA";
        $storage02->capacity = "1862 GB";
        $storage02->asset_id = 1;
        $storage02->manufacturer_id = 17;
        $storage02->obs = "BackUp (D,E)";
        $storage02->save();

        $storage03 = new Storage();
        $storage03->type = "HDD";
        $storage03->interface = "SATA";
        $storage03->capacity = "931 GB";
        $storage03->asset_id = 2;
        $storage03->manufacturer_id = 29;
        $storage03->obs = "DiscoLocal (C)";
        $storage03->save();

        $storage04 = new Storage();
        $storage04->type = "HDD";
        $storage04->interface = "SATA";
        $storage04->capacity = "1810 GB";
        $storage04->asset_id = 2;
        $storage04->manufacturer_id = 17;
        $storage04->obs = "BackUpLocal (D)";
        $storage04->save();

        $storage05 = new Storage();
        $storage05->type = "HDD";
        $storage05->interface = "SATA";
        $storage05->capacity = "931 GB";
        $storage05->asset_id = 2;
        $storage05->manufacturer_id = 29;
        $storage05->obs = "BackUpOD (E)";
        $storage05->save();

        // Diana
        $storage06 = new Storage();
        $storage06->type = "SSD";
        $storage06->interface = "SATA";
        $storage06->capacity = "480 GB";
        $storage06->asset_id = 3;
        $storage06->manufacturer_id = 14;
        $storage06->obs = "Disco Local (C:)";
        $storage06->save();

        // Gera
        $storage07 = new Storage();
        $storage07->type = "SSD";
        $storage07->interface = "SATA";
        $storage07->capacity = "512 GB";
        $storage07->asset_id = 4;
        $storage07->manufacturer_id = 23;
        $storage07->obs = "Disco Local (C:)";
        $storage07->save();

        // Valeria
        $storage08 = new Storage();
        $storage08->type = "SSD";
        $storage08->interface = "SATA";
        $storage08->capacity = "480 GB";
        $storage08->asset_id = 5;
        $storage08->manufacturer_id = 14;
        $storage08->obs = "Disco Local (C:)";
        $storage08->save();

        // Janeth
        $storage09 = new Storage();
        $storage09->type = "SSD";
        $storage09->interface = "SATA";
        $storage09->capacity = "480 GB";
        $storage09->asset_id = 6;
        $storage09->manufacturer_id = 23;
        $storage09->obs = "Disco Local (C:)";
        $storage09->save();

        // Caro
        $storage10 = new Storage();
        $storage10->type = "SSD";
        $storage10->interface = "SATA";
        $storage10->capacity = "480 GB";
        $storage10->asset_id = 7;
        $storage10->manufacturer_id = 14;
        $storage10->obs = "Disco Local (C:)";
        $storage10->save();

        // Valentín
        $storage11 = new Storage();
        $storage11->type = "SSD";
        $storage11->interface = "SATA";
        $storage11->capacity = "480 GB";
        $storage11->asset_id = 8;
        $storage11->manufacturer_id = 14;
        $storage11->obs = "Disco Local (C:)";
        $storage11->save();

        // Gaby
        $storage12 = new Storage();
        $storage12->type = "SSD";
        $storage12->interface = "SATA";
        $storage12->capacity = "480 GB";
        $storage12->asset_id = 9;
        $storage12->manufacturer_id = 14;
        $storage12->obs = "Disco Local (C:)";
        $storage12->save();

        // Paty
        $storage13 = new Storage();
        $storage13->type = "SSD";
        $storage13->interface = "SATA";
        $storage13->capacity = "480 GB";
        $storage13->asset_id = 10;
        $storage13->manufacturer_id = 14;
        $storage13->obs = "Disco Local (C)";
        $storage13->save();

        // Ivan
        $storage14 = new Storage();
        $storage14->type = "SSD";
        $storage14->interface = "SATA";
        $storage14->capacity = "480 GB";
        $storage14->asset_id = 11;
        $storage14->manufacturer_id = 14;
        $storage14->obs = "Disco Local (C)";
        $storage14->save();

        // Juntas
        $storage15 = new Storage();
        $storage15->type = "SSD";
        $storage15->interface = "M.2 NVMe";
        $storage15->capacity = "256 GB";
        $storage15->asset_id = 12;
        $storage15->manufacturer_id = 20;
        $storage15->obs = "Disco Local (C)";
        $storage15->save();

    }
}
