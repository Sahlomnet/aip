<?php

namespace Database\Seeders;

use App\Models\Company;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class ZCompanySeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $company = new Company();
        $company->name = "Novelty Corporativo";
        $company->short_name = "NC";
        $company->business_name = "Novelty Corporativo";
        $company->rfc = "NCO161222G30";
        $company->tax_regime = "601 - General de Ley Personas Morales";
        $company->street = "Guayaquil";
        $company->ext_number = "2654";
        $company->int_number = NULL;
        $company->col = "Providencia 3ra Sección";
        $company->city = "Guadalajara";
        $company->mun = "Guadalajara";
        $company->state = "Jalisco";
        $company->country = "México";
        $company->zip_code = "44630";
        $company->obs = NULL;
        $company->save();
    }
}
