<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use App\Models\Ram;

class RamSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $ram01 = new Ram();
        $ram01->interface = "DDR3";
        $ram01->speed = "1333 MHz";
        $ram01->capacity = "2 GB";
        $ram01->asset_id = 1;
        $ram01->manufacturer_id = 19;
        $ram01->obs = "";
        $ram01->save();

        $ram02 = new Ram();
        $ram02->interface = "DDR3";
        $ram02->speed = "1333 MHz";
        $ram02->capacity = "2 GB";
        $ram02->asset_id = 1;
        $ram02->manufacturer_id = 11;
        $ram02->obs = "";
        $ram02->save();

        $ram03 = new Ram();
        $ram03->interface = "DDR4";
        $ram03->speed = "2400 MHz";
        $ram03->capacity = "8 GB";
        $ram03->asset_id = 2;
        $ram03->manufacturer_id = 11;
        $ram03->obs = "";
        $ram03->save();

        $ram04 = new Ram();
        $ram04->interface = "DDR4";
        $ram04->speed = "2400 MHz";
        $ram04->capacity = "8 GB";
        $ram04->asset_id = 2;
        $ram04->manufacturer_id = 11;
        $ram04->obs = "";
        $ram04->save();

        $ram05 = new Ram();
        $ram05->interface = "DDR4";
        $ram05->speed = "2400 MHz";
        $ram05->capacity = "8 GB";
        $ram05->asset_id = 2;
        $ram05->manufacturer_id = 11;
        $ram05->obs = "";
        $ram05->save();

        $ram06 = new Ram();
        $ram06->interface = "DDR4";
        $ram06->speed = "2400 MHz";
        $ram06->capacity = "8 GB";
        $ram06->asset_id = 2;
        $ram06->manufacturer_id = 11;
        $ram06->obs = "";
        $ram06->save();

        $ram07 = new Ram();
        $ram07->interface = "DDR4";
        $ram07->speed = "2666 MHz";
        $ram07->capacity = "4 GB";
        $ram07->asset_id = 3;
        $ram07->manufacturer_id = 11;
        $ram07->obs = "";
        $ram07->save();

        $ram08 = new Ram();
        $ram08->interface = "DDR4";
        $ram08->speed = "2666 MHz";
        $ram08->capacity = "4 GB";
        $ram08->asset_id = 3;
        $ram08->manufacturer_id = 11;
        $ram08->obs = "";
        $ram08->save();

        $ram09 = new Ram();
        $ram09->interface = "DDR4";
        $ram09->speed = "3200 MHz";
        $ram09->capacity = "16 GB";
        $ram09->asset_id = 4;
        $ram09->manufacturer_id = 11;
        $ram09->obs = "";
        $ram09->save();

        $ram10 = new Ram();
        $ram10->interface = "DDR4";
        $ram10->speed = "3200 MHz";
        $ram10->capacity = "8 GB";
        $ram10->asset_id = 5;
        $ram10->manufacturer_id = 19;
        $ram10->obs = "";
        $ram10->save();

        $ram11 = new Ram();
        $ram11->interface = "DDR3";
        $ram11->speed = "1600 MHz";
        $ram11->capacity = "8 GB";
        $ram11->asset_id = 6;
        $ram11->manufacturer_id = 22;
        $ram11->obs = "";
        $ram11->save();

        $ram12 = new Ram();
        $ram12->interface = "DDR3";
        $ram12->speed = "1600 MHz";
        $ram12->capacity = "4 GB";
        $ram12->asset_id = 7;
        $ram12->manufacturer_id = 11;
        $ram12->obs = "";
        $ram12->save();

        $ram13 = new Ram();
        $ram13->interface = "DDR3";
        $ram13->speed = "1600 MHz";
        $ram13->capacity = "4 GB";
        $ram13->asset_id = 7;
        $ram13->manufacturer_id = 23;
        $ram13->obs = "";
        $ram13->save();

        $ram14 = new Ram();
        $ram14->interface = "DDR4";
        $ram14->speed = "3200 MHz";
        $ram14->capacity = "8 GB";
        $ram14->asset_id = 8;
        $ram14->manufacturer_id = 24;
        $ram14->obs = "";
        $ram14->save();

        $ram15 = new Ram();
        $ram15->interface = "DDR4";
        $ram15->speed = "3200 MHz";
        $ram15->capacity = "16 GB";
        $ram15->asset_id = 9;
        $ram15->manufacturer_id = 11;
        $ram15->obs = "";
        $ram15->save();

        $ram16 = new Ram();
        $ram16->interface = "DDR3";
        $ram16->speed = "1600 MHz";
        $ram16->capacity = "4 GB";
        $ram16->asset_id = 10;
        $ram16->manufacturer_id = 24;
        $ram16->obs = "";
        $ram16->save();

        $ram17 = new Ram();
        $ram17->interface = "DDR4";
        $ram17->speed = "2667 MHz";
        $ram17->capacity = "4 GB";
        $ram17->asset_id = 11;
        $ram17->manufacturer_id = 11;
        $ram17->obs = "";
        $ram17->save();

        $ram18 = new Ram();
        $ram18->interface = "DDR4";
        $ram18->speed = "2667 MHz";
        $ram18->capacity = "4 GB";
        $ram18->asset_id = 11;
        $ram18->manufacturer_id = 11;
        $ram18->obs = "";
        $ram18->save();

        $ram19 = new Ram();
        $ram19->interface = "DDR4";
        $ram19->speed = "2667 MHz";
        $ram19->capacity = "4 GB";
        $ram19->asset_id = 12;
        $ram19->manufacturer_id = 11;
        $ram19->obs = "";
        $ram19->save();

        $ram20 = new Ram();
        $ram20->interface = "DDR4";
        $ram20->speed = "2667 MHz";
        $ram20->capacity = "4 GB";
        $ram20->asset_id = 12;
        $ram20->manufacturer_id = 11;
        $ram20->obs = "";
        $ram20->save();

        $ram21 = new Ram();
        $ram21->interface = "DDR4";
        $ram21->speed = "2667 MHz";
        $ram21->capacity = "8 GB";
        $ram21->asset_id = 13;
        $ram21->manufacturer_id = 20;
        $ram21->obs = "";
        $ram21->save();

        $ram22 = new Ram();
        $ram22->interface = "DDR4";
        $ram22->speed = "2667 MHz";
        $ram22->capacity = "8 GB";
        $ram22->asset_id = 13;
        $ram22->manufacturer_id = 20;
        $ram22->obs = "";
        $ram22->save();

        $ram23 = new Ram();
        $ram23->interface = "DDR4";
        $ram23->speed = "3200 MHz";
        $ram23->capacity = "4 GB";
        $ram23->asset_id = 14;
        $ram23->manufacturer_id = 11;
        $ram23->obs = "";
        $ram23->save();

        $ram24 = new Ram();
        $ram24->interface = "DDR4";
        $ram24->speed = "3200 MHz";
        $ram24->capacity = "4 GB";
        $ram24->asset_id = 14;
        $ram24->manufacturer_id = 11;
        $ram24->obs = "";
        $ram24->save();

        $ram25 = new Ram();
        $ram25->interface = "DDR3";
        $ram25->speed = "1600 MHz";
        $ram25->capacity = "8 GB";
        $ram25->asset_id = 15;
        $ram25->manufacturer_id = 14;
        $ram25->obs = "";
        $ram25->save();

        $ram26 = new Ram();
        $ram26->interface = "DDR3";
        $ram26->speed = "1334 MHz";
        $ram26->capacity = "4 GB";
        $ram26->asset_id = 15;
        $ram26->manufacturer_id = 14;
        $ram26->obs = "";
        $ram26->save();
        
        $ram27 = new Ram();
        $ram27->interface = "DDR4";
        $ram27->speed = "2667 MHz";
        $ram27->capacity = "4 GB";
        $ram27->asset_id = 16;
        $ram27->manufacturer_id = 11;
        $ram27->obs = "";
        $ram27->save();

        $ram28 = new Ram();
        $ram28->interface = "DDR4";
        $ram28->speed = "2667 MHz";
        $ram28->capacity = "4 GB";
        $ram28->asset_id = 16;
        $ram28->manufacturer_id = 11;
        $ram28->obs = "";
        $ram28->save();

        $ram29 = new Ram();
        $ram29->interface = "DDR4";
        $ram29->speed = "3200 MHz";
        $ram29->capacity = "16 GB";
        $ram29->asset_id = 17;
        $ram29->manufacturer_id = 11;
        $ram29->obs = "";
        $ram29->save();

        $ram30 = new Ram();
        $ram30->interface = "DDR4";
        $ram30->speed = "3200 MHz";
        $ram30->capacity = "16 GB";
        $ram30->asset_id = 17;
        $ram30->manufacturer_id = 11;
        $ram30->obs = "";
        $ram30->save();

        $ram31 = new Ram();
        $ram31->interface = "DDR4";
        $ram31->speed = "3200 MHz";
        $ram31->capacity = "16 GB";
        $ram31->asset_id = 17;
        $ram31->manufacturer_id = 11;
        $ram31->obs = "";
        $ram31->save();

        $ram32 = new Ram();
        $ram32->interface = "DDR4";
        $ram32->speed = "3200 MHz";
        $ram32->capacity = "16 GB";
        $ram32->asset_id = 17;
        $ram32->manufacturer_id = 11;
        $ram32->obs = "";
        $ram32->save();

        $ram33 = new Ram();
        $ram33->interface = "DDR3";
        $ram33->speed = "1600 MHz";
        $ram33->capacity = "4 GB";
        $ram33->asset_id = 18;
        $ram33->manufacturer_id = 14;
        $ram33->obs = "";
        $ram33->save();

        $ram34 = new Ram();
        $ram34->interface = "DDR3";
        $ram34->speed = "1600 MHz";
        $ram34->capacity = "4 GB";
        $ram34->asset_id = 18;
        $ram34->manufacturer_id = 26;
        $ram34->obs = "";
        $ram34->save();

        $ram35 = new Ram();
        $ram35->interface = "DDR3";
        $ram35->speed = "1333 MHz";
        $ram35->capacity = "4 GB";
        $ram35->asset_id = 19;
        $ram35->manufacturer_id = 1;
        $ram35->obs = "";
        $ram35->save();

        $ram36 = new Ram();
        $ram36->interface = "DDR3";
        $ram36->speed = "1600 MHz";
        $ram36->capacity = "8 GB";
        $ram36->asset_id = 19;
        $ram36->manufacturer_id = 14;
        $ram36->obs = "";
        $ram36->save();

        $ram37 = new Ram();
        $ram37->interface = "DDR3";
        $ram37->speed = "1333 MHz";
        $ram37->capacity = "4 GB";
        $ram37->asset_id = 19;
        $ram37->manufacturer_id = 1;
        $ram37->obs = "";
        $ram37->save();



        $ram99 = new Ram();
        $ram99->interface = "DDR3";
        $ram99->speed = "1600 MHz";
        $ram99->capacity = "4 GB";
        $ram99->asset_id = 62;
        $ram99->manufacturer_id = 24;
        $ram99->obs = "";
        $ram99->save();
    }
}
