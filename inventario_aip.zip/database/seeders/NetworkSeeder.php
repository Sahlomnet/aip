<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use App\Models\Network;

class NetworkSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        
        $network01= new Network();
        $network01->type = "Ethernet";
        $network01->mac = "E4:11:5B:B3:2C:24";
        $network01->ip = "192.168.0.91";
        $network01->asset_id = 1;
        $network01->manufacturer_id = 12;
        $network01->obs = "";
        $network01->save();

        $network02= new Network();
        $network02->type = "Ethernet";
        $network02->mac = "E4:11:5B:B3:2C:25";
        $network02->ip = "192.168.0.191";
        $network02->asset_id = 1;
        $network02->manufacturer_id = 12;
        $network02->obs = "";
        $network02->save();

        $network03= new Network();
        $network03->type = "Ethernet";
        $network03->mac = "EC:EB:B8:F8:4B:E8";
        $network03->ip = "192.168.0.92";
        $network03->asset_id = 2;
        $network03->manufacturer_id = 18;
        $network03->obs = "";
        $network03->save();

        $network04= new Network();
        $network04->type = "Ethernet";
        $network04->mac = "EC:EB:B8:F8:4B:E9";
        $network04->ip = "192.168.0.192";
        $network04->asset_id = 2;
        $network04->manufacturer_id = 18;
        $network04->obs = "";
        $network04->save();

        $network05= new Network();
        $network05->type = "Ethernet";
        $network05->mac = "2C:F0:5D:52:5A:75";
        $network05->ip = "192.168.0.101";
        $network05->asset_id = 3;
        $network05->manufacturer_id = 21;
        $network05->obs = "";
        $network05->save();

        $network06= new Network();
        $network06->type = "WiFi";
        $network06->mac = "30:C9:AB:D3:B9:31";
        $network06->ip = "192.168.0.102";
        $network06->asset_id = 3;
        $network06->manufacturer_id = 21;
        $network06->obs = "";
        $network06->save();

        $network07= new Network();
        $network07->type = "Ethernet";
        $network07->mac = "9C:2D:CD:E3:AB:07";
        $network07->ip = "192.168.0.103";
        $network07->asset_id = 4;
        $network07->manufacturer_id = 12;
        $network07->obs = "";
        $network07->save();

        $network08= new Network();
        $network08->type = "WiFi";
        $network08->mac = "AC:5A:FC:63:F0:0B";
        $network08->ip = "192.168.0.104";
        $network08->asset_id = 4;
        $network08->manufacturer_id = 12;
        $network08->obs = "";
        $network08->save();

        $network09= new Network();
        $network09->type = "Ethernet";
        $network09->mac = "00:D8:61:F2:3F:CB";
        $network09->ip = "192.168.0.105";
        $network09->asset_id = 5;
        $network09->manufacturer_id = 21;
        $network09->obs = "";
        $network09->save();


        $network10= new Network();
        $network10->type = "Ethernet";
        $network10->mac = "FC:4D:D4:4A:3E:C5";
        $network10->ip = "192.168.0.107";
        $network10->asset_id = 6;
        $network10->manufacturer_id = 12;
        $network10->obs = "";
        $network10->save();


        $network11= new Network();
        $network11->type = "Ethernet";
        $network11->mac = "FC:4D:D4:D3:09:04";
        $network11->ip = "192.168.0.109";
        $network11->asset_id = 7;
        $network11->manufacturer_id = 12;
        $network11->obs = "";
        $network11->save();

        $network12= new Network();
        $network12->type = "Ethernet";
        $network12->mac = "E8:80:88:23:44:12";
        $network12->ip = "192.168.0.111";
        $network12->asset_id = 8;
        $network12->manufacturer_id = 12;
        $network12->obs = "";
        $network12->save();

        $network13= new Network();
        $network13->type = "WiFi";
        $network13->mac = "30:89:4A:77:BC:35";
        $network13->ip = "192.168.0.112";
        $network13->asset_id = 8;
        $network13->manufacturer_id = 12;
        $network13->obs = "";
        $network13->save();

        $network14= new Network();
        $network14->type = "Ethernet";
        $network14->mac = "9C:2D:CD:E3:AA:B7";
        $network14->ip = "192.168.0.113";
        $network14->asset_id = 9;
        $network14->manufacturer_id = 12;
        $network14->obs = "";
        $network14->save();

        $network15= new Network();
        $network15->type = "WiFi";
        $network15->mac = "AC:5A:FC:63:F7:77";
        $network15->ip = "192.168.0.114";
        $network15->asset_id = 9;
        $network15->manufacturer_id = 12;
        $network15->obs = "";
        $network15->save();

        $network16= new Network();
        $network16->type = "Ethernet";
        $network16->mac = "44:8A:5B:03:26:21";
        $network16->ip = "192.168.0.115";
        $network16->asset_id = 10;
        $network16->manufacturer_id = 21;
        $network16->obs = "";
        $network16->save();

        $network17= new Network();
        $network17->type = "Ethernet";
        $network17->mac = "2C:F0:5D:52:F0:D4";
        $network17->ip = "192.168.0.117";
        $network17->asset_id = 11;
        $network17->manufacturer_id = 21;
        $network17->obs = "";
        $network17->save();

        $network18= new Network();
        $network18->type = "WiFi";
        $network18->mac = "30:C9:AB:E0:F0:1D";
        $network18->ip = "192.168.0.118";
        $network18->asset_id = 11;
        $network18->manufacturer_id = 21;
        $network18->obs = "";
        $network18->save();

        $network19= new Network();
        $network19->type = "Ethernet";
        $network19->mac = "2C:F0:5D:52:F0:F1";
        $network19->ip = "192.168.0.119";
        $network19->asset_id = 12;
        $network19->manufacturer_id = 21;
        $network19->obs = "";
        $network19->save();

        $network20= new Network();
        $network20->type = "WiFi";
        $network20->mac = "30:C9:AB:E0:EF:A9";
        $network20->ip = "192.168.0.120";
        $network20->asset_id = 12;
        $network20->manufacturer_id = 21;
        $network20->obs = "";
        $network20->save();

        $network21= new Network();
        $network21->type = "Ethernet";
        $network21->mac = "6C:4B:90:E2:66:AB";
        $network21->ip = "192.168.0.121";
        $network21->asset_id = 13;
        $network21->manufacturer_id = 12;
        $network21->obs = "";
        $network21->save();

        $network22= new Network();
        $network22->type = "WiFi";
        $network22->mac = "3C:55:76:6C:CD:B1";
        $network22->ip = "192.168.0.124";
        $network22->asset_id = 14;
        $network22->manufacturer_id = 21;
        $network22->obs = "";
        $network22->save();

        $network23= new Network();
        $network23->type = "Ethernet";
        $network23->mac = "44:37:E6:DC:BD:E2";
        $network23->ip = "192.168.0.125";
        $network23->asset_id = 15;
        $network23->manufacturer_id = 21;
        $network23->obs = "";
        $network23->save();

        $network24= new Network();
        $network24->type = "Ethernet";
        $network24->mac = "2C:F0:5D:52:F0:C4";
        $network24->ip = "192.168.0.127";
        $network24->asset_id = 16;
        $network24->manufacturer_id = 21;
        $network24->obs = "";
        $network24->save();

        $network25= new Network();
        $network25->type = "WiFi";
        $network25->mac = "30:C9:AB:DF:A7:65";
        $network25->ip = "192.168.0.128";
        $network25->asset_id = 16;
        $network25->manufacturer_id = 21;
        $network25->obs = "";
        $network25->save();

        $network26= new Network();
        $network26->type = "Ethernet";
        $network26->mac = "1C:69:7A:49:D7:43";
        $network26->ip = "192.168.0.129";
        $network26->asset_id = 17;
        $network26->manufacturer_id = 21;
        $network26->obs = "";
        $network26->save();

        $network27= new Network();
        $network27->type = "Ethernet";
        $network27->mac = "54:EE:75:78:7E:C2";
        $network27->ip = "192.168.0.131";
        $network27->asset_id = 18;
        $network27->manufacturer_id = 12;
        $network27->obs = "";
        $network27->save();

        $network28= new Network();
        $network28->type = "WiFi";
        $network28->mac = "A4:C4:94:BE:97:FE";
        $network28->ip = "192.168.0.132";
        $network28->asset_id = 18;
        $network28->manufacturer_id = 12;
        $network28->obs = "";
        $network28->save();

        $network29= new Network();
        $network29->type = "Ethernet";
        $network29->mac = "9C:B6:54:12:7D:9C";
        $network29->ip = "192.168.1.91";
        $network29->asset_id = 19;
        $network29->manufacturer_id = 18;
        $network29->obs = "";
        $network29->save();

        $network30= new Network();
        $network30->type = "Ethernet";
        $network30->mac = "9C:B6:54:12:7D:9D";
        $network30->ip = "192.168.1.191";
        $network30->asset_id = 19;
        $network30->manufacturer_id = 18;
        $network30->obs = "";
        $network30->save();

        $network99= new Network();
        $network99->type = "Ethernet";
        $network99->mac = "FC:4D:D4:4A:3E:C1";
        $network99->ip = "192.168.3.101";
        $network99->asset_id = 62;
        $network99->manufacturer_id = 12;
        $network99->obs = "";
        $network99->save();



    }
}
