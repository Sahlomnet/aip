<?php

namespace Database\Seeders;

use App\Models\Usage;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class UsageSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $usage01 = new Usage();
        $usage01->des = "Personal";
        $usage01->obs = "Para uso Personal";
        $usage01->save();

        $usage02 = new Usage();
        $usage02->des = "Compartido";
        $usage02->obs = "Para uso Compartido";
        $usage02->save();

        $usage03 = new Usage();
        $usage03->des = "Custodia";
        $usage03->obs = "En Custodia";
        $usage03->save();
    }
}
