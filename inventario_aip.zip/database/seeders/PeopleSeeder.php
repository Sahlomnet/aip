<?php

namespace Database\Seeders;

use App\Models\People;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class PeopleSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $people01 = new People();
        $people01->name = "Argelia";
        $people01->last_name = "Reyes Ríos";
        $people01->position = "Dirección General 01";
        $people01->tel = "+523311122622";
        $people01->mail = "direccion@lospinos.org";
        $people01->obs = "";
        $people01->save();

        $people02 = new People();
        $people02->name = "Guillermo";
        $people02->last_name = "Aguirre Adame";
        $people02->position = "Procuración de Fondos 01";
        $people02->tel = "+523324941914";
        $people02->mail = "procuracion@lospinos.org";
        $people02->obs = "";
        $people02->save();

        $people03 = new People();
        $people03->name = "Marimar";
        $people03->last_name = "Quiroz Ruelas";
        $people03->position = "Recolección 01";
        $people03->tel = "+523315190435";
        $people03->mail = "recoleccion@lospinos.org";
        $people03->obs = "";
        $people03->save();

        $people04 = new People();
        $people04->name = "Jonathan Rafael";
        $people04->last_name = "Bermejo Medel";
        $people04->position = "Recolección 02";
        $people04->tel = "+523321640312";
        $people04->mail = "rafa.erus27@gmail.com";
        $people04->obs = "";
        $people04->save();

        $people05 = new People();
        $people05->name = "Judith";
        $people05->last_name = "Díaz Vega";
        $people05->position = "Captación 01";
        $people05->tel = "+523310007579";
        $people05->mail = "info@lospinos.org";
        $people05->obs = "";
        $people05->save();

        $people06 = new People();
        $people06->name = "Fanny Amalia";
        $people06->last_name = "Alanís Díaz";
        $people06->position = "Captación 02";
        $people06->tel = "+523339045660";
        $people06->mail = "labor.social2@lospinos.org";
        $people06->obs = "";
        $people06->save();

        $people07 = new People();
        $people07->name = "Karla Paola";
        $people07->last_name = "Flores Martínez";
        $people07->position = "Captación 03";
        $people07->tel = "+523310889005";
        $people07->mail = "labor.social1@lospinos.org";
        $people07->obs = "";
        $people07->save();

        $people08 = new People();
        $people08->name = "Brenda Netze";
        $people08->last_name = "Andrade Alejo";
        $people08->position = "Captación 04";
        $people08->tel = "+523311492849";
        $people08->mail = "labor.social@lospinos.org";
        $people08->obs = "";
        $people08->save();

        $people09 = new People();
        $people09->name = "Vacante";
        $people09->last_name = "Comunicación";
        $people09->position = "Comunicación 01";
        $people09->tel = NULL;
        $people09->mail = NULL;
        $people09->obs = "";
        $people09->save();

        $people10 = new People();
        $people10->name = "Hitomy Edith";
        $people10->last_name = "Matsuda Wilson";
        $people10->position = "Proyectos 01";
        $people10->tel = "+523316980535";
        $people10->mail = "proyectos.sociales@lospinos.org";
        $people10->obs = "";
        $people10->save();

        $people11 = new People();
        $people11->name = "Alejandro Javier";
        $people11->last_name = "Larios Proa";
        $people11->position = "Seguimiento 01";
        $people11->tel = "+524421578034";
        $people11->mail = "seguimiento@lospinos.org";
        $people11->obs = "";
        $people11->save();

        $people12 = new People();
        $people12->name = "Oliver Alberto";
        $people12->last_name = "Domínguez Izaguirre";
        $people12->position = "Seguimiento02";
        $people12->tel = "+523339058977";
        $people12->mail = "oliver_dominguez1@hotmail.com";
        $people12->obs = "";
        $people12->save();

        $people13 = new People();
        $people13->name = "Leticia";
        $people13->last_name = "Rojas Pérez";
        $people13->position = "Seguimiento 03";
        $people13->tel = "+523314171047";
        $people13->mail = "lety_rojas_perez@hotmail.com";
        $people13->obs = "";
        $people13->save();

        $people14 = new People();
        $people14->name = "Vacante";
        $people14->last_name = "Seguimiento";
        $people14->position = "Seguimiento 04";
        $people14->tel = NULL;
        $people14->mail = NULL;
        $people14->obs = "";
        $people14->save();

        $people15 = new People();
        $people15->name = "Externo";
        $people15->last_name = "Contabilidad";
        $people15->position = "Contabilidad 01";
        $people15->tel = NULL;
        $people15->mail = "contabilidad@lospinos.org";
        $people15->obs = "";
        $people15->save();

        $people16 = new People();
        $people16->name = "Alva Edith";
        $people16->last_name = "Gómez Morales";
        $people16->position = "Contabilidad 02";
        $people16->tel = "+523313474243";
        $people16->mail = "tesoreria@lospinos.org";
        $people16->obs = "";
        $people16->save();

        $people17 = new People();
        $people17->name = "Martha Alicia";
        $people17->last_name = "Pizano Moreno";
        $people17->position = "Contabilidad 03";
        $people17->tel = "+523310276100";
        $people17->mail = "auxiliarcontable.pinos@gmail.com";
        $people17->obs = "";
        $people17->save();

        $people18 = new People();
        $people18->name = "Marcia Suyapa";
        $people18->last_name = "Chiuz Girón";
        $people18->position = "Desarrollo Humano 01";
        $people18->tel = "+523317029009";
        $people18->mail = "desarrollo.humano@lospinos.org";
        $people18->obs = "";
        $people18->save();

        $people19 = new People();
        $people19->name = "Heriberto";
        $people19->last_name = "Muñiz Iglesias";
        $people19->position = "Calidad 01";
        $people19->tel = "+523335085459";
        $people19->mail = "calidad@lospinos.org";
        $people19->obs = "";
        $people19->save();

        $people20 = new People();
        $people20->name = "María de los Ángeles";
        $people20->last_name = "Ramírez Guzmán";
        $people20->position = "Nutrición 02";
        $people20->tel = "+523339048556";
        $people20->mail = "nutricion.pinos@hotmail.es";
        $people20->obs = "";
        $people20->save();

        $people21 = new People();
        $people21->name = "Iván";
        $people21->last_name = "Alonzo Jiménez";
        $people21->position = "Almacen 02";
        $people21->tel = "+523318795807";
        $people21->mail = "almacen@lospinos.org";
        $people21->obs = "";
        $people21->save();

        $people22 = new People();
        $people22->name = "Vacante";
        $people22->last_name = "Mantenimiento ";
        $people22->position = "Mantenimiento 02";
        $people22->tel = "";
        $people22->mail = "";
        $people22->obs = "";
        $people22->save();

        $people023 = new People();
        $people023->name = "Benjamín";
        $people023->last_name = "Sahagún Lomelí";
        $people023->position = "Soporte 02";
        $people023->tel = "+523323851005";
        $people023->mail = "benjamin@sahlom.com";
        $people023->obs = "";
        $people023->save();

        $people24 = new People();
        $people24->name = "José Gilberto";
        $people24->last_name = "García Hernández";
        $people24->position = "Dirección Educativa 01";
        $people24->tel = "+523335080350";
        $people24->mail = "direccion.educativa@pinos.org";
        $people24->obs = "";
        $people24->save();

        $people25 = new People();
        $people25->name = "Karen Noemy";
        $people25->last_name = "Cruz Pérez";
        $people25->position = "Recepción 02";
        $people25->tel = "+52";
        $people25->mail = "pinosac.recepcion@gmail.com";
        $people25->obs = "";
        $people25->save();

        $people26 = new People();
        $people26->name = "Margarita";
        $people26->last_name = "Pérez Pantoja";
        $people26->position = "Educación Especial 02";
        $people26->tel = "+52";
        $people26->mail = "";
        $people26->obs = "";
        $people26->save();

        $people27 = new People();
        $people27->name = "Norma Angélica";
        $people27->last_name = "Gamboa Rodríguez";
        $people27->position = "Formación Familiar 01";
        $people27->tel = "+523312968623";
        $people27->mail = "formacion.familiar@lospinos.org";
        $people27->obs = "";
        $people27->save();

        $people28 = new People();
        $people28->name = "Ana Paulina";
        $people28->last_name = "García Quiñones";
        $people28->position = "Formación Familiar 02";
        $people28->tel = "+523324812069";
        $people28->mail = "anapau.alberguelospinos@gmail.com";
        $people28->obs = "";
        $people28->save();

        $people29 = new People();
        $people29->name = "Gabriela Carolina";
        $people29->last_name = "Díaz Maldonado";
        $people29->position = "Formación Familiar 03";
        $people29->tel = "+523319522735";
        $people29->mail = "";
        $people29->obs = "";
        $people29->save();

        $people30 = new People();
        $people30->name = "María de los Ángeles";
        $people30->last_name = "Castillo Cervantes";
        $people30->position = "Formación Familiar 04";
        $people30->tel = "+523317371074";
        $people30->mail = "angeles.lospinos@gmail.com";
        $people30->obs = "";
        $people30->save();

        $people31 = new People();
        $people31->name = "Mariana";
        $people31->last_name = "Gutierrez Anguiano";
        $people31->position = "Formación Familiar 05";
        $people31->tel = "+523310710830";
        $people31->mail = "mariana.lospinos17@gmail.com";
        $people31->obs = "";
        $people31->save();

        $people32 = new People();
        $people32->name = "Marijose";
        $people32->last_name = "Ríos";
        $people32->position = "Trabajo Social 02";
        $people32->tel = "+523311965455";
        $people32->mail = "";
        $people32->obs = "";
        $people32->save();

        $people33 = new People();
        $people33->name = "Vacante";
        $people33->last_name = "Trabajo Social";
        $people33->position = "Trabajo Social 03";
        $people33->tel = "+52";
        $people33->mail = "";
        $people33->obs = "";
        $people33->save();

        $people34 = new People();
        $people34->name = "Roberto";
        $people34->last_name = " Magaña Espinoza";
        $people34->position = "Medicina 02";
        $people34->tel = "+52";
        $people34->mail = "";
        $people34->obs = "";
        $people34->save();

        $people35 = new People();
        $people35->name = "Luis";
        $people35->last_name = "Rojas Barreras";
        $people35->position = "Medicina 03";
        $people35->tel = "+52";
        $people35->mail = "";
        $people35->obs = "";
        $people35->save();

        $people36 = new People();
        $people36->name = "Guadalupe";
        $people36->last_name = "Hurtado Barrozo";
        $people36->position = "Formación Infantil 01";
        $people36->tel = "+523333986618";
        $people36->mail = "coordinacion.infantil@lospinos.org";
        $people36->obs = "";
        $people36->save();

        $people37 = new People();
        $people37->name = "Israel";
        $people37->last_name = "Nieves Vazquez";
        $people37->position = "Formación Juvenil 01";
        $people37->tel = "+523335590538";
        $people37->mail = "coordinacion.juvenil@lospinos.org";
        $people37->obs = "";
        $people37->save();

        $people38 = new People();
        $people38->name = "Luis Alejandro";
        $people38->last_name = "Coronel Hernández";
        $people38->position = "Formación Juvenil 02";
        $people38->tel = "+523328073024";
        $people38->mail = "";
        $people38->obs = "";
        $people38->save();

        // $people = new People();
        // $people->name = "NOMBRE";
        // $people->last_name = "APELLIDOS";
        // $people->position = "PUESTO";
        // $people->tel = "+52";
        // $people->mail = "EMAIL";
        // $people->obs = "";
        // $people->save();

    }
}