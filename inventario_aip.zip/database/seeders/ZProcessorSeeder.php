<?php

namespace Database\Seeders;

use App\Models\Processor;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class ZProcessorSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $processor01= new Processor();
        $processor01->des = "Xeon CPU E3-1220 V2";
        $processor01->frequency = "3.10 GHz";
        $processor01->asset_id = 1;
        $processor01->manufacturer_id = 12;
        $processor01->obs = "";
        $processor01->save();

        $processor02= new Processor();
        $processor02->des = "Xeon CPU E31220";
        $processor02->frequency = "3.10 GHz";
        $processor02->asset_id = 2;
        $processor02->manufacturer_id = 12;
        $processor02->obs = "";
        $processor02->save();

        $processor03= new Processor();
        $processor03->des = "Core i5-6200U";
        $processor03->frequency = "2.30 GHz";
        $processor03->asset_id = 3;
        $processor03->manufacturer_id = 12;
        $processor03->obs = "";
        $processor03->save();

        $processor04= new Processor();
        $processor04->des = "Core i5-8250U";
        $processor04->frequency = "1.60 GHz";
        $processor04->asset_id = 4;
        $processor04->manufacturer_id = 12;
        $processor04->obs = "";
        $processor04->save();

        $processor05= new Processor();
        $processor05->des = "Core i5-6200U";
        $processor05->frequency = "2.30 GHz";
        $processor05->asset_id = 5;
        $processor05->manufacturer_id = 12;
        $processor05->obs = "";
        $processor05->save();

        $processor06= new Processor();
        $processor06->des = "Core i5-7200U";
        $processor06->frequency = "2.50 GHz";
        $processor06->asset_id = 6;
        $processor06->manufacturer_id = 12;
        $processor06->obs = "";
        $processor06->save();

        $processor07= new Processor();
        $processor07->des = "Core i5-6400T";
        $processor07->frequency = "2.20 GHz";
        $processor07->asset_id = 7;
        $processor07->manufacturer_id = 12;
        $processor07->obs = "";
        $processor07->save();

        $processor08= new Processor();
        $processor08->des = "Core i7-4790";
        $processor08->frequency = "3.60 GHz";
        $processor08->asset_id = 8;
        $processor08->manufacturer_id = 12;
        $processor08->obs = "";
        $processor08->save();

        $processor09= new Processor();
        $processor09->des = "Core i5-3330S";
        $processor09->frequency = "2.70 GHz";
        $processor09->asset_id = 9;
        $processor09->manufacturer_id = 12;
        $processor09->obs = "";
        $processor09->save();

        $processor10= new Processor();
        $processor10->des = "Core i5-2400S";
        $processor10->frequency = "2.50 GHz";
        $processor10->asset_id = 10;
        $processor10->manufacturer_id = 12;
        $processor10->obs = "";
        $processor10->save();

        $processor11= new Processor();
        $processor11->des = "Core i5-6400T";
        $processor11->frequency = "2.20 GHz";
        $processor11->asset_id = 11;
        $processor11->manufacturer_id = 12;
        $processor11->obs = "";
        $processor11->save();

        $processor12= new Processor();
        $processor12->des = "Core i3-1115G4";
        $processor12->frequency = "3.00 GHz";
        $processor12->asset_id = 12;
        $processor12->manufacturer_id = 12;
        $processor12->obs = "";
        $processor12->save();

    }
}
