<?php

namespace Database\Seeders;

use App\Models\Environment;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class ZEnvironmentSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $environment01 = new Environment();
        $environment01->name = "NOVSER091";
        $environment01->domain_group = "Novelty";
        $environment01->user = "Administrador";
        $environment01->password = "********";
        $environment01->rdp_port = 50091;
        $environment01->asset_id = 1;
        $environment01->obs = "";
        $environment01->save();

        $environment02 = new Environment();
        $environment02->name = "NOVSER091";
        $environment02->domain_group = "Novelty";
        $environment02->user = "Usuario";
        $environment02->password = "Novelty2018.";
        $environment02->rdp_port = 50091;
        $environment02->asset_id = 1;
        $environment02->obs = "";
        $environment02->save();

        $environment03 = new Environment();
        $environment03->name = "NOVSER091";
        $environment03->domain_group = "Novelty";
        $environment03->user = "Valentin";
        $environment03->password = "Novelty2023*";
        $environment03->rdp_port = 50091;
        $environment03->asset_id = 1;
        $environment03->obs = "";
        $environment03->save();

        $environment04 = new Environment();
        $environment04->name = "NOVSER091";
        $environment04->domain_group = "Novelty";
        $environment04->user = "Valeria";
        $environment04->password = "Novelty2018.";
        $environment04->rdp_port = 50091;
        $environment04->asset_id = 1;
        $environment04->obs = "";
        $environment04->save();

        $environment05 = new Environment();
        $environment05->name = "NOVSER093";
        $environment05->domain_group = "Novelty";
        $environment05->user = "Administrador";
        $environment05->password = "PASS";
        $environment05->rdp_port = 50093;
        $environment05->asset_id = 2;
        $environment05->obs = "";
        $environment05->save();

        $environment06 = new Environment();
        $environment06->name = "NOVSER093";
        $environment06->domain_group = "Novelty";
        $environment06->user = "Usuario";
        $environment06->password = "Novelty2018.";
        $environment06->rdp_port = 50093;
        $environment06->asset_id = 2;
        $environment06->obs = "";
        $environment06->save();

        $environment07 = new Environment();
        $environment07->name = "NOVSER093";
        $environment07->domain_group = "Novelty";
        $environment07->user = "Valentin";
        $environment07->password = "Novelty2023*";
        $environment07->rdp_port = 50093;
        $environment07->asset_id = 2;
        $environment07->obs = "";
        $environment07->save();

        $environment08 = new Environment();
        $environment08->name = "NOVAIORECEPCION";
        $environment08->domain_group = "Novelty";
        $environment08->user = "Novelty";
        $environment08->password = "Novelty2018.";
        $environment08->rdp_port = 50101;
        $environment08->asset_id = 3;
        $environment08->obs = "";
        $environment08->save();

        $environment09 = new Environment();
        $environment09->name = "NOVAIORH01";
        $environment09->domain_group = "Novelty";
        $environment09->user = "Novelty";
        $environment09->password = "";
        $environment09->rdp_port = 50106;
        $environment09->asset_id = 4;
        $environment09->obs = "";
        $environment09->save();

        $environment10 = new Environment();
        $environment10->name = "NOVAIORH02";
        $environment10->domain_group = "Novelty";
        $environment10->user = "Novelty";
        $environment10->password = "";
        $environment10->rdp_port = 50104;
        $environment10->asset_id = 5;
        $environment10->obs = "";
        $environment10->save();

        $environment11 = new Environment();
        $environment11->name = "NOVAIOCONTA01";
        $environment11->domain_group = "Novelty";
        $environment11->user = "Novelty";
        $environment11->password = "";
        $environment11->rdp_port = 50107;
        $environment11->asset_id = 6;
        $environment11->obs = "";
        $environment11->save();

        $environment12 = new Environment();
        $environment12->name = "NOVAIOCONTA03";
        $environment12->domain_group = "Novelty";
        $environment12->user = "Novelty";
        $environment12->password = "Carolina1807";
        $environment12->rdp_port = 50108;
        $environment12->asset_id = 7;
        $environment12->obs = "";
        $environment12->save();

        $environment13 = new Environment();
        $environment13->name = "NOVDESAUDITORIA";
        $environment13->domain_group = "Novelty";
        $environment13->user = "Novelty";
        $environment13->password = "Novelty2018.";
        $environment13->rdp_port = 50109;
        $environment13->asset_id = 8;
        $environment13->obs = "";
        $environment13->save();

        $environment14 = new Environment();
        $environment14->name = "NOVAIOASIST";
        $environment14->domain_group = "Novelty";
        $environment14->user = "Novelty";
        $environment14->password = "G1a2b3r4";
        $environment14->rdp_port = 50113;
        $environment14->asset_id = 9;
        $environment14->obs = "";
        $environment14->save();

        $environment15 = new Environment();
        $environment15->name = "NOVAIODIRECCION";
        $environment15->domain_group = "Novelty";
        $environment15->user = "Novelty";
        $environment15->password = "SO1112";
        $environment15->rdp_port = 115;
        $environment15->asset_id = 10;
        $environment15->obs = "";
        $environment15->save();

        $environment16 = new Environment();
        $environment16->name = "NOVAIOCOMERCIAL";
        $environment16->domain_group = "Novelty";
        $environment16->user = "Novelty";
        $environment16->password = "Novelty2018.";
        $environment16->rdp_port = 116;
        $environment16->asset_id = 11;
        $environment16->obs = "";
        $environment16->save();

        $environment17 = new Environment();
        $environment17->name = "NOVLAPJUNTAS";
        $environment17->domain_group = "Novelty";
        $environment17->user = "Novelty";
        $environment17->password = "";
        $environment17->rdp_port = 117;
        $environment17->asset_id = 12;
        $environment17->obs = "";
        $environment17->save();

        // $environment13 = new Environment();
        // $environment13->name = "NOMBRE";
        // $environment13->domain_group = "Novelty";
        // $environment13->user = "USUARIO";
        // $environment13->password = "PASS";
        // $environment13->rdp_port = PUERTO;
        // $environment13->asset_id = ASSET;
        // $environment13->obs = "";
        // $environment13->save();

        // $environment14 = new Environment();
        // $environment14->name = "NOMBRE";
        // $environment14->domain_group = "Novelty";
        // $environment14->user = "USUARIO";
        // $environment14->password = "PASS";
        // $environment14->rdp_port = PUERTO;
        // $environment14->asset_id = ASSET;
        // $environment14->obs = "";
        // $environment14->save();

    }
}
