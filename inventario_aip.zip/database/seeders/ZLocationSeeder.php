<?php

namespace Database\Seeders;

use App\Models\Location;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class ZLocationSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $location01 = new Location();
        $location01->name = "Providencia";
        $location01->tel = "+523336151388";
        $location01->public_ip = "187.247.162.109";
        $location01->public_dns = "novelty.sahlom.com";
        $location01->street = "Guayaquil";
        $location01->ext_number = "2654";
        $location01->int_number = NULL;
        $location01->col = "Providencia 3ra Sección";
        $location01->city = "Guadalajara";
        $location01->mun = "Guadalajara";
        $location01->state = "Jalisco";
        $location01->country = "México";
        $location01->zip_code = "44630";
        $location01->obs = NULL;
        $location01->save();
    }
}
