<?php

namespace Database\Seeders;

use App\Models\Placement;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class ZPlacementSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $placement01 = new Placement();
        $placement01->name = "Almacén";
        $placement01->location_id = 1;
        $placement01->people_id = 2;
        $placement01->obs = "Almacén";
        $placement01->save();

        $placement02 = new Placement();
        $placement02->name = "Oficina de Dirección";
        $placement02->location_id = 1;
        $placement02->people_id = 1;
        $placement02->obs = "Oficina";
        $placement02->save();

        $placement03 = new Placement();
        $placement03->name = "Sala de Juntas";
        $placement03->location_id = 1;
        $placement03->people_id = 4;
        $placement03->obs = "Sala";
        $placement03->save();

        $placement04 = new Placement();
        $placement04->name = "Oficina del Gerente Comercial";
        $placement04->location_id = 1;
        $placement04->people_id = 2;
        $placement04->obs = "Oficina";
        $placement04->save();

        $placement05 = new Placement();
        $placement05->name = "Escritorio 10";
        $placement05->location_id = 1;
        $placement05->people_id = 3;
        $placement05->obs = "Escritorio";
        $placement05->save();

        $placement06 = new Placement();
        $placement06->name = "Escritorio 11";
        $placement06->location_id = 1;
        $placement06->people_id = 3;
        $placement06->obs = "Escritorio";
        $placement06->save();

        $placement07 = new Placement();
        $placement07->name = "Escritorio 12";
        $placement07->location_id = 1;
        $placement07->people_id = 3;
        $placement07->obs = "Escritorio";
        $placement07->save();

        $placement08 = new Placement();
        $placement08->name = "Escritorio 13";
        $placement08->location_id = 1;
        $placement08->people_id = 3;
        $placement08->obs = "Escritorio";
        $placement08->save();

        $placement09 = new Placement();
        $placement09->name = "Escritorio 07";
        $placement09->location_id = 1;
        $placement09->people_id = 8;
        $placement09->obs = "Escritorio";
        $placement09->save();

        $placement10 = new Placement();
        $placement10->name = "Escritorio 08";
        $placement10->location_id = 1;
        $placement10->people_id = 7;
        $placement10->obs = "Escritorio";
        $placement10->save();

        $placement11 = new Placement();
        $placement11->name = "Escritorio 09";
        $placement11->location_id = 1;
        $placement11->people_id = 6;
        $placement11->obs = "Escritorio";
        $placement11->save();

        $placement12 = new Placement();
        $placement12->name = "Escritorio 03";
        $placement12->location_id = 1;
        $placement12->people_id = 3;
        $placement12->obs = "Escritorio";
        $placement12->save();

        $placement13 = new Placement();
        $placement13->name = "Escritorio 04";
        $placement13->location_id = 1;
        $placement13->people_id = 11;
        $placement13->obs = "Escritorio";
        $placement13->save();

        $placement14 = new Placement();
        $placement14->name = "Escritorio 05";
        $placement14->location_id = 1;
        $placement14->people_id = 3;
        $placement14->obs = "Escritorio";
        $placement14->save();

        $placement15 = new Placement();
        $placement15->name = "Escritorio 06";
        $placement15->location_id = 1;
        $placement15->people_id = 10;
        $placement15->obs = "Escritorio";
        $placement15->save();

        $placement16 = new Placement();
        $placement16->name = "Escritorio de Recepción";
        $placement16->location_id = 1;
        $placement16->people_id = 5;
        $placement16->obs = "Escritorio";
        $placement16->save();

        $placement17 = new Placement();
        $placement17->name = "Site";
        $placement17->location_id = 1;
        $placement17->people_id = 9;
        $placement17->obs = "Escritorio";
        $placement17->save();

        // $placement1 = new Placement();
        // $placement1->name = "NOMBRE";
        // $placement1->location_id = 1;
        // $placement1->people_id = PERSONA;
        // $placement1->obs = "Escritorio";
        // $placement1->save();
    }
}
