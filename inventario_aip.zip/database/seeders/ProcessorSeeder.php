<?php

namespace Database\Seeders;

use App\Models\Processor;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class ProcessorSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $processor01= new Processor();
        $processor01->des = "Xeon CPU E31220";
        $processor01->frequency = "3.10 GHz";
        $processor01->asset_id = 1;
        $processor01->manufacturer_id = 12;
        $processor01->obs = "";
        $processor01->save();

        $processor02= new Processor();
        $processor02->des = "Xeon CPU E31220 v6";
        $processor02->frequency = "3.00 GHz";
        $processor02->asset_id = 2;
        $processor02->manufacturer_id = 12;
        $processor02->obs = "";
        $processor02->save();
        
        $processor03= new Processor();
        $processor03->des = "Ryzen 5 PRO 3400G";
        $processor03->frequency = "3.70 GHz";
        $processor03->asset_id = 3;
        $processor03->manufacturer_id = 13;
        $processor03->obs = "";
        $processor03->save();

        $processor04= new Processor();
        $processor04->des = "Core i7-1165G7";
        $processor04->frequency = "2.80 GHz";
        $processor04->asset_id = 4;
        $processor04->manufacturer_id = 12;
        $processor04->obs = "";
        $processor04->save();

        $processor05= new Processor();
        $processor05->des = "Ryzen 5 PRO 3400G";
        $processor05->frequency = "3.70 GHz";
        $processor05->asset_id = 5;
        $processor05->manufacturer_id = 13;
        $processor05->obs = "";
        $processor05->save();

        $processor06= new Processor();
        $processor06->des = "Core i3-3220";
        $processor06->frequency = "3.30 GHz";
        $processor06->asset_id = 6;
        $processor06->manufacturer_id = 12;
        $processor06->obs = "";
        $processor06->save();

        $processor07= new Processor();
        $processor07->des = "Core i5-4570";
        $processor07->frequency = "3.20 GHz";
        $processor07->asset_id = 7;
        $processor07->manufacturer_id = 12;
        $processor07->obs = "";
        $processor07->save();

        $processor08= new Processor();
        $processor08->des = "Core i7-12700T";
        $processor08->frequency = "1.40 GHz";
        $processor08->asset_id = 8;
        $processor08->manufacturer_id = 12;
        $processor08->obs = "";
        $processor08->save();

        $processor09= new Processor();
        $processor09->des = "Core i7-1165G7";
        $processor09->frequency = "2.80 GHz";
        $processor09->asset_id = 9;
        $processor09->manufacturer_id = 12;
        $processor09->obs = "";
        $processor09->save();

        $processor10= new Processor();
        $processor10->des = "Core i3-3220";
        $processor10->frequency = "3.30 GHz";
        $processor10->asset_id = 10;
        $processor10->manufacturer_id = 12;
        $processor10->obs = "";
        $processor10->save();

        $processor11= new Processor();
        $processor11->des = "Ryzen 5 PRO 3400G";
        $processor11->frequency = "3.70 GHz";
        $processor11->asset_id = 11;
        $processor11->manufacturer_id = 13;
        $processor11->obs = "";
        $processor11->save();

        $processor12= new Processor();
        $processor12->des = "Ryzen 5 PRO 3400G";
        $processor12->frequency = "3.70 GHz";
        $processor12->asset_id = 12;
        $processor12->manufacturer_id = 13;
        $processor12->obs = "";
        $processor12->save();

        $processor13= new Processor();
        $processor13->des = "Core i5-9400";
        $processor13->frequency = "2.90 GHz";
        $processor13->asset_id = 13;
        $processor13->manufacturer_id = 12;
        $processor13->obs = "";
        $processor13->save();

        $processor14= new Processor();
        $processor14->des = "Core i7-1255U";
        $processor14->frequency = "1.70 GHz";
        $processor14->asset_id = 14;
        $processor14->manufacturer_id = 12;
        $processor14->obs = "";
        $processor14->save();

        $processor15= new Processor();
        $processor15->des = "Core i3-4130";
        $processor15->frequency = "3.40 GHz";
        $processor15->asset_id = 15;
        $processor15->manufacturer_id = 12;
        $processor15->obs = "";
        $processor15->save();

        $processor16= new Processor();
        $processor16->des = "Ryzen 5 PRO 3400G";
        $processor16->frequency = "3.70 GHz";
        $processor16->asset_id = 16;
        $processor16->manufacturer_id = 13;
        $processor16->obs = "";
        $processor16->save();

        $processor17= new Processor();
        $processor17->des = "Ryzen 7 4700G";
        $processor17->frequency = "3.60 GHz";
        $processor17->asset_id = 17;
        $processor17->manufacturer_id = 13;
        $processor17->obs = "";
        $processor17->save();

        $processor18= new Processor();
        $processor18->des = "Core i5-4210M";
        $processor18->frequency = "2.60 GHz";
        $processor18->asset_id = 18;
        $processor18->manufacturer_id = 12;
        $processor18->obs = "";
        $processor18->save();

        $processor19= new Processor();
        $processor19->des = "Core i3-3220";
        $processor19->frequency = "3.30 GHz";
        $processor19->asset_id = 19;
        $processor19->manufacturer_id = 12;
        $processor19->obs = "";
        $processor19->save();

        $processor20= new Processor();
        $processor20->des = "Xeon X3430";
        $processor20->frequency = "2.40 GHz";
        $processor20->asset_id = 20;
        $processor20->manufacturer_id = 12;
        $processor20->obs = "";
        $processor20->save();

        $processor21= new Processor();
        $processor21->des = "Core i7-1255U";
        $processor21->frequency = "1.70 GHz";
        $processor21->asset_id = 21;
        $processor21->manufacturer_id = 12;
        $processor21->obs = "";
        $processor21->save();

        $processor22= new Processor();
        $processor22->des = "Core i5-1135G7";
        $processor22->frequency = "2.40 GHz";
        $processor22->asset_id = 22;
        $processor22->manufacturer_id = 12;
        $processor22->obs = "";
        $processor22->save();

        $processor23= new Processor();
        $processor23->des = "Core i5-7200U";
        $processor23->frequency = "2.50 GHz";
        $processor23->asset_id = 23;
        $processor23->manufacturer_id = 12;
        $processor23->obs = "";
        $processor23->save();

        $processor24= new Processor();
        $processor24->des = "Core i7-1255U";
        $processor24->frequency = "1.70 GHz";
        $processor24->asset_id = 24;
        $processor24->manufacturer_id = 12;
        $processor24->obs = "";
        $processor24->save();

        $processor25= new Processor();
        $processor25->des = "Core i3-3220";
        $processor25->frequency = "3.30 GHz";
        $processor25->asset_id = 25;
        $processor25->manufacturer_id = 12;
        $processor25->obs = "";
        $processor25->save();

        $processor26= new Processor();
        $processor26->des = "Core i3 550";
        $processor26->frequency = "3.20 GHz";
        $processor26->asset_id = 26;
        $processor26->manufacturer_id = 12;
        $processor26->obs = "";
        $processor26->save();

        $processor27= new Processor();
        $processor27->des = "Core i3-6100";
        $processor27->frequency = "3.70 GHz";
        $processor27->asset_id = 27;
        $processor27->manufacturer_id = 12;
        $processor27->obs = "";
        $processor27->save();

        $processor28= new Processor();
        $processor28->des = "Core i3-4130";
        $processor28->frequency = "3.40 GHz";
        $processor28->asset_id = 28;
        $processor28->manufacturer_id = 12;
        $processor28->obs = "";
        $processor28->save();

        $processor29= new Processor();
        $processor29->des = "Core i3-3220";
        $processor29->frequency = "3.30 GHz";
        $processor29->asset_id = 29;
        $processor29->manufacturer_id = 12;
        $processor29->obs = "";
        $processor29->save();

        $processor30= new Processor();
        $processor30->des = "Core i3 550";
        $processor30->frequency = "3.20 GHz";
        $processor30->asset_id = 30;
        $processor30->manufacturer_id = 12;
        $processor30->obs = "";
        $processor30->save();

        $processor31= new Processor();
        $processor31->des = "Core i3-4130";
        $processor31->frequency = "3.40 GHz";
        $processor31->asset_id = 31;
        $processor31->manufacturer_id = 12;
        $processor31->obs = "";
        $processor31->save();

        $processor32= new Processor();
        $processor32->des = "Ryzen 5 PRO 3400G";
        $processor32->frequency = "3.70 GHz";
        $processor32->asset_id = 32;
        $processor32->manufacturer_id = 13;
        $processor32->obs = "";
        $processor32->save();

        $processor33= new Processor();
        $processor33->des = "Core i5-4210M";
        $processor33->frequency = "2.66 GHz";
        $processor33->asset_id = 33;
        $processor33->manufacturer_id = 12;
        $processor33->obs = "";
        $processor33->save();
        
        $processor34= new Processor();
        $processor34->des = "Core i5-9400";
        $processor34->frequency = "2.90 GHz";
        $processor34->asset_id = 34;
        $processor34->manufacturer_id = 12;
        $processor34->obs = "";
        $processor34->save();
        
        $processor35= new Processor();
        $processor35->des = "Core i5-6200U";
        $processor35->frequency = "2.30 GHz";
        $processor35->asset_id = 35;
        $processor35->manufacturer_id = 12;
        $processor35->obs = "";
        $processor35->save();
        
        $processor36= new Processor();
        $processor36->des = "Core i3-4150";
        $processor36->frequency = "3.50 GHz";
        $processor36->asset_id = 36;
        $processor36->manufacturer_id = 12;
        $processor36->obs = "";
        $processor36->save();
        
        $processor37= new Processor();
        $processor37->des = "Core i3-4150";
        $processor37->frequency = "3.50 GHz";
        $processor37->asset_id = 37;
        $processor37->manufacturer_id = 12;
        $processor37->obs = "";
        $processor37->save();
        
        $processor38= new Processor();
        $processor38->des = "Core i3-550";
        $processor38->frequency = "3.20 GHz";
        $processor38->asset_id = 38;
        $processor38->manufacturer_id = 12;
        $processor38->obs = "";
        $processor38->save();
        
        $processor39= new Processor();
        $processor39->des = "Core i3-550";
        $processor39->frequency = "3.20 GHz";
        $processor39->asset_id = 39;
        $processor39->manufacturer_id = 12;
        $processor39->obs = "";
        $processor39->save();
        
        $processor40= new Processor();
        $processor40->des = "Core i3-550";
        $processor40->frequency = "3.20 GHz";
        $processor40->asset_id = 40;
        $processor40->manufacturer_id = 12;
        $processor40->obs = "";
        $processor40->save();
        
        $processor41= new Processor();
        $processor41->des = "Core i3-540";
        $processor41->frequency = "3.07 GHz";
        $processor41->asset_id = 41;
        $processor41->manufacturer_id = 12;
        $processor41->obs = "";
        $processor41->save();
        
        $processor42= new Processor();
        $processor42->des = "Ryzen 5 PRO 3400G";
        $processor42->frequency = "3.70 GHz";
        $processor42->asset_id = 42;
        $processor42->manufacturer_id = 13;
        $processor42->obs = "";
        $processor42->save();
        
        $processor43= new Processor();
        $processor43->des = "Core i5-5200U";
        $processor43->frequency = "2.20 GHz";
        $processor43->asset_id = 43;
        $processor43->manufacturer_id = 12;
        $processor43->obs = "";
        $processor43->save();
        
        $processor44= new Processor();
        $processor44->des = "Celeron N4020";
        $processor44->frequency = "1.10 GHz";
        $processor44->asset_id = 44;
        $processor44->manufacturer_id = 12;
        $processor44->obs = "";
        $processor44->save();
        
        $processor45= new Processor();
        $processor45->des = "Core i3-2120";
        $processor45->frequency = "3.30 GHz";
        $processor45->asset_id = 45;
        $processor45->manufacturer_id = 12;
        $processor45->obs = "";
        $processor45->save();
        
        $processor46= new Processor();
        $processor46->des = "Ryzen 5 PRO 3400G";
        $processor46->frequency = "3.70 GHz";
        $processor46->asset_id = 46;
        $processor46->manufacturer_id = 13;
        $processor46->obs = "";
        $processor46->save();
        
        $processor47= new Processor();
        $processor47->des = "Pentium CPU B960";
        $processor47->frequency = "2.20 GHz";
        $processor47->asset_id = 47;
        $processor47->manufacturer_id = 12;
        $processor47->obs = "";
        $processor47->save();
        
        $processor48= new Processor();
        $processor48->des = "Core i3-2328M";
        $processor48->frequency = "2.20 GHz";
        $processor48->asset_id = 48;
        $processor48->manufacturer_id = 12;
        $processor48->obs = "";
        $processor48->save();
        
        $processor49= new Processor();
        $processor49->des = "Core i5-6200U";
        $processor49->frequency = "2.30 GHz";
        $processor49->asset_id = 49;
        $processor49->manufacturer_id = 12;
        $processor49->obs = "";
        $processor49->save();
        
        $processor50= new Processor();
        $processor50->des = "E2-6110 APU with AMD Radeon R2 Graphics";
        $processor50->frequency = "1.50 GHz";
        $processor50->asset_id = 50;
        $processor50->manufacturer_id = 13;
        $processor50->obs = "";
        $processor50->save();
        
        $processor51= new Processor();
        $processor51->des = "E2-6110 APU with AMD Radeon R2 Graphics";
        $processor51->frequency = "1.50 GHz";
        $processor51->asset_id = 51;
        $processor51->manufacturer_id = 13;
        $processor51->obs = "";
        $processor51->save();
        
        $processor52= new Processor();
        $processor52->des = "E2-6110 APU with AMD Radeon R2 Graphics";
        $processor52->frequency = "1.50 GHz";
        $processor52->asset_id = 52;
        $processor52->manufacturer_id = 13;
        $processor52->obs = "";
        $processor52->save();
        
        $processor53= new Processor();
        $processor53->des = "E2-6110 APU with AMD Radeon R2 Graphics";
        $processor53->frequency = "1.50 GHz";
        $processor53->asset_id = 53;
        $processor53->manufacturer_id = 13;
        $processor53->obs = "";
        $processor53->save();
        
        $processor54= new Processor();
        $processor54->des = "E2-6110 APU with AMD Radeon R2 Graphics";
        $processor54->frequency = "1.50 GHz";
        $processor54->asset_id = 54;
        $processor54->manufacturer_id = 13;
        $processor54->obs = "";
        $processor54->save();
        
        $processor55= new Processor();
        $processor55->des = "E2-6110 APU with AMD Radeon R2 Graphics";
        $processor55->frequency = "1.50 GHz";
        $processor55->asset_id = 55;
        $processor55->manufacturer_id = 13;
        $processor55->obs = "";
        $processor55->save();
        
        $processor56= new Processor();
        $processor56->des = "E2-6110 APU with AMD Radeon R2 Graphics";
        $processor56->frequency = "1.50 GHz";
        $processor56->asset_id = 56;
        $processor56->manufacturer_id = 13;
        $processor56->obs = "";
        $processor56->save();
        
        $processor57= new Processor();
        $processor57->des = "E2-6110 APU with AMD Radeon R2 Graphics";
        $processor57->frequency = "1.50 GHz";
        $processor57->asset_id = 57;
        $processor57->manufacturer_id = 13;
        $processor57->obs = "";
        $processor57->save();
        
        $processor58= new Processor();
        $processor58->des = "E2-6110 APU with AMD Radeon R2 Graphics";
        $processor58->frequency = "1.50 GHz";
        $processor58->asset_id = 58;
        $processor58->manufacturer_id = 13;
        $processor58->obs = "";
        $processor58->save();
        
        $processor59= new Processor();
        $processor59->des = "E2-6110 APU with AMD Radeon R2 Graphics";
        $processor59->frequency = "1.50 GHz";
        $processor59->asset_id = 59;
        $processor59->manufacturer_id = 13;
        $processor59->obs = "";
        $processor59->save();
        
        $processor60= new Processor();
        $processor60->des = "Core i5-6200U";
        $processor60->frequency = "2.30 GHz";
        $processor60->asset_id = 60;
        $processor60->manufacturer_id = 12;
        $processor60->obs = "";
        $processor60->save();
        
        $processor61= new Processor();
        $processor61->des = "Core i5-6200U";
        $processor61->frequency = "2.30 GHz";
        $processor61->asset_id = 61;
        $processor61->manufacturer_id = 12;
        $processor61->obs = "";
        $processor61->save();
        
        $processor62= new Processor();
        $processor62->des = "Core i3-3220";
        $processor62->frequency = "3.30 GHz";
        $processor62->asset_id = 62;
        $processor62->manufacturer_id = 12;
        $processor62->obs = "";
        $processor62->save();
        
        $processor63= new Processor();
        $processor63->des = "Core i5-6200U";
        $processor63->frequency = "2.30 GHz";
        $processor63->asset_id = 63;
        $processor63->manufacturer_id = 12;
        $processor63->obs = "";
        $processor63->save();
        
        $processor64= new Processor();
        $processor64->des = "Core i7-6500";
        $processor64->frequency = "2.50 GHz";
        $processor64->asset_id = 64;
        $processor64->manufacturer_id = 12;
        $processor64->obs = "";
        $processor64->save();
        
        $processor65= new Processor();
        $processor65->des = "Core i5-1135G7";
        $processor65->frequency = "2.40 GHz";
        $processor65->asset_id = 65;
        $processor65->manufacturer_id = 12;
        $processor65->obs = "";
        $processor65->save();
        
        $processor66= new Processor();
        $processor66->des = "Core i3-3220";
        $processor66->frequency = "3.30 GHz";
        $processor66->asset_id = 66;
        $processor66->manufacturer_id = 12;
        $processor66->obs = "";
        $processor66->save();
        
        $processor67= new Processor();
        $processor67->des = "Ryzen 5 PRO 3400G";
        $processor67->frequency = "3.70 GHz";
        $processor67->asset_id = 67;
        $processor67->manufacturer_id = 13;
        $processor67->obs = "";
        $processor67->save();
        
        $processor68= new Processor();
        $processor68->des = "Core i3-4130";
        $processor68->frequency = "3.40 GHz";
        $processor68->asset_id = 68;
        $processor68->manufacturer_id = 12;
        $processor68->obs = "";
        $processor68->save();
        
        $processor69= new Processor();
        $processor69->des = "Core i3-4130";
        $processor69->frequency = "3.40 GHz";
        $processor69->asset_id = 69;
        $processor69->manufacturer_id = 12;
        $processor69->obs = "";
        $processor69->save();
        
        $processor70= new Processor();
        $processor70->des = "Core i5-8250U";
        $processor70->frequency = "1.60 GHz";
        $processor70->asset_id = 70;
        $processor70->manufacturer_id = 12;
        $processor70->obs = "";
        $processor70->save();
    }
}
