<?php

namespace Database\Seeders;

use App\Models\License;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class ZLicenseSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $license01 = new License();
        $license01->des = "Kaspersky Small Office Security (Ser)";
        $license01->serial = "CAZMS-JEF4K-TB8TN-A5UB7";
        $license01->expiration_date = "2024-08-29";
        $license01->asset_id = 1;
        $license01->manufacturer_id = 16;
        $license01->obs = "Asignado";
        $license01->save();

        $license02 = new License();
        $license02->des = "Kaspersky Small Office Security (Ser)";
        $license02->serial = "CAZMS-JEF4K-TB8TN-A5UB7";
        $license02->expiration_date = "2024-08-29";
        $license02->asset_id = 2;
        $license02->manufacturer_id = 16;
        $license02->obs = "Asignado";
        $license02->save();

        $license03 = new License();
        $license03->des = "Kaspersky Small Office Security (PC)";
        $license03->serial = "CAZMS-JEF4K-TB8TN-A5UB7";
        $license03->expiration_date = "2024-08-29";
        $license03->asset_id = 3;
        $license03->manufacturer_id = 16;
        $license03->obs = "Asignado";
        $license03->save();

        $license04 = new License();
        $license04->des = "Kaspersky Small Office Security (PC)";
        $license04->serial = "CAZMS-JEF4K-TB8TN-A5UB7";
        $license04->expiration_date = "2024-08-29";
        $license04->asset_id = 4;
        $license04->manufacturer_id = 16;
        $license04->obs = "Asignado";
        $license04->save();

        $license05 = new License();
        $license05->des = "Kaspersky Small Office Security (PC)";
        $license05->serial = "CAZMS-JEF4K-TB8TN-A5UB7";
        $license05->expiration_date = "2024-08-29";
        $license05->asset_id = 5;
        $license05->manufacturer_id = 16;
        $license05->obs = "Asignado";
        $license05->save();

        $license06 = new License();
        $license06->des = "Kaspersky Small Office Security (PC)";
        $license06->serial = "CAZMS-JEF4K-TB8TN-A5UB7";
        $license06->expiration_date = "2024-08-29";
        $license06->asset_id = 6;
        $license06->manufacturer_id = 16;
        $license06->obs = "Asignado";
        $license06->save();

        $license07 = new License();
        $license07->des = "Kaspersky Small Office Security (PC)";
        $license07->serial = "CAZMS-JEF4K-TB8TN-A5UB7";
        $license07->expiration_date = "2024-08-29";
        $license07->asset_id = 7;
        $license07->manufacturer_id = 16;
        $license07->obs = "Asignado";
        $license07->save();

        $license08 = new License();
        $license08->des = "Kaspersky Small Office Security (PC)";
        $license08->serial = "CAZMS-JEF4K-TB8TN-A5UB7";
        $license08->expiration_date = "2024-08-29";
        $license08->asset_id = 8;
        $license08->manufacturer_id = 16;
        $license08->obs = "Asignado";
        $license08->save();

        $license09 = new License();
        $license09->des = "Kaspersky Small Office Security (PC)";
        $license09->serial = "CAZMS-JEF4K-TB8TN-A5UB7";
        $license09->expiration_date = "2024-08-29";
        $license09->asset_id = 9;
        $license09->manufacturer_id = 16;
        $license09->obs = "Asignado";
        $license09->save();

        $license10 = new License();
        $license10->des = "Kaspersky Small Office Security (PC)";
        $license10->serial = "CAZMS-JEF4K-TB8TN-A5UB7";
        $license10->expiration_date = "2024-08-29";
        $license10->asset_id = 10;
        $license10->manufacturer_id = 16;
        $license10->obs = "Asignado";
        $license10->save();

        $license11 = new License();
        $license11->des = "Kaspersky Small Office Security (PC)";
        $license11->serial = "CAZMS-JEF4K-TB8TN-A5UB7";
        $license11->expiration_date = "2024-08-29";
        $license11->asset_id = 11;
        $license11->manufacturer_id = 16;
        $license11->obs = "Asignado";
        $license11->save();

        $license12 = new License();
        $license12->des = "Kaspersky Small Office Security (PC)";
        $license12->serial = "CAZMS-JEF4K-TB8TN-A5UB7";
        $license12->expiration_date = "2024-08-29";
        $license12->asset_id = 12;
        $license12->manufacturer_id = 16;
        $license12->obs = "Asignado";
        $license12->save();

        $license13 = new License();
        $license13->des = "Kaspersky Small Office Security (PC)";
        $license13->serial = "CAZMS-JEF4K-TB8TN-A5UB7";
        $license13->expiration_date = "2024-08-29";
        $license13->asset_id = NULL;
        $license13->manufacturer_id = 16;
        $license13->obs = "Sin Asignar";
        $license13->save();

        $license14 = new License();
        $license14->des = "Kaspersky Small Office Security (PC)";
        $license14->serial = "CAZMS-JEF4K-TB8TN-A5UB7";
        $license14->expiration_date = "2024-08-29";
        $license14->asset_id = NULL;
        $license14->manufacturer_id = 16;
        $license14->obs = "Sin Asignar";
        $license14->save();

        $license15 = new License();
        $license15->des = "Kaspersky Small Office Security (PC)";
        $license15->serial = "CAZMS-JEF4K-TB8TN-A5UB7";
        $license15->expiration_date = "2024-08-29";
        $license15->asset_id = NULL;
        $license15->manufacturer_id = 16;
        $license15->obs = "Sin Asignar";
        $license15->save();

        $license16 = new License();
        $license16->des = "Kaspersky Small Office Security (PC)";
        $license16->serial = "CAZMS-JEF4K-TB8TN-A5UB7";
        $license16->expiration_date = "2024-08-29";
        $license16->asset_id = NULL;
        $license16->manufacturer_id = 16;
        $license16->obs = "Sin Asignar";
        $license16->save();

        $license17 = new License();
        $license17->des = "Kaspersky Small Office Security (PC)";
        $license17->serial = "CAZMS-JEF4K-TB8TN-A5UB7";
        $license17->expiration_date = "2024-08-29";
        $license17->asset_id = NULL;
        $license17->manufacturer_id = 16;
        $license17->obs = "Sin Asignar";
        $license17->save();

        $license18 = new License();
        $license18->des = "Microsoft 365 Empresa Estandar";
        $license18->serial = "Suscripción 1 (1)";
        $license18->expiration_date = "2050-11-11";
        $license18->asset_id = 4;
        $license18->manufacturer_id = 15;
        $license18->obs = "Asignado";
        $license18->save();

        $license19 = new License();
        $license19->des = "Microsoft 365 Empresa Estandar";
        $license19->serial = "Suscripción 2 (1)";
        $license19->expiration_date = "2050-11-11";
        $license19->asset_id = 5;
        $license19->manufacturer_id = 15;
        $license19->obs = "Asignado";
        $license19->save();

        $license20 = new License();
        $license20->des = "Microsoft 365 Empresa Estandar";
        $license20->serial = "Suscripción 3 (1)";
        $license20->expiration_date = "2050-11-11";
        $license20->asset_id = 8;
        $license20->manufacturer_id = 15;
        $license20->obs = "Asignado";
        $license20->save();

        $license21 = new License();
        $license21->des = "Microsoft 365 Empresa Estandar";
        $license21->serial = "Suscripción 4 (1)";
        $license21->expiration_date = "2050-11-11";
        $license21->asset_id = 9;
        $license21->manufacturer_id = 15;
        $license21->obs = "Asignado";
        $license21->save();

        $license22 = new License();
        $license22->des = "Microsoft 365 Empresa Estandar";
        $license22->serial = "Suscripción 5 (1)";
        $license22->expiration_date = "2050-11-11";
        $license22->asset_id = 10;
        $license22->manufacturer_id = 15;
        $license22->obs = "Asignado";
        $license22->save();

        $license23 = new License();
        $license23->des = "Microsoft 365 Empresa Basic";
        $license23->serial = "Suscripción 6 (1)";
        $license23->expiration_date = "2050-11-11";
        $license23->asset_id = 1;
        $license23->manufacturer_id = 15;
        $license23->obs = "Asignado";
        $license23->save();

        $license24 = new License();
        $license24->des = "Microsoft 365 Empresa Basic";
        $license24->serial = "Suscripción 7 (1)";
        $license24->expiration_date = "2050-11-11";
        $license24->asset_id = 2;
        $license24->manufacturer_id = 15;
        $license24->obs = "Asignado";
        $license24->save();

        $license25 = new License();
        $license25->des = "Microsoft 365 Empresa Basic";
        $license25->serial = "Suscripción 8 (1)";
        $license25->expiration_date = "2050-11-11";
        $license25->asset_id = 2;
        $license25->manufacturer_id = 15;
        $license25->obs = "Asignado";
        $license25->save();

        $license26 = new License();
        $license26->des = "Microsoft 365 Empresa Basic";
        $license26->serial = "Suscripción 9 (1)";
        $license26->expiration_date = "2050-11-11";
        $license26->asset_id = 3;
        $license26->manufacturer_id = 15;
        $license26->obs = "Asignado";
        $license26->save();

        $license27 = new License();
        $license27->des = "Microsoft 365 Empresa Basic";
        $license27->serial = "Suscripción 10 (1)";
        $license27->expiration_date = "2050-11-11";
        $license27->asset_id = 6;
        $license27->manufacturer_id = 15;
        $license27->obs = "Asignado";
        $license27->save();

        $license28 = new License();
        $license28->des = "Microsoft 365 Empresa Basic";
        $license28->serial = "Suscripción 11 (1)";
        $license28->expiration_date = "2050-11-11";
        $license28->asset_id = 7;
        $license28->manufacturer_id = 15;
        $license28->obs = "Asignado";
        $license28->save();

        $license29 = new License();
        $license29->des = "Microsoft 365 Empresa Basic";
        $license29->serial = "Suscripción 12 (1)";
        $license29->expiration_date = "2050-11-11";
        $license29->asset_id = 11;
        $license29->manufacturer_id = 15;
        $license29->obs = "Asignado";
        $license29->save();

        $license30 = new License();
        $license30->des = "Microsoft 365 Empresa Basic";
        $license30->serial = "Suscripción 13 (1)";
        $license30->expiration_date = "2050-11-11";
        $license30->asset_id = NULL;
        $license30->manufacturer_id = 15;
        $license30->obs = "Sin Asignar";
        $license30->save();

        $license31 = new License();
        $license31->des = "Microsoft 365 Empresa Basic";
        $license31->serial = "Suscripción 14 (1)";
        $license31->expiration_date = "2050-11-11";
        $license31->asset_id = NULL;
        $license31->manufacturer_id = 15;
        $license31->obs = "Sin Asignar";
        $license31->save();

        $license32 = new License();
        $license32->des = "Microsoft 365 Empresa Basic";
        $license32->serial = "Suscripción 15 (1)";
        $license32->expiration_date = "2050-11-11";
        $license32->asset_id = NULL;
        $license32->manufacturer_id = 15;
        $license32->obs = "Sin Asignar";
        $license32->save();

        $license33 = new License();
        $license33->des = "Microsoft 365 Empresa Basic";
        $license33->serial = "Suscripción 16 (1)";
        $license33->expiration_date = "2050-11-11";
        $license33->asset_id = NULL;
        $license33->manufacturer_id = 15;
        $license33->obs = "Sin Asignar";
        $license33->save();

        $license34 = new License();
        $license34->des = "Microsoft Office 2021 Professional";
        $license34->serial = "OEM";
        $license34->expiration_date = "2050-11-11";
        $license34->asset_id = 12;
        $license34->manufacturer_id = 15;
        $license34->obs = "Asignado";
        $license34->save();

        $license35 = new License();
        $license35->des = "Windows Server 2016 Standard";
        $license35->serial = "OEM";
        $license35->expiration_date = "2050-11-11";
        $license35->asset_id = 1;
        $license35->manufacturer_id = 15;
        $license35->obs = "Asignado";
        $license35->save();

        $license36 = new License();
        $license36->des = "Windows Server 2016 Standard";
        $license36->serial = "OEM";
        $license36->expiration_date = "2050-11-11";
        $license36->asset_id = 2;
        $license36->manufacturer_id = 15;
        $license36->obs = "Asignado";
        $license36->save();

        $license37 = new License();
        $license37->des = "Windows 10 Enterprise";
        $license37->serial = "OEM";
        $license37->expiration_date = "2050-11-11";
        $license37->asset_id = 3;
        $license37->manufacturer_id = 15;
        $license37->obs = "Asignado";
        $license37->save();

        $license38 = new License();
        $license38->des = "Windows 10 Home";
        $license38->serial = "OEM";
        $license38->expiration_date = "2050-11-11";
        $license38->asset_id = 4;
        $license38->manufacturer_id = 15;
        $license38->obs = "Asignado";
        $license38->save();

        $license39 = new License();
        $license39->des = "Windows 10 Home";
        $license39->serial = "OEM";
        $license39->expiration_date = "2050-11-11";
        $license39->asset_id = 5;
        $license39->manufacturer_id = 15;
        $license39->obs = "Asignado";
        $license39->save();

        $license40 = new License();
        $license40->des = "Windows 10 Home";
        $license40->serial = "OEM";
        $license40->expiration_date = "2050-11-11";
        $license40->asset_id = 6;
        $license40->manufacturer_id = 15;
        $license40->obs = "Asignado";
        $license40->save();

        $license41 = new License();
        $license41->des = "Windows 10 Enterprise";
        $license41->serial = "OEM";
        $license41->expiration_date = "2050-11-11";
        $license41->asset_id = 7;
        $license41->manufacturer_id = 15;
        $license41->obs = "Asignado";
        $license41->save();

        $license42 = new License();
        $license42->des = "Windows 10 Enterprise";
        $license42->serial = "OEM";
        $license42->expiration_date = "2050-11-11";
        $license42->asset_id = 8;
        $license42->manufacturer_id = 15;
        $license42->obs = "Asignado";
        $license42->save();

        $license43 = new License();
        $license43->des = "Windows 10 Enterprise";
        $license43->serial = "OEM";
        $license43->expiration_date = "2050-11-11";
        $license43->asset_id = 9;
        $license43->manufacturer_id = 15;
        $license43->obs = "Asignado";
        $license43->save();

        $license44 = new License();
        $license44->des = "Windows 10 Enterprise";
        $license44->serial = "OEM";
        $license44->expiration_date = "2050-11-11";
        $license44->asset_id = 10;
        $license44->manufacturer_id = 15;
        $license44->obs = "Asignado";
        $license44->save();

        $license45 = new License();
        $license45->des = "Windows 10 Enterprise";
        $license45->serial = "OEM";
        $license45->expiration_date = "2050-11-11";
        $license45->asset_id = 11;
        $license45->manufacturer_id = 15;
        $license45->obs = "Asignado";
        $license45->save();

        $license46 = new License();
        $license46->des = "Windows 11 Home";
        $license46->serial = "OEM";
        $license46->expiration_date = "2050-11-11";
        $license46->asset_id = 12;
        $license46->manufacturer_id = 15;
        $license46->obs = "Asignado";
        $license46->save();


    }
}
