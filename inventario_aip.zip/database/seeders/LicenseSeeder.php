<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use App\Models\License;

class LicenseSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $license01 = new License();
        $license01->des = "Kaspersky Small Office Security (Ser)";
        $license01->serial = "2JYCQ-CV4BF-UC21D-U5HRH";
        $license01->expiration_date = "2024-05-20";
        $license01->asset_id = 1;
        $license01->manufacturer_id = 16;
        $license01->obs = "Asignado";
        $license01->save();
        
        $license02 = new License();
        $license02->des = "Kaspersky Small Office Security (Pc)";
        $license02->serial = "2JYCQ-CV4BF-UC21D-U5HRH";
        $license02->expiration_date = "2024-05-20";
        $license02->asset_id = 3;
        $license02->manufacturer_id = 16;
        $license02->obs = "Asignado";
        $license02->save();
        
        $license03 = new License();
        $license03->des = "Kaspersky Small Office Security (Pc)";
        $license03->serial = "2JYCQ-CV4BF-UC21D-U5HRH";
        $license03->expiration_date = "2024-05-20";
        $license03->asset_id = 4;
        $license03->manufacturer_id = 16;
        $license03->obs = "Asignado";
        $license03->save();
        
        $license04 = new License();
        $license04->des = "Kaspersky Small Office Security (Pc)";
        $license04->serial = "2JYCQ-CV4BF-UC21D-U5HRH";
        $license04->expiration_date = "2024-05-20";
        $license04->asset_id = 5;
        $license04->manufacturer_id = 16;
        $license04->obs = "Asignado";
        $license04->save();
        
        $license05 = new License();
        $license05->des = "Kaspersky Small Office Security (Pc)";
        $license05->serial = "2JYCQ-CV4BF-UC21D-U5HRH";
        $license05->expiration_date = "2024-05-20";
        $license05->asset_id = 7;
        $license05->manufacturer_id = 16;
        $license05->obs = "Asignado";
        $license05->save();
        
        $license06 = new License();
        $license06->des = "Kaspersky Small Office Security (Pc)";
        $license06->serial = "2JYCQ-CV4BF-UC21D-U5HRH";
        $license06->expiration_date = "2024-05-20";
        $license06->asset_id = 8;
        $license06->manufacturer_id = 16;
        $license06->obs = "Asignado";
        $license06->save();
        
        $license07 = new License();
        $license07->des = "Kaspersky Small Office Security (Pc)";
        $license07->serial = "2JYCQ-CV4BF-UC21D-U5HRH";
        $license07->expiration_date = "2024-05-20";
        $license07->asset_id = 10;
        $license07->manufacturer_id = 16;
        $license07->obs = "Asignado";
        $license07->save();
        
        $license08 = new License();
        $license08->des = "Kaspersky Small Office Security (Pc)";
        $license08->serial = "2JYCQ-CV4BF-UC21D-U5HRH";
        $license08->expiration_date = "2024-05-20";
        $license08->asset_id = 11;
        $license08->manufacturer_id = 16;
        $license08->obs = "Asignado";
        $license08->save();
        
        $license09 = new License();
        $license09->des = "Kaspersky Small Office Security (Pc)";
        $license09->serial = "2JYCQ-CV4BF-UC21D-U5HRH";
        $license09->expiration_date = "2024-05-20";
        $license09->asset_id = 12;
        $license09->manufacturer_id = 16;
        $license09->obs = "Asignado";
        $license09->save();
        
        $license10 = new License();
        $license10->des = "Kaspersky Small Office Security (Pc)";
        $license10->serial = "2JYCQ-CV4BF-UC21D-U5HRH";
        $license10->expiration_date = "2024-05-20";
        $license10->asset_id = 13;
        $license10->manufacturer_id = 16;
        $license10->obs = "Asignado";
        $license10->save();
        
        $license11 = new License();
        $license11->des = "Kaspersky Small Office Security (Pc)";
        $license11->serial = "2JYCQ-CV4BF-UC21D-U5HRH";
        $license11->expiration_date = "2024-05-20";
        $license11->asset_id = 14;
        $license11->manufacturer_id = 16;
        $license11->obs = "Asignado";
        $license11->save();
        
        $license12 = new License();
        $license12->des = "Kaspersky Small Office Security (Ser)";
        $license12->serial = "5VPXS-TU5QH-ZU59K-6WB58";
        $license12->expiration_date = "2024-05-20";
        $license12->asset_id = 2;
        $license12->manufacturer_id = 16;
        $license12->obs = "Asignado";
        $license12->save();
        
        $license13 = new License();
        $license13->des = "Kaspersky Small Office Security (Pc)";
        $license13->serial = "5VPXS-TU5QH-ZU59K-6WB58";
        $license13->expiration_date = "2024-05-20";
        $license13->asset_id = 6;
        $license13->manufacturer_id = 16;
        $license13->obs = "Asignado";
        $license13->save();
        
        $license14 = new License();
        $license14->des = "Kaspersky Small Office Security (Pc)";
        $license14->serial = "5VPXS-TU5QH-ZU59K-6WB58";
        $license14->expiration_date = "2024-05-20";
        $license14->asset_id = 9;
        $license14->manufacturer_id = 16;
        $license14->obs = "Asignado";
        $license14->save();
        
        $license15 = new License();
        $license15->des = "Kaspersky Small Office Security (Pc)";
        $license15->serial = "5VPXS-TU5QH-ZU59K-6WB58";
        $license15->expiration_date = "2024-05-20";
        $license15->asset_id = 15;
        $license15->manufacturer_id = 16;
        $license15->obs = "Asignado";
        $license15->save();
        
        $license16 = new License();
        $license16->des = "Kaspersky Small Office Security (Pc)";
        $license16->serial = "5VPXS-TU5QH-ZU59K-6WB58";
        $license16->expiration_date = "2024-05-20";
        $license16->asset_id = 16;
        $license16->manufacturer_id = 16;
        $license16->obs = "Asignado";
        $license16->save();
        
        $license17 = new License();
        $license17->des = "Kaspersky Small Office Security (Pc)";
        $license17->serial = "5VPXS-TU5QH-ZU59K-6WB58";
        $license17->expiration_date = "2024-05-20";
        $license17->asset_id = 17;
        $license17->manufacturer_id = 16;
        $license17->obs = "Asignado";
        $license17->save();
        
        $license18 = new License();
        $license18->des = "Kaspersky Small Office Security (Pc)";
        $license18->serial = "5VPXS-TU5QH-ZU59K-6WB58";
        $license18->expiration_date = "2024-05-20";
        $license18->asset_id = 18;
        $license18->manufacturer_id = 16;
        $license18->obs = "Asignado";
        $license18->save();
        
        $license19 = new License();
        $license19->des = "Kaspersky Small Office Security (Pc)";
        $license19->serial = "5VPXS-TU5QH-ZU59K-6WB58";
        $license19->expiration_date = "2024-05-20";
        $license19->asset_id = NULL;
        $license19->manufacturer_id = 16;
        $license19->obs = "Sin Asignar";
        $license19->save();
        
        $license20 = new License();
        $license20->des = "Kaspersky Small Office Security (Pc)";
        $license20->serial = "5VPXS-TU5QH-ZU59K-6WB58";
        $license20->expiration_date = "2024-05-20";
        $license20->asset_id = NULL;
        $license20->manufacturer_id = 16;
        $license20->obs = "Sin Asignar";
        $license20->save();
        
        $license21 = new License();
        $license21->des = "Kaspersky Small Office Security (Pc)";
        $license21->serial = "5VPXS-TU5QH-ZU59K-6WB58";
        $license21->expiration_date = "2024-05-20";
        $license21->asset_id = NULL;
        $license21->manufacturer_id = 16;
        $license21->obs = "Sin Asignar";
        $license21->save();
        
        $license22 = new License();
        $license22->des = "Kaspersky Small Office Security (Pc)";
        $license22->serial = "5VPXS-TU5QH-ZU59K-6WB58";
        $license22->expiration_date = "2024-05-20";
        $license22->asset_id = NULL;
        $license22->manufacturer_id = 16;
        $license22->obs = "Sin Asignar";
        $license22->save();

        $license23 = new License();
        $license23->des = "Kaspersky Small Office Security (Ser)";
        $license23->serial = "D9HHP-4MVAK-5G2AV-R81SF";
        $license23->expiration_date = "2024-05-23";
        $license23->asset_id = 19;
        $license23->manufacturer_id = 16;
        $license23->obs = "Asignado";
        $license23->save();
        
        $license24 = new License();
        $license24->des = "Kaspersky Small Office Security (Pc)";
        $license24->serial = "D9HHP-4MVAK-5G2AV-R81SF";
        $license24->expiration_date = "2024-05-23";
        $license24->asset_id = 21;
        $license24->manufacturer_id = 16;
        $license24->obs = "Asignado";
        $license24->save();
        
        $license25 = new License();
        $license25->des = "Kaspersky Small Office Security (Pc)";
        $license25->serial = "D9HHP-4MVAK-5G2AV-R81SF";
        $license25->expiration_date = "2024-05-23";
        $license25->asset_id = 22;
        $license25->manufacturer_id = 16;
        $license25->obs = "Asignado";
        $license25->save();
        
        $license26 = new License();
        $license26->des = "Kaspersky Small Office Security (Pc)";
        $license26->serial = "D9HHP-4MVAK-5G2AV-R81SF";
        $license26->expiration_date = "2024-05-23";
        $license26->asset_id = 23;
        $license26->manufacturer_id = 16;
        $license26->obs = "Asignado";
        $license26->save();
        
        $license27 = new License();
        $license27->des = "Kaspersky Small Office Security (Pc)";
        $license27->serial = "D9HHP-4MVAK-5G2AV-R81SF";
        $license27->expiration_date = "2024-05-23";
        $license27->asset_id = 25;
        $license27->manufacturer_id = 16;
        $license27->obs = "Asignado";
        $license27->save();
        
        $license28 = new License();
        $license28->des = "Kaspersky Small Office Security (Pc)";
        $license28->serial = "D9HHP-4MVAK-5G2AV-R81SF";
        $license28->expiration_date = "2024-05-23";
        $license28->asset_id = 26;
        $license28->manufacturer_id = 16;
        $license28->obs = "Asignado";
        $license28->save();
        
        $license29 = new License();
        $license29->des = "Kaspersky Small Office Security (Pc)";
        $license29->serial = "D9HHP-4MVAK-5G2AV-R81SF";
        $license29->expiration_date = "2024-05-23";
        $license29->asset_id = 27;
        $license29->manufacturer_id = 16;
        $license29->obs = "Asignado";
        $license29->save();
        
        $license30 = new License();
        $license30->des = "Kaspersky Small Office Security (Pc)";
        $license30->serial = "D9HHP-4MVAK-5G2AV-R81SF";
        $license30->expiration_date = "2024-05-23";
        $license30->asset_id = 30;
        $license30->manufacturer_id = 16;
        $license30->obs = "Asignado";
        $license30->save();
        
        $license31 = new License();
        $license31->des = "Kaspersky Small Office Security (Pc)";
        $license31->serial = "D9HHP-4MVAK-5G2AV-R81SF";
        $license31->expiration_date = "2024-05-23";
        $license31->asset_id = 31;
        $license31->manufacturer_id = 16;
        $license31->obs = "Asignado";
        $license31->save();
        
        $license32 = new License();
        $license32->des = "Kaspersky Small Office Security (Pc)";
        $license32->serial = "D9HHP-4MVAK-5G2AV-R81SF";
        $license32->expiration_date = "2024-05-23";
        $license32->asset_id = 32;
        $license32->manufacturer_id = 16;
        $license32->obs = "Asignado";
        $license32->save();
        
        $license33 = new License();
        $license33->des = "Kaspersky Small Office Security (Pc)";
        $license33->serial = "D9HHP-4MVAK-5G2AV-R81SF";
        $license33->expiration_date = "2024-05-23";
        $license33->asset_id = 33;
        $license33->manufacturer_id = 16;
        $license33->obs = "Asignado";
        $license33->save();

        $license34 = new License();
        $license34->des = "Kaspersky Small Office Security (Ser)";
        $license34->serial = "JSBZW-261ZD-ZZYNK-X4WUU";
        $license34->expiration_date = "2024-05-23";
        $license34->asset_id = 20;
        $license34->manufacturer_id = 16;
        $license34->obs = "Asignado";
        $license34->save();
        
        $license35 = new License();
        $license35->des = "Kaspersky Small Office Security (Pc)";
        $license35->serial = "JSBZW-261ZD-ZZYNK-X4WUU";
        $license35->expiration_date = "2024-05-23";
        $license35->asset_id = 36;
        $license35->manufacturer_id = 16;
        $license35->obs = "Asignado";
        $license35->save();
        
        $license36 = new License();
        $license36->des = "Kaspersky Small Office Security (Pc)";
        $license36->serial = "JSBZW-261ZD-ZZYNK-X4WUU";
        $license36->expiration_date = "2024-05-23";
        $license36->asset_id = 37;
        $license36->manufacturer_id = 16;
        $license36->obs = "Asignado";
        $license36->save();
        
        $license37 = new License();
        $license37->des = "Kaspersky Small Office Security (Pc)";
        $license37->serial = "JSBZW-261ZD-ZZYNK-X4WUU";
        $license37->expiration_date = "2024-05-23";
        $license37->asset_id = 38;
        $license37->manufacturer_id = 16;
        $license37->obs = "Asignado";
        $license37->save();
        
        $license38 = new License();
        $license38->des = "Kaspersky Small Office Security (Pc)";
        $license38->serial = "JSBZW-261ZD-ZZYNK-X4WUU";
        $license38->expiration_date = "2024-05-23";
        $license38->asset_id = 39;
        $license38->manufacturer_id = 16;
        $license38->obs = "Asignado";
        $license38->save();
        
        $license39 = new License();
        $license39->des = "Kaspersky Small Office Security (Pc)";
        $license39->serial = "JSBZW-261ZD-ZZYNK-X4WUU";
        $license39->expiration_date = "2024-05-23";
        $license39->asset_id = 40;
        $license39->manufacturer_id = 16;
        $license39->obs = "Asignado";
        $license39->save();
        
        $license40 = new License();
        $license40->des = "Kaspersky Small Office Security (Pc)";
        $license40->serial = "JSBZW-261ZD-ZZYNK-X4WUU";
        $license40->expiration_date = "2024-05-23";
        $license40->asset_id = 41;
        $license40->manufacturer_id = 16;
        $license40->obs = "Asignado";
        $license40->save();
        
        $license41 = new License();
        $license41->des = "Kaspersky Small Office Security (Pc)";
        $license41->serial = "JSBZW-261ZD-ZZYNK-X4WUU";
        $license41->expiration_date = "2024-05-23";
        $license41->asset_id = 42;
        $license41->manufacturer_id = 16;
        $license41->obs = "Asignado";
        $license41->save();
        
        $license42 = new License();
        $license42->des = "Kaspersky Small Office Security (Pc)";
        $license42->serial = "JSBZW-261ZD-ZZYNK-X4WUU";
        $license42->expiration_date = "2024-05-23";
        $license42->asset_id = 43;
        $license42->manufacturer_id = 16;
        $license42->obs = "Asignado";
        $license42->save();
        
        $license43 = new License();
        $license43->des = "Kaspersky Small Office Security (Pc)";
        $license43->serial = "JSBZW-261ZD-ZZYNK-X4WUU";
        $license43->expiration_date = "2024-05-23";
        $license43->asset_id = 45;
        $license43->manufacturer_id = 16;
        $license43->obs = "Asignado";
        $license43->save();
        
        $license44 = new License();
        $license44->des = "Kaspersky Small Office Security (Pc)";
        $license44->serial = "JSBZW-261ZD-ZZYNK-X4WUU";
        $license44->expiration_date = "2024-05-23";
        $license44->asset_id = 46;
        $license44->manufacturer_id = 16;
        $license44->obs = "Asignado";
        $license44->save();

        $license45 = new License();
        $license45->des = "Kaspersky Small Office Security (Ser)";
        $license45->serial = "MURAH-BXCYQ-X2CGE-3RC56";
        $license45->expiration_date = "2024-05-23";
        $license45->asset_id = NULL;
        $license45->manufacturer_id = 16;
        $license45->obs = "Sin Asignar";
        $license45->save();
        
        $license46 = new License();
        $license46->des = "Kaspersky Small Office Security (Pc)";
        $license46->serial = "MURAH-BXCYQ-X2CGE-3RC56";
        $license46->expiration_date = "2024-05-23";
        $license46->asset_id = 24;
        $license46->manufacturer_id = 16;
        $license46->obs = "Asignado";
        $license46->save();
        
        $license47 = new License();
        $license47->des = "Kaspersky Small Office Security (Pc)";
        $license47->serial = "MURAH-BXCYQ-X2CGE-3RC56";
        $license47->expiration_date = "2024-05-23";
        $license47->asset_id = 28;
        $license47->manufacturer_id = 16;
        $license47->obs = "Asignado";
        $license47->save();
        
        $license48 = new License();
        $license48->des = "Kaspersky Small Office Security (Pc)";
        $license48->serial = "MURAH-BXCYQ-X2CGE-3RC56";
        $license48->expiration_date = "2024-05-23";
        $license48->asset_id = 29;
        $license48->manufacturer_id = 16;
        $license48->obs = "Asignado";
        $license48->save();
        
        $license49 = new License();
        $license49->des = "Kaspersky Small Office Security (Pc)";
        $license49->serial = "MURAH-BXCYQ-X2CGE-3RC56";
        $license49->expiration_date = "2024-05-23";
        $license49->asset_id = 34;
        $license49->manufacturer_id = 16;
        $license49->obs = "Asignado";
        $license49->save();
        
        $license50 = new License();
        $license50->des = "Kaspersky Small Office Security (Pc)";
        $license50->serial = "MURAH-BXCYQ-X2CGE-3RC56";
        $license50->expiration_date = "2024-05-23";
        $license50->asset_id = 35;
        $license50->manufacturer_id = 16;
        $license50->obs = "Asignado";
        $license50->save();
        
        $license51 = new License();
        $license51->des = "Kaspersky Small Office Security (Pc)";
        $license51->serial = "MURAH-BXCYQ-X2CGE-3RC56";
        $license51->expiration_date = "2024-05-23";
        $license51->asset_id = 47;
        $license51->manufacturer_id = 16;
        $license51->obs = "Asignado";
        $license51->save();
        
        $license52 = new License();
        $license52->des = "Kaspersky Small Office Security (Pc)";
        $license52->serial = "MURAH-BXCYQ-X2CGE-3RC56";
        $license52->expiration_date = "2024-05-23";
        $license52->asset_id = 48;
        $license52->manufacturer_id = 16;
        $license52->obs = "Asignado";
        $license52->save();
        
        $license53 = new License();
        $license53->des = "Kaspersky Small Office Security (Pc)";
        $license53->serial = "MURAH-BXCYQ-X2CGE-3RC56";
        $license53->expiration_date = "2024-05-23";
        $license53->asset_id = 58;
        $license53->manufacturer_id = 16;
        $license53->obs = "Asignado";
        $license53->save();
        
        $license54 = new License();
        $license54->des = "Kaspersky Small Office Security (Pc)";
        $license54->serial = "MURAH-BXCYQ-X2CGE-3RC56";
        $license54->expiration_date = "2024-05-23";
        $license54->asset_id = 62;
        $license54->manufacturer_id = 16;
        $license54->obs = "Asignado";
        $license54->save();
        
        $license55 = new License();
        $license55->des = "Kaspersky Small Office Security (Pc)";
        $license55->serial = "MURAH-BXCYQ-X2CGE-3RC56";
        $license55->expiration_date = "2024-05-23";
        $license55->asset_id = NULL;
        $license55->manufacturer_id = 16;
        $license55->obs = "Sin Asignar";
        $license55->save();

        $license56 = new License();
        $license56->des = "Kaspersky Small Office Security (Ser)";
        $license56->serial = "T5RZJ-XNTVU-SCKW5-87G81";
        $license56->expiration_date = "2024-05-23";
        $license56->asset_id = NULL;
        $license56->manufacturer_id = 16;
        $license56->obs = "Sin Asignar";
        $license56->save();
        
        $license57 = new License();
        $license57->des = "Kaspersky Small Office Security (Pc)";
        $license57->serial = "T5RZJ-XNTVU-SCKW5-87G81";
        $license57->expiration_date = "2024-05-23";
        $license57->asset_id = 49;
        $license57->manufacturer_id = 16;
        $license57->obs = "Asignado";
        $license57->save();
        
        $license58 = new License();
        $license58->des = "Kaspersky Small Office Security (Pc)";
        $license58->serial = "T5RZJ-XNTVU-SCKW5-87G81";
        $license58->expiration_date = "2024-05-23";
        $license58->asset_id = 50;
        $license58->manufacturer_id = 16;
        $license58->obs = "Asignado";
        $license58->save();
        
        $license59 = new License();
        $license59->des = "Kaspersky Small Office Security (Pc)";
        $license59->serial = "T5RZJ-XNTVU-SCKW5-87G81";
        $license59->expiration_date = "2024-05-23";
        $license59->asset_id = 51;
        $license59->manufacturer_id = 16;
        $license59->obs = "Asignado";
        $license59->save();
        
        $license60 = new License();
        $license60->des = "Kaspersky Small Office Security (Pc)";
        $license60->serial = "T5RZJ-XNTVU-SCKW5-87G81";
        $license60->expiration_date = "2024-05-23";
        $license60->asset_id = 52;
        $license60->manufacturer_id = 16;
        $license60->obs = "Asignado";
        $license60->save();
        
        $license61 = new License();
        $license61->des = "Kaspersky Small Office Security (Pc)";
        $license61->serial = "T5RZJ-XNTVU-SCKW5-87G81";
        $license61->expiration_date = "2024-05-23";
        $license61->asset_id = 53;
        $license61->manufacturer_id = 16;
        $license61->obs = "Asignado";
        $license61->save();
        
        $license62 = new License();
        $license62->des = "Kaspersky Small Office Security (Pc)";
        $license62->serial = "T5RZJ-XNTVU-SCKW5-87G81";
        $license62->expiration_date = "2024-05-23";
        $license62->asset_id = 54;
        $license62->manufacturer_id = 16;
        $license62->obs = "Asignado";
        $license62->save();
        
        $license63 = new License();
        $license63->des = "Kaspersky Small Office Security (Pc)";
        $license63->serial = "T5RZJ-XNTVU-SCKW5-87G81";
        $license63->expiration_date = "2024-05-23";
        $license63->asset_id = 55;
        $license63->manufacturer_id = 16;
        $license63->obs = "Asignado";
        $license63->save();
        
        $license64 = new License();
        $license64->des = "Kaspersky Small Office Security (Pc)";
        $license64->serial = "T5RZJ-XNTVU-SCKW5-87G81";
        $license64->expiration_date = "2024-05-23";
        $license64->asset_id = 56;
        $license64->manufacturer_id = 16;
        $license64->obs = "Asignado";
        $license64->save();
        
        $license65 = new License();
        $license65->des = "Kaspersky Small Office Security (Pc)";
        $license65->serial = "T5RZJ-XNTVU-SCKW5-87G81";
        $license65->expiration_date = "2024-05-23";
        $license65->asset_id = 57;
        $license65->manufacturer_id = 16;
        $license65->obs = "Asignado";
        $license65->save();
        
        $license66 = new License();
        $license66->des = "Kaspersky Small Office Security (Pc)";
        $license66->serial = "T5RZJ-XNTVU-SCKW5-87G81";
        $license66->expiration_date = "2024-05-23";
        $license66->asset_id = 59;
        $license66->manufacturer_id = 16;
        $license66->obs = "Asignado";
        $license66->save();

        $license67 = new License();
        $license67->des = "Microsoft 365 Empresa Premium";
        $license67->serial = "Suscripción 1 (1)";
        $license67->expiration_date = "2023-10-20";
        $license67->asset_id = 3;
        $license67->manufacturer_id = 15;
        $license67->obs = "Asignado";
        $license67->save();

        $license68 = new License();
        $license68->des = "Microsoft 365 Empresa Premium";
        $license68->serial = "Suscripción 1 (2)";
        $license68->expiration_date = "2023-10-20";
        $license68->asset_id = 4;
        $license68->manufacturer_id = 15;
        $license68->obs = "Asignado";
        $license68->save();

        $license69 = new License();
        $license69->des = "Microsoft 365 Empresa Premium";
        $license69->serial = "Suscripción 2 (1)";
        $license69->expiration_date = "2023-10-20";
        $license69->asset_id = 8;
        $license69->manufacturer_id = 15;
        $license69->obs = "Asignado";
        $license69->save();

        $license70 = new License();
        $license70->des = "Microsoft 365 Empresa Premium";
        $license70->serial = "Suscripción 2 (2)";
        $license70->expiration_date = "2023-10-20";
        $license70->asset_id = 9;
        $license70->manufacturer_id = 15;
        $license70->obs = "Asignado";
        $license70->save();

        $license71 = new License();
        $license71->des = "Microsoft 365 Empresa Premium";
        $license71->serial = "Suscripción 3 (1)";
        $license71->expiration_date = "2023-10-20";
        $license71->asset_id = 11;
        $license71->manufacturer_id = 15;
        $license71->obs = "Asignado";
        $license71->save();

        $license72 = new License();
        $license72->des = "Microsoft 365 Empresa Premium";
        $license72->serial = "Suscripción 4 (1)";
        $license72->expiration_date = "2023-10-20";
        $license72->asset_id = 13;
        $license72->manufacturer_id = 15;
        $license72->obs = "Asignado";
        $license72->save();

        $license73 = new License();
        $license73->des = "Microsoft 365 Empresa Premium";
        $license73->serial = "Suscripción 4 (2)";
        $license73->expiration_date = "2023-10-20";
        $license73->asset_id = 14;
        $license73->manufacturer_id = 15;
        $license73->obs = "Asignado";
        $license73->save();

        $license74 = new License();
        $license74->des = "Microsoft 365 Empresa Premium";
        $license74->serial = "Suscripción 5 (1)";
        $license74->expiration_date = "2023-10-20";
        $license74->asset_id = 17;
        $license74->manufacturer_id = 15;
        $license74->obs = "Asignado";
        $license74->save();

        $license75 = new License();
        $license75->des = "Microsoft 365 Empresa Premium";
        $license75->serial = "Suscripción 5 (2)";
        $license75->expiration_date = "2023-10-20";
        $license75->asset_id = 18;
        $license75->manufacturer_id = 15;
        $license75->obs = "Asignado";
        $license75->save();

        $license76 = new License();
        $license76->des = "Microsoft 365 Empresa Premium";
        $license76->serial = "Suscripción 6 (1)";
        $license76->expiration_date = "2023-10-20";
        $license76->asset_id = 21;
        $license76->manufacturer_id = 15;
        $license76->obs = "Asignado";
        $license76->save();

        $license77 = new License();
        $license77->des = "Microsoft 365 Empresa Premium";
        $license77->serial = "Suscripción 7 (1)";
        $license77->expiration_date = "2023-10-20";
        $license77->asset_id = 23;
        $license77->manufacturer_id = 15;
        $license77->obs = "Asignado";
        $license77->save();

        $license78 = new License();
        $license78->des = "Microsoft 365 Empresa Premium";
        $license78->serial = "Suscripción 8 (1)";
        $license78->expiration_date = "2023-10-20";
        $license78->asset_id = 24;
        $license78->manufacturer_id = 15;
        $license78->obs = "Asignado";
        $license78->save();

        $license79 = new License();
        $license79->des = "Microsoft 365 Empresa Premium";
        $license79->serial = "Suscripción 9 (1)";
        $license79->expiration_date = "2023-10-20";
        $license79->asset_id = 34;
        $license79->manufacturer_id = 15;
        $license79->obs = "Asignado";
        $license79->save();

        $license80 = new License();
        $license80->des = "Microsoft 365 Empresa Premium";
        $license80->serial = "Suscripción 10 (1)";
        $license80->expiration_date = "2023-10-20";
        $license80->asset_id = 42;
        $license80->manufacturer_id = 15;
        $license80->obs = "Asignado";
        $license80->save();

        $license81 = new License();
        $license81->des = "Microsoft 365 Empresa Basic";
        $license81->serial = "Suscripción 1 (1)";
        $license81->expiration_date = "2023-10-20";
        $license81->asset_id = 1;
        $license81->manufacturer_id = 15;
        $license81->obs = "Asignado";
        $license81->save();

        $license82 = new License();
        $license82->des = "Microsoft 365 Empresa Basic";
        $license82->serial = "Suscripción 2 (1)";
        $license82->expiration_date = "2023-10-20";
        $license82->asset_id = 2;
        $license82->manufacturer_id = 15;
        $license82->obs = "Asignado";
        $license82->save();

        $license83 = new License();
        $license83->des = "Microsoft 365 Empresa Basic";
        $license83->serial = "Suscripción 3 (1)";
        $license83->expiration_date = "2023-10-20";
        $license83->asset_id = 5;
        $license83->manufacturer_id = 15;
        $license83->obs = "Asignado";
        $license83->save();

        $license84 = new License();
        $license84->des = "Microsoft 365 Empresa Basic";
        $license84->serial = "Suscripción 4 (1)";
        $license84->expiration_date = "2023-10-20";
        $license84->asset_id = 6;
        $license84->manufacturer_id = 15;
        $license84->obs = "Asignado";
        $license84->save();

        $license85 = new License();
        $license85->des = "Microsoft 365 Empresa Basic";
        $license85->serial = "Suscripción 5 (1)";
        $license85->expiration_date = "2023-10-20";
        $license85->asset_id = 7;
        $license85->manufacturer_id = 15;
        $license85->obs = "Asignado";
        $license85->save();

        $license86 = new License();
        $license86->des = "Microsoft 365 Empresa Basic";
        $license86->serial = "Suscripción 6 (1)";
        $license86->expiration_date = "2023-10-20";
        $license86->asset_id = 10;
        $license86->manufacturer_id = 15;
        $license86->obs = "Asignado";
        $license86->save();

        $license87 = new License();
        $license87->des = "Microsoft 365 Empresa Basic";
        $license87->serial = "Suscripción 7 (1)";
        $license87->expiration_date = "2023-10-20";
        $license87->asset_id = 12;
        $license87->manufacturer_id = 15;
        $license87->obs = "Asignado";
        $license87->save();

        $license88 = new License();
        $license88->des = "Microsoft 365 Empresa Basic";
        $license88->serial = "Suscripción 8 (1)";
        $license88->expiration_date = "2023-10-20";
        $license88->asset_id = 15;
        $license88->manufacturer_id = 15;
        $license88->obs = "Asignado";
        $license88->save();

        $license89 = new License();
        $license89->des = "Microsoft 365 Empresa Basic";
        $license89->serial = "Suscripción 9 (1)";
        $license89->expiration_date = "2023-10-20";
        $license89->asset_id = 16;
        $license89->manufacturer_id = 15;
        $license89->obs = "Asignado";
        $license89->save();

        $license90 = new License();
        $license90->des = "Microsoft 365 Empresa Basic";
        $license90->serial = "Suscripción 10 (1)";
        $license90->expiration_date = "2023-10-20";
        $license90->asset_id = 19;
        $license90->manufacturer_id = 15;
        $license90->obs = "Asignado";
        $license90->save();

        $license91 = new License();
        $license91->des = "Microsoft 365 Empresa Basic";
        $license91->serial = "Suscripción 11 (1)";
        $license91->expiration_date = "2023-10-20";
        $license91->asset_id = 20;
        $license91->manufacturer_id = 15;
        $license91->obs = "Asignado";
        $license91->save();

        $license92 = new License();
        $license92->des = "Microsoft 365 Empresa Basic";
        $license92->serial = "Suscripción 12 (1)";
        $license92->expiration_date = "2023-10-20";
        $license92->asset_id = 22;
        $license92->manufacturer_id = 15;
        $license92->obs = "Asignado";
        $license92->save();

        $license93 = new License();
        $license93->des = "Microsoft 365 Empresa Basic";
        $license93->serial = "Suscripción 13 (1)";
        $license93->expiration_date = "2023-10-20";
        $license93->asset_id = 25;
        $license93->manufacturer_id = 15;
        $license93->obs = "Asignado";
        $license93->save();

        $license94 = new License();
        $license94->des = "Microsoft 365 Empresa Basic";
        $license94->serial = "Suscripción 14 (1)";
        $license94->expiration_date = "2023-10-20";
        $license94->asset_id = 26;
        $license94->manufacturer_id = 15;
        $license94->obs = "Asignado";
        $license94->save();

        $license95 = new License();
        $license95->des = "Microsoft 365 Empresa Basic";
        $license95->serial = "Suscripción 15 (1)";
        $license95->expiration_date = "2023-10-20";
        $license95->asset_id = 27;
        $license95->manufacturer_id = 15;
        $license95->obs = "Asignado";
        $license95->save();

        $license96 = new License();
        $license96->des = "Microsoft 365 Empresa Basic";
        $license96->serial = "Suscripción 16 (1)";
        $license96->expiration_date = "2023-10-20";
        $license96->asset_id = 28;
        $license96->manufacturer_id = 15;
        $license96->obs = "Asignado";
        $license96->save();

        $license97 = new License();
        $license97->des = "Microsoft 365 Empresa Basic";
        $license97->serial = "Suscripción 17 (1)";
        $license97->expiration_date = "2023-10-20";
        $license97->asset_id = 29;
        $license97->manufacturer_id = 15;
        $license97->obs = "Asignado";
        $license97->save();

        $license98 = new License();
        $license98->des = "Microsoft 365 Empresa Basic";
        $license98->serial = "Suscripción 18 (1)";
        $license98->expiration_date = "2023-10-20";
        $license98->asset_id = 30;
        $license98->manufacturer_id = 15;
        $license98->obs = "Asignado";
        $license98->save();

        $license99 = new License();
        $license99->des = "Microsoft 365 Empresa Basic";
        $license99->serial = "Suscripción 19 (1)";
        $license99->expiration_date = "2023-10-20";
        $license99->asset_id = 31;
        $license99->manufacturer_id = 15;
        $license99->obs = "Asignado";
        $license99->save();

        $license100 = new License();
        $license100->des = "Microsoft 365 Empresa Basic";
        $license100->serial = "Suscripción 20 (1)";
        $license100->expiration_date = "2023-10-20";
        $license100->asset_id = 32;
        $license100->manufacturer_id = 15;
        $license100->obs = "Asignado";
        $license100->save();

        $license101 = new License();
        $license101->des = "Microsoft 365 Empresa Basic";
        $license101->serial = "Suscripción 21 (1)";
        $license101->expiration_date = "2023-10-20";
        $license101->asset_id = 33;
        $license101->manufacturer_id = 15;
        $license101->obs = "Asignado";
        $license101->save();

        $license102 = new License();
        $license102->des = "Microsoft 365 Empresa Basic";
        $license102->serial = "Suscripción 22 (1)";
        $license102->expiration_date = "2023-10-20";
        $license102->asset_id = 36;
        $license102->manufacturer_id = 15;
        $license102->obs = "Asignado";
        $license102->save();

        $license103 = new License();
        $license103->des = "Microsoft 365 Empresa Basic";
        $license103->serial = "Suscripción 23 (1)";
        $license103->expiration_date = "2023-10-20";
        $license103->asset_id = 37;
        $license103->manufacturer_id = 15;
        $license103->obs = "Asignado";
        $license103->save();

        $license104 = new License();
        $license104->des = "Microsoft 365 Empresa Basic";
        $license104->serial = "Suscripción 24 (1)";
        $license104->expiration_date = "2023-10-20";
        $license104->asset_id = 38;
        $license104->manufacturer_id = 15;
        $license104->obs = "Asignado";
        $license104->save();

        $license105 = new License();
        $license105->des = "Microsoft 365 Empresa Basic";
        $license105->serial = "Suscripción 25 (1)";
        $license105->expiration_date = "2023-10-20";
        $license105->asset_id = 39;
        $license105->manufacturer_id = 15;
        $license105->obs = "Asignado";
        $license105->save();

        $license106 = new License();
        $license106->des = "Microsoft 365 Empresa Basic";
        $license106->serial = "Suscripción 26 (1)";
        $license106->expiration_date = "2023-10-20";
        $license106->asset_id = 40;
        $license106->manufacturer_id = 15;
        $license106->obs = "Asignado";
        $license106->save();

        $license107 = new License();
        $license107->des = "Microsoft 365 Empresa Basic";
        $license107->serial = "Suscripción 27 (1)";
        $license107->expiration_date = "2023-10-20";
        $license107->asset_id = 41;
        $license107->manufacturer_id = 15;
        $license107->obs = "Asignado";
        $license107->save();

        $license108 = new License();
        $license108->des = "Microsoft 365 Empresa Basic";
        $license108->serial = "Suscripción 28 (1)";
        $license108->expiration_date = "2023-10-20";
        $license108->asset_id = 43;
        $license108->manufacturer_id = 15;
        $license108->obs = "Asignado";
        $license108->save();

        $license109 = new License();
        $license109->des = "Microsoft 365 Empresa Basic";
        $license109->serial = "Suscripción 29 (1)";
        $license109->expiration_date = "2023-10-20";
        $license109->asset_id = 46;
        $license109->manufacturer_id = 15;
        $license109->obs = "Asignado";
        $license109->save();

        $license110 = new License();
        $license110->des = "Microsoft 365 Empresa Basic";
        $license110->serial = "Suscripción 30 (1)";
        $license110->expiration_date = "2023-10-20";
        $license110->asset_id = 49;
        $license110->manufacturer_id = 15;
        $license110->obs = "Asignado";
        $license110->save();

        $license111 = new License();
        $license111->des = "Windows Server 2016 Standard";
        $license111->serial = "OEM";
        $license111->expiration_date = NULL;
        $license111->asset_id = 1;
        $license111->manufacturer_id = 15;
        $license111->obs = "Asignado";
        $license111->save();

        $license112 = new License();
        $license112->des = "Windows Server 2016 Standard";
        $license112->serial = "OEM";
        $license112->expiration_date = NULL;
        $license112->asset_id = 2;
        $license112->manufacturer_id = 15;
        $license112->obs = "Asignado";
        $license112->save();

        $license113 = new License();
        $license113->des = "Windows 10 Pro";
        $license113->serial = "OEM";
        $license113->expiration_date = NULL;
        $license113->asset_id = 3;
        $license113->manufacturer_id = 15;
        $license113->obs = "Asignado";
        $license113->save();

        $license114 = new License();
        $license114->des = "Windows 11 Pro";
        $license114->serial = "OEM";
        $license114->expiration_date = NULL;
        $license114->asset_id = 4;
        $license114->manufacturer_id = 15;
        $license114->obs = "Asignado";
        $license114->save();

        $license115 = new License();
        $license115->des = "Windows 11 Pro";
        $license115->serial = "OEM";
        $license115->expiration_date = NULL;
        $license115->asset_id = 5;
        $license115->manufacturer_id = 15;
        $license115->obs = "Asignado";
        $license115->save();

        $license116 = new License();
        $license116->des = "Windows 10 Pro";
        $license116->serial = "OEM";
        $license116->expiration_date = NULL;
        $license116->asset_id = 6;
        $license116->manufacturer_id = 15;
        $license116->obs = "Asignado";
        $license116->save();

        $license117 = new License();
        $license117->des = "Windows 10 Pro";
        $license117->serial = "OEM";
        $license117->expiration_date = NULL;
        $license117->asset_id = 7;
        $license117->manufacturer_id = 15;
        $license117->obs = "Asignado";
        $license117->save();

        $license118 = new License();
        $license118->des = "Windows 11 Pro";
        $license118->serial = "OEM";
        $license118->expiration_date = NULL;
        $license118->asset_id = 8;
        $license118->manufacturer_id = 15;
        $license118->obs = "Asignado";
        $license118->save();

        $license119 = new License();
        $license119->des = "Windows 11 Pro";
        $license119->serial = "OEM";
        $license119->expiration_date = NULL;
        $license119->asset_id = 9;
        $license119->manufacturer_id = 15;
        $license119->obs = "Asignado";
        $license119->save();

        $license120 = new License();
        $license120->des = "Windows 10 Pro";
        $license120->serial = "OEM";
        $license120->expiration_date = NULL;
        $license120->asset_id = 10;
        $license120->manufacturer_id = 15;
        $license120->obs = "Asignado";
        $license120->save();

        $license121 = new License();
        $license121->des = "Windows 10 Pro";
        $license121->serial = "OEM";
        $license121->expiration_date = NULL;
        $license121->asset_id = 11;
        $license121->manufacturer_id = 15;
        $license121->obs = "Asignado";
        $license121->save();

        $license122 = new License();
        $license122->des = "Windows 11 Pro";
        $license122->serial = "OEM";
        $license122->expiration_date = NULL;
        $license122->asset_id = 12;
        $license122->manufacturer_id = 15;
        $license122->obs = "Asignado";
        $license122->save();

        $license123 = new License();
        $license123->des = "Windows 10 Pro";
        $license123->serial = "OEM";
        $license123->expiration_date = NULL;
        $license123->asset_id = 13;
        $license123->manufacturer_id = 15;
        $license123->obs = "Asignado";
        $license123->save();

        $license124 = new License();
        $license124->des = "Windows 10 Home";
        $license124->serial = "OEM";
        $license124->expiration_date = NULL;
        $license124->asset_id = 14;
        $license124->manufacturer_id = 15;
        $license124->obs = "Asignado";
        $license124->save();

        $license125 = new License();
        $license125->des = "Windows 10 Pro";
        $license125->serial = "OEM";
        $license125->expiration_date = NULL;
        $license125->asset_id = 15;
        $license125->manufacturer_id = 15;
        $license125->obs = "Asignado";
        $license125->save();

        $license126 = new License();
        $license126->des = "Windows 10 Pro";
        $license126->serial = "OEM";
        $license126->expiration_date = NULL;
        $license126->asset_id = 16;
        $license126->manufacturer_id = 15;
        $license126->obs = "Asignado";
        $license126->save();

        $license127 = new License();
        $license127->des = "Windows 10 Pro";
        $license127->serial = "OEM";
        $license127->expiration_date = NULL;
        $license127->asset_id = 17;
        $license127->manufacturer_id = 15;
        $license127->obs = "Asignado";
        $license127->save();

        $license128 = new License();
        $license128->des = "Windows 10 Pro";
        $license128->serial = "OEM";
        $license128->expiration_date = NULL;
        $license128->asset_id = 18;
        $license128->manufacturer_id = 15;
        $license128->obs = "Asignado";
        $license128->save();

        $license129 = new License();
        $license129->des = "Windows Server 2016 Standard";
        $license129->serial = "OEM";
        $license129->expiration_date = NULL;
        $license129->asset_id = 19;
        $license129->manufacturer_id = 15;
        $license129->obs = "Asignado";
        $license129->save();
        
        $license130 = new License();
        $license130->des = "Windows Server 2016 Standard";
        $license130->serial = "OEM";
        $license130->expiration_date = NULL;
        $license130->asset_id = 20;
        $license130->manufacturer_id = 15;
        $license130->obs = "Asignado";
        $license130->save();

        $license131 = new License();
        $license131->des = "Windows 11 Home";
        $license131->serial = "OEM";
        $license131->expiration_date = NULL;
        $license131->asset_id = 21;
        $license131->manufacturer_id = 15;
        $license131->obs = "Asignado";
        $license131->save();

        $license132 = new License();
        $license132->des = "Windows 11 Home";
        $license132->serial = "OEM";
        $license132->expiration_date = NULL;
        $license132->asset_id = 22;
        $license132->manufacturer_id = 15;
        $license132->obs = "Asignado";
        $license132->save();

        $license133 = new License();
        $license133->des = "Windows 10 Pro";
        $license133->serial = "OEM";
        $license133->expiration_date = NULL;
        $license133->asset_id = 23;
        $license133->manufacturer_id = 15;
        $license133->obs = "Asignado";
        $license133->save();

        $license134 = new License();
        $license134->des = "Windows 11 Home";
        $license134->serial = "OEM";
        $license134->expiration_date = NULL;
        $license134->asset_id = 24;
        $license134->manufacturer_id = 15;
        $license134->obs = "Asignado";
        $license134->save();


        $license135 = new License();
        $license135->des = "Windows 10 Pro";
        $license135->serial = "OEM";
        $license135->expiration_date = NULL;
        $license135->asset_id = 25;
        $license135->manufacturer_id = 15;
        $license135->obs = "Asignado";
        $license135->save();

        $license136 = new License();
        $license136->des = "Windows 10 Pro";
        $license136->serial = "OEM";
        $license136->expiration_date = NULL;
        $license136->asset_id = 26;
        $license136->manufacturer_id = 15;
        $license136->obs = "Asignado";
        $license136->save();

        $license137 = new License();
        $license137->des = "Windows 10 Pro";
        $license137->serial = "OEM";
        $license137->expiration_date = NULL;
        $license137->asset_id = 27;
        $license137->manufacturer_id = 15;
        $license137->obs = "Asignado";
        $license137->save();

        $license138 = new License();
        $license138->des = "Windows 10 Pro";
        $license138->serial = "OEM";
        $license138->expiration_date = NULL;
        $license138->asset_id = 28;
        $license138->manufacturer_id = 15;
        $license138->obs = "Asignado";
        $license138->save();

        $license139 = new License();
        $license139->des = "Windows 10 Pro";
        $license139->serial = "OEM";
        $license139->expiration_date = NULL;
        $license139->asset_id = 29;
        $license139->manufacturer_id = 15;
        $license139->obs = "Asignado";
        $license139->save();

        $license140 = new License();
        $license140->des = "Windows 10 Pro";
        $license140->serial = "OEM";
        $license140->expiration_date = NULL;
        $license140->asset_id = 30;
        $license140->manufacturer_id = 15;
        $license140->obs = "Asignado";
        $license140->save();

        $license141 = new License();
        $license141->des = "Windows 10 Pro";
        $license141->serial = "OEM";
        $license141->expiration_date = NULL;
        $license141->asset_id = 31;
        $license141->manufacturer_id = 15;
        $license141->obs = "Asignado";
        $license141->save();

        $license142 = new License();
        $license142->des = "Windows 10 Pro";
        $license142->serial = "OEM";
        $license142->expiration_date = NULL;
        $license142->asset_id = 32;
        $license142->manufacturer_id = 15;
        $license142->obs = "Asignado";
        $license142->save();

        $license143 = new License();
        $license143->des = "Windows 10 Pro";
        $license143->serial = "OEM";
        $license143->expiration_date = NULL;
        $license143->asset_id = 33;
        $license143->manufacturer_id = 15;
        $license143->obs = "Asignado";
        $license143->save();

        $license144 = new License();
        $license144->des = "Microsoft 365 Empresa Premium";
        $license144->serial = "Suscripción 9 (2)";
        $license144->expiration_date = "2023-10-20";
        $license144->asset_id = 35;
        $license144->manufacturer_id = 15;
        $license144->obs = "Asignado";
        $license144->save();

        $license145 = new License();
        $license145->des = "Windows 10 Pro";
        $license145->serial = "OEM";
        $license145->expiration_date = NULL;
        $license145->asset_id = 34;
        $license145->manufacturer_id = 15;
        $license145->obs = "Asignado";
        $license145->save();

        $license146 = new License();
        $license146->des = "Windows 10 Pro";
        $license146->serial = "OEM";
        $license146->expiration_date = NULL;
        $license146->asset_id = 35;
        $license146->manufacturer_id = 15;
        $license146->obs = "Asignado";
        $license146->save();

        $license147 = new License();
        $license147->des = "Windows 10 Pro";
        $license147->serial = "OEM";
        $license147->expiration_date = NULL;
        $license147->asset_id = 36;
        $license147->manufacturer_id = 15;
        $license147->obs = "Asignado";
        $license147->save();

        $license148 = new License();
        $license148->des = "Windows 10 Pro";
        $license148->serial = "OEM";
        $license148->expiration_date = NULL;
        $license148->asset_id = 37;
        $license148->manufacturer_id = 15;
        $license148->obs = "Asignado";
        $license148->save();

        $license149 = new License();
        $license149->des = "Windows 10 Pro";
        $license149->serial = "OEM";
        $license149->expiration_date = NULL;
        $license149->asset_id = 38;
        $license149->manufacturer_id = 15;
        $license149->obs = "Asignado";
        $license149->save();

        $license150 = new License();
        $license150->des = "Windows 10 Pro";
        $license150->serial = "OEM";
        $license150->expiration_date = NULL;
        $license150->asset_id = 39;
        $license150->manufacturer_id = 15;
        $license150->obs = "Asignado";
        $license150->save();

        $license151 = new License();
        $license151->des = "Windows 10 Pro";
        $license151->serial = "OEM";
        $license151->expiration_date = NULL;
        $license151->asset_id = 40;
        $license151->manufacturer_id = 15;
        $license151->obs = "Asignado";
        $license151->save();

        $license152 = new License();
        $license152->des = "Windows 10 Pro";
        $license152->serial = "OEM";
        $license152->expiration_date = NULL;
        $license152->asset_id = 41;
        $license152->manufacturer_id = 15;
        $license152->obs = "Asignado";
        $license152->save();

        $license153 = new License();
        $license153->des = "Windows 10 Pro";
        $license153->serial = "OEM";
        $license153->expiration_date = NULL;
        $license153->asset_id = 42;
        $license153->manufacturer_id = 15;
        $license153->obs = "Asignado";
        $license153->save();

        $license154 = new License();
        $license154->des = "Windows 10 Pro";
        $license154->serial = "OEM";
        $license154->expiration_date = NULL;
        $license154->asset_id = 43;
        $license154->manufacturer_id = 15;
        $license154->obs = "Asignado";
        $license154->save();

        $license155 = new License();
        $license155->des = "Chrome OS 113";
        $license155->serial = "OEM";
        $license155->expiration_date = NULL;
        $license155->asset_id = 44;
        $license155->manufacturer_id = 25;
        $license155->obs = "Asignado";
        $license155->save();

        $license156 = new License();
        $license156->des = "Windows 10 Pro";
        $license156->serial = "OEM";
        $license156->expiration_date = NULL;
        $license156->asset_id = 45;
        $license156->manufacturer_id = 15;
        $license156->obs = "Asignado";
        $license156->save();

        $license157 = new License();
        $license157->des = "Windows 11 Pro";
        $license157->serial = "OEM";
        $license157->expiration_date = NULL;
        $license157->asset_id = 46;
        $license157->manufacturer_id = 15;
        $license157->obs = "Asignado";
        $license157->save();

        $license158 = new License();
        $license158->des = "Windows 10 Pro";
        $license158->serial = "OEM";
        $license158->expiration_date = NULL;
        $license158->asset_id = 47;
        $license158->manufacturer_id = 15;
        $license158->obs = "Asignado";
        $license158->save();

        $license159 = new License();
        $license159->des = "Windows 10 Home";
        $license159->serial = "OEM";
        $license159->expiration_date = NULL;
        $license159->asset_id = 48;
        $license159->manufacturer_id = 15;
        $license159->obs = "Asignado";
        $license159->save();

        $license160 = new License();
        $license160->des = "Windows 10 Pro";
        $license160->serial = "OEM";
        $license160->expiration_date = NULL;
        $license160->asset_id = 49;
        $license160->manufacturer_id = 15;
        $license160->obs = "Asignado";
        $license160->save();
        
        $license161 = new License();
        $license161->des = "Windows 7 Ultimate";
        $license161->serial = "OEM";
        $license161->expiration_date = NULL;
        $license161->asset_id = 50;
        $license161->manufacturer_id = 15;
        $license161->obs = "Asignado";
        $license161->save();
        
        $license162 = new License();
        $license162->des = "Windows 7 Ultimate";
        $license162->serial = "OEM";
        $license162->expiration_date = NULL;
        $license162->asset_id = 51;
        $license162->manufacturer_id = 15;
        $license162->obs = "Asignado";
        $license162->save();
        
        $license163 = new License();
        $license163->des = "Windows 7 Ultimate";
        $license163->serial = "OEM";
        $license163->expiration_date = NULL;
        $license163->asset_id = 52;
        $license163->manufacturer_id = 15;
        $license163->obs = "Asignado";
        $license163->save();
        
        $license164 = new License();
        $license164->des = "Windows 7 Ultimate";
        $license164->serial = "OEM";
        $license164->expiration_date = NULL;
        $license164->asset_id = 53;
        $license164->manufacturer_id = 15;
        $license164->obs = "Asignado";
        $license164->save();
        
        $license165 = new License();
        $license165->des = "Windows 7 Ultimate";
        $license165->serial = "OEM";
        $license165->expiration_date = NULL;
        $license165->asset_id = 54;
        $license165->manufacturer_id = 15;
        $license165->obs = "Asignado";
        $license165->save();
        
        $license166 = new License();
        $license166->des = "Windows 7 Ultimate";
        $license166->serial = "OEM";
        $license166->expiration_date = NULL;
        $license166->asset_id = 55;
        $license166->manufacturer_id = 15;
        $license166->obs = "Asignado";
        $license166->save();
        
        $license167 = new License();
        $license167->des = "Windows 7 Ultimate";
        $license167->serial = "OEM";
        $license167->expiration_date = NULL;
        $license167->asset_id = 56;
        $license167->manufacturer_id = 15;
        $license167->obs = "Asignado";
        $license167->save();
        
        $license168 = new License();
        $license168->des = "Windows 7 Ultimate";
        $license168->serial = "OEM";
        $license168->expiration_date = NULL;
        $license168->asset_id = 57;
        $license168->manufacturer_id = 15;
        $license168->obs = "Asignado";
        $license168->save();
        
        $license169 = new License();
        $license169->des = "Windows 7 Ultimate";
        $license169->serial = "OEM";
        $license169->expiration_date = NULL;
        $license169->asset_id = 58;
        $license169->manufacturer_id = 15;
        $license169->obs = "Asignado";
        $license169->save();
        
        $license170 = new License();
        $license170->des = "Windows 7 Ultimate";
        $license170->serial = "OEM";
        $license170->expiration_date = NULL;
        $license170->asset_id = 59;
        $license170->manufacturer_id = 15;
        $license170->obs = "Asignado";
        $license170->save();

        $license171 = new License();
        $license171->des = "Windows 10 Pro";
        $license171->serial = "OEM";
        $license171->expiration_date = NULL;
        $license171->asset_id = 60;
        $license171->manufacturer_id = 15;
        $license171->obs = "Asignado";
        $license171->save();

        $license172 = new License();
        $license172->des = "Windows 10 Pro";
        $license172->serial = "OEM";
        $license172->expiration_date = NULL;
        $license172->asset_id = 61;
        $license172->manufacturer_id = 15;
        $license172->obs = "Asignado";
        $license172->save();

        $license173 = new License();
        $license173->des = "Windows 10 Pro";
        $license173->serial = "OEM";
        $license173->expiration_date = NULL;
        $license173->asset_id = 62;
        $license173->manufacturer_id = 15;
        $license173->obs = "Asignado";
        $license173->save();




    }
}
