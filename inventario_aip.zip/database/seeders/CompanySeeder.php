<?php

namespace Database\Seeders;

use App\Models\Company;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class CompanySeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run()
    {
        $company = new Company();
        $company->name = "Albergue Infantil Los Pinos AC";
        $company->short_name = "AIP";
        $company->business_name = "Albergue Infantil Los Pinos";
        $company->rfc = "AIP871204MG0";
        $company->tax_regime = "603 Personas Morales con Fines no Lucrativos";
        $company->street = "Calzada de los Fresnos";
        $company->ext_number = "47";
        $company->int_number = NULL;
        $company->col = "Ciudad Granja";
        $company->city = "Zapopan";
        $company->mun = "Zapopan";
        $company->state = "Jalisco";
        $company->country = "México";
        $company->zip_code = "45010";
        $company->obs = "Albergue Infantil Los Pinos AC";
        $company->save();
    }

}
