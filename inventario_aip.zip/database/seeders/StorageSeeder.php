<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use App\Models\Storage;


class StorageSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $storage01 = new Storage();
        $storage01->type = "SSD";
        $storage01->interface = "SATA";
        $storage01->capacity = "465 GB";
        $storage01->asset_id = 1;
        $storage01->manufacturer_id = 17;
        $storage01->obs = "Disco Local (C)";
        $storage01->save();

        $storage02 = new Storage();
        $storage02->type = "HDD";
        $storage02->interface = "SATA";
        $storage02->capacity = "3.63 TB";
        $storage02->asset_id = 1;
        $storage02->manufacturer_id = 17;
        $storage02->obs = "Data (D)";
        $storage02->save();

        $storage03 = new Storage();
        $storage03->type = "HDD";
        $storage03->interface = "SATA";
        $storage03->capacity = "3.63 TB";
        $storage03->asset_id = 1;
        $storage03->manufacturer_id = 17;
        $storage03->obs = "BackUp (E)";
        $storage03->save();

        $storage04 = new Storage();
        $storage04->type = "SSD";
        $storage04->interface = "SATA";
        $storage04->capacity = "930 GB";
        $storage04->asset_id = 2;
        $storage04->manufacturer_id = 17;
        $storage04->obs = "OS (C)";
        $storage04->save();

        $storage05 = new Storage();
        $storage05->type = "HDD";
        $storage05->interface = "SATA";
        $storage05->capacity = "3.63 TB";
        $storage05->asset_id = 2;
        $storage05->manufacturer_id = 17;
        $storage05->obs = "Data (D)";
        $storage05->save();

        $storage06 = new Storage();
        $storage06->type = "HDD";
        $storage06->interface = "SATA";
        $storage06->capacity = "7.27 TB";
        $storage06->asset_id = 2;
        $storage06->manufacturer_id = 17;
        $storage06->obs = "BackUp (E)";
        $storage06->save();

        $storage07 = new Storage();
        $storage07->type = "SSD";
        $storage07->interface = "M.2 NVMe";
        $storage07->capacity = "475 GB";
        $storage07->asset_id = 3;
        $storage07->manufacturer_id = 17;
        $storage07->obs = "Windows (C)";
        $storage07->save();

        $storage08 = new Storage();
        $storage08->type = "SSD";
        $storage08->interface = "M.2 NVMe";
        $storage08->capacity = "474 GB";
        $storage08->asset_id = 4;
        $storage08->manufacturer_id = 20;
        $storage08->obs = "Windows (C)";
        $storage08->save();

        $storage09 = new Storage();
        $storage09->type = "SSD";
        $storage09->interface = "M.2 NVMe";
        $storage09->capacity = "237 GB";
        $storage09->asset_id = 5;
        $storage09->manufacturer_id = 11;
        $storage09->obs = "Windows (C)";
        $storage09->save();

        $storage10 = new Storage();
        $storage10->type = "SSD";
        $storage10->interface = "SATA";
        $storage10->capacity = "446 GB";
        $storage10->asset_id = 6;
        $storage10->manufacturer_id = 14;
        $storage10->obs = "Windows (C)";
        $storage10->save();

        $storage11 = new Storage();
        $storage11->type = "SSD";
        $storage11->interface = "SATA";
        $storage11->capacity = "446 GB";
        $storage11->asset_id = 7;
        $storage11->manufacturer_id = 14;
        $storage11->obs = "Windows (C)";
        $storage11->save();

        $storage12 = new Storage();
        $storage12->type = "SSD";
        $storage12->interface = "M.2 NVMe";
        $storage12->capacity = "474 GB";
        $storage12->asset_id = 8;
        $storage12->manufacturer_id = 19;
        $storage12->obs = "Windows (C)";
        $storage12->save();

        $storage13 = new Storage();
        $storage13->type = "SSD";
        $storage13->interface = "M.2 NVMe";
        $storage13->capacity = "474 GB";
        $storage13->asset_id = 9;
        $storage13->manufacturer_id = 20;
        $storage13->obs = "Windows (C)";
        $storage13->save();

        $storage14 = new Storage();
        $storage14->type = "SSD";
        $storage14->interface = "SATA";
        $storage14->capacity = "446 GB";
        $storage14->asset_id = 10;
        $storage14->manufacturer_id = 14;
        $storage14->obs = "Windows (C)";
        $storage14->save();

        $storage15 = new Storage();
        $storage15->type = "SSD";
        $storage15->interface = "M.2 NVMe";
        $storage15->capacity = "475 GB";
        $storage15->asset_id = 11;
        $storage15->manufacturer_id = 17;
        $storage15->obs = "Windows (C)";
        $storage15->save();

        $storage16 = new Storage();
        $storage16->type = "SSD";
        $storage16->interface = "M.2 NVMe";
        $storage16->capacity = "475 GB";
        $storage16->asset_id = 12;
        $storage16->manufacturer_id = 17;
        $storage16->obs = "Windows (C)";
        $storage16->save();

        $storage17 = new Storage();
        $storage17->type = "SSD";
        $storage17->interface = "SATA";
        $storage17->capacity = "446 GB";
        $storage17->asset_id = 13;
        $storage17->manufacturer_id = 14;
        $storage17->obs = "Windows (C)";
        $storage17->save();

        $storage18 = new Storage();
        $storage18->type = "SSD";
        $storage18->interface = "M.2 NVMe";
        $storage18->capacity = "476 GB";
        $storage18->asset_id = 14;
        $storage18->manufacturer_id = 20;
        $storage18->obs = "Windows (C)";
        $storage18->save();

        $storage19 = new Storage();
        $storage19->type = "SSD";
        $storage19->interface = "SATA";
        $storage19->capacity = "222 GB";
        $storage19->asset_id = 15;
        $storage19->manufacturer_id = 14;
        $storage19->obs = "Windows (C)";
        $storage19->save();

        $storage20 = new Storage();
        $storage20->type = "SSD";
        $storage20->interface = "M.2 NVMe";
        $storage20->capacity = "475 GB";
        $storage20->asset_id = 16;
        $storage20->manufacturer_id = 17;
        $storage20->obs = "Windows (C)";
        $storage20->save();

        $storage21 = new Storage();
        $storage21->type = "SSD";
        $storage21->interface = "SATA";
        $storage21->capacity = "446 GB";
        $storage21->asset_id = 17;
        $storage21->manufacturer_id = 14;
        $storage21->obs = "Windows (C)";
        $storage21->save();

        $storage22 = new Storage();
        $storage22->type = "SSD";
        $storage22->interface = "SATA";
        $storage22->capacity = "446 GB";
        $storage22->asset_id = 18;
        $storage22->manufacturer_id = 14;
        $storage22->obs = "Windows (C)";
        $storage22->save();

        $storage23 = new Storage();
        $storage23->type = "SSD";
        $storage23->interface = "SATA";
        $storage23->capacity = "480 GB";
        $storage23->asset_id = 19;
        $storage23->manufacturer_id = 14;
        $storage23->obs = "";
        $storage23->save();

        $storage24 = new Storage();
        $storage24->type = "SSD";
        $storage24->interface = "SATA";
        $storage24->capacity = "480 GB";
        $storage24->asset_id = 19;
        $storage24->manufacturer_id = 14;
        $storage24->obs = "";
        $storage24->save();

        $storage25 = new Storage();
        $storage25->type = "HDD";
        $storage25->interface = "SATA";
        $storage25->capacity = "1000 GB";
        $storage25->asset_id = 19;
        $storage25->manufacturer_id = 27;
        $storage25->obs = "";
        $storage25->save();

        
        $storage99 = new Storage();
        $storage99->type = "HDD";
        $storage99->interface = "SATA";
        $storage99->capacity = "465 GB";
        $storage99->asset_id = 62;
        $storage99->manufacturer_id = 27;
        $storage99->obs = "Windows (C)";
        $storage99->save();

    }
}
