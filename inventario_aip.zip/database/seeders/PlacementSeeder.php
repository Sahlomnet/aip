<?php

namespace Database\Seeders;

use App\Models\Placement;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class PlacementSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $placement01 = new Placement();
        $placement01->name = "Almacén de Sistemas";
        $placement01->location_id = 2;
        $placement01->people_id = 23;
        $placement01->obs = "Almacén";
        $placement01->save();

        $placement02 = new Placement();
        $placement02->name = "Oficina de Dirección 01";
        $placement02->location_id = 1;
        $placement02->people_id = 1;
        $placement02->obs = "Oficina";
        $placement02->save();

        $placement03 = new Placement();
        $placement03->name = "Escritorio de Desarrollo Humano 01";
        $placement03->location_id = 1;
        $placement03->people_id = 2;
        $placement03->obs = "Escritorio";
        $placement03->save();

        $placement04 = new Placement();
        $placement04->name = "Escritorio de Comunicación 01";
        $placement04->location_id = 1;
        $placement04->people_id = 9;
        $placement04->obs = "Escritorio";
        $placement04->save();

        $placement05 = new Placement();
        $placement05->name = "Escritorio de Captación 04";
        $placement05->location_id = 1;
        $placement05->people_id = 8;
        $placement05->obs = "Escritorio";
        $placement05->save();

        $placement06 = new Placement();
        $placement06->name = "Escritorio de Captación 03";
        $placement06->location_id = 1;
        $placement06->people_id = 7;
        $placement06->obs = "Escritorio";
        $placement06->save();

        $placement07 = new Placement();
        $placement07->name = "Oficina de Procuración de Fondos 01";
        $placement07->location_id = 1;
        $placement07->people_id = 2;
        $placement07->obs = "Oficina";
        $placement07->save();

        $placement08 = new Placement();
        $placement08->name = "Site de Procuración";
        $placement08->location_id = 1;
        $placement08->people_id = 2;
        $placement08->obs = "Site";
        $placement08->save();

        $placement09 = new Placement();
        $placement09->name = "Sala de Juntas Oficinas";
        $placement09->location_id = 1;
        $placement09->people_id = 2;
        $placement09->obs = "Sala";
        $placement09->save();

        $placement10 = new Placement();
        $placement10->name = "Escritorio de Captación 02";
        $placement10->location_id = 1;
        $placement10->people_id = 6;
        $placement10->obs = "Escritorio";
        $placement10->save();

        $placement11 = new Placement();
        $placement11->name = "Escritorio de Captación 01";
        $placement11->location_id = 1;
        $placement11->people_id = 5;
        $placement11->obs = "Escritorio";
        $placement11->save();

        $placement12 = new Placement();
        $placement12->name = "Escritorio de Proyectos 01";
        $placement12->location_id = 1;
        $placement12->people_id = 10;
        $placement12->obs = "Escritorio";
        $placement12->save();

        $placement13 = new Placement();
        $placement13->name = "Escritorio de Seguimiento 01";
        $placement13->location_id = 1;
        $placement13->people_id = 11;
        $placement13->obs = "Escritorio";
        $placement13->save();

        $placement14 = new Placement();
        $placement14->name = "Escritorio de Contabilidad 03";
        $placement14->location_id = 1;
        $placement14->people_id = 17;
        $placement14->obs = "Escritorio";
        $placement14->save();

        $placement15 = new Placement();
        $placement15->name = "Site de Contabilidad";
        $placement15->location_id = 1;
        $placement15->people_id = 2;
        $placement15->obs = "Site";
        $placement15->save();

        $placement16 = new Placement();
        $placement16->name = "Escritorio de Recolección 02";
        $placement16->location_id = 1;
        $placement16->people_id = 4;
        $placement16->obs = "Escritorio";
        $placement16->save();

        $placement17 = new Placement();
        $placement17->name = "Escritorio de Recolección 01";
        $placement17->location_id = 1;
        $placement17->people_id = 3;
        $placement17->obs = "Escritorio";
        $placement17->save();

        $placement18 = new Placement();
        $placement18->name = "Escritorio de Contabilidad 01";
        $placement18->location_id = 1;
        $placement18->people_id = 15;
        $placement18->obs = "Escritorio";
        $placement18->save();

        $placement19 = new Placement();
        $placement19->name = "Escritorio de Contabilidad 02";
        $placement19->location_id = 1;
        $placement19->people_id = 16;
        $placement19->obs = "Escritorio";
        $placement19->save();

        $placement20 = new Placement();
        $placement20->name = "Oficina de Calidad 01";
        $placement20->location_id = 2;
        $placement20->people_id = 19;
        $placement20->obs = "Oficina";
        $placement20->save();

        $placement21 = new Placement();
        $placement21->name = "Oficina de Nutrición 02";
        $placement21->location_id = 2;
        $placement21->people_id = 20;
        $placement21->obs = "Oficina";
        $placement21->save();

        $placement22 = new Placement();
        $placement22->name = "Oficina de Soporte 02";
        $placement22->location_id = 2;
        $placement22->people_id = 23;
        $placement22->obs = "Oficina";
        $placement22->save();

        $placement23 = new Placement();
        $placement23->name = "Site de Casa de Niños";
        $placement23->location_id = 2;
        $placement23->people_id = 23;
        $placement23->obs = "Site";
        $placement23->save();

        $placement24 = new Placement();
        $placement24->name = "Oficina de Dirección Educativa 01";
        $placement24->location_id = 2;
        $placement24->people_id = 24;
        $placement24->obs = "Oficina";
        $placement24->save();

        $placement25 = new Placement();
        $placement25->name = "Escritorio de Seguimiento 02";
        $placement25->location_id = 2;
        $placement25->people_id = 19;
        $placement25->obs = "Oficina";
        $placement25->save();

        $placement26 = new Placement();
        $placement26->name = "Escritorio de Seguimiento 03";
        $placement26->location_id = 2;
        $placement26->people_id = 19;
        $placement26->obs = "Oficina";
        $placement26->save();

        $placement27 = new Placement();
        $placement27->name = "Escritorio de Recepción 02";
        $placement27->location_id = 2;
        $placement27->people_id = 25;
        $placement27->obs = "Escritorio";
        $placement27->save();

        $placement28 = new Placement();
        $placement28->name = "Consultorio de Medicina 02";
        $placement28->location_id = 2;
        $placement28->people_id = 35;
        $placement28->obs = "Oficina";
        $placement28->save();

        $placement29 = new Placement();
        $placement29->name = "Aula de Educación Especial 02";
        $placement29->location_id = 2;
        $placement29->people_id = 26;
        $placement29->obs = "Oficina";
        $placement29->save();

        $placement30 = new Placement();
        $placement30->name = "Escritorio de Formación Infantil 02";
        $placement30->location_id = 2;
        $placement30->people_id = 36;
        $placement30->obs = "Escritorio";
        $placement30->save();

        $placement31 = new Placement();
        $placement31->name = "Escritorio de Formación Infantil 03";
        $placement31->location_id = 2;
        $placement31->people_id = 36;
        $placement31->obs = "Escritorio";
        $placement31->save();

        $placement32 = new Placement();
        $placement32->name = "Oficina de Formación Infantil 01";
        $placement32->location_id = 2;
        $placement32->people_id = 36;
        $placement32->obs = "Oficina";
        $placement32->save();

        $placement33 = new Placement();
        $placement33->name = "Oficina de Dirección Educativa Jóvenes";
        $placement33->location_id = 3;
        $placement33->people_id = 24;
        $placement33->obs = "Oficina";
        $placement33->save();

        $placement34 = new Placement();
        $placement34->name = "Oficina de Desarrollo Humano 01";
        $placement34->location_id = 3;
        $placement34->people_id = 18;
        $placement34->obs = "Oficina";
        $placement34->save();

        $placement35 = new Placement();
        $placement35->name = "Oficina de Dirección General Jóvenes";
        $placement35->location_id = 3;
        $placement35->people_id = 1;
        $placement35->obs = "Oficina";
        $placement35->save();

        $placement36 = new Placement();
        $placement36->name = "Escritorio de Trabajo Social 03";
        $placement36->location_id = 3;
        $placement36->people_id = 27;
        $placement36->obs = "Escritorio";
        $placement36->save();

        $placement37 = new Placement();
        $placement37->name = "Escritorio de Trabajo Social 02";
        $placement37->location_id = 3;
        $placement37->people_id = 32;
        $placement37->obs = "Escritorio";
        $placement37->save();

        $placement38 = new Placement();
        $placement38->name = "Escritorio de Formación Familiar 02";
        $placement38->location_id = 3;
        $placement38->people_id = 28;
        $placement38->obs = "Escritorio";
        $placement38->save();

        $placement39 = new Placement();
        $placement39->name = "Escritorio de Formación Familiar 03";
        $placement39->location_id = 3;
        $placement39->people_id = 29;
        $placement39->obs = "Escritorio";
        $placement39->save();

        $placement40 = new Placement();
        $placement40->name = "Escritorio de Formación Familiar 04";
        $placement40->location_id = 3;
        $placement40->people_id = 30;
        $placement40->obs = "Escritorio";
        $placement40->save();

        $placement41 = new Placement();
        $placement41->name = "Escritorio de Formación Familiar 05";
        $placement41->location_id = 3;
        $placement41->people_id = 31;
        $placement41->obs = "Escritorio";
        $placement41->save();

        $placement42 = new Placement();
        $placement42->name = "Oficina de Formación Familiar 01";
        $placement42->location_id = 3;
        $placement42->people_id = 27;
        $placement42->obs = "Oficina";
        $placement42->save();

        $placement43 = new Placement();
        $placement43->name = "Oficina de Formación Juvenil 02";
        $placement43->location_id = 3;
        $placement43->people_id = 37;
        $placement43->obs = "Oficina";
        $placement43->save();

        $placement44 = new Placement();
        $placement44->name = "Oficina de Formación Juvenil 01";
        $placement44->location_id = 3;
        $placement44->people_id = 37;
        $placement44->obs = "Oficina";
        $placement44->save();

        $placement45 = new Placement();
        $placement45->name = "Oficina de Formación Juvenil 03";
        $placement45->location_id = 3;
        $placement45->people_id = 38;
        $placement45->obs = "Oficina";
        $placement45->save();

        $placement46 = new Placement();
        $placement46->name = "Laboratorio de Cómputo";
        $placement46->location_id = 3;
        $placement46->people_id = 37;
        $placement46->obs = "Oficina";
        $placement46->save();

        $placement47 = new Placement();
        $placement47->name = "Almacén General";
        $placement47->location_id = 4;
        $placement47->people_id = 21;
        $placement47->obs = "Almacén";
        $placement47->save();


    }
}