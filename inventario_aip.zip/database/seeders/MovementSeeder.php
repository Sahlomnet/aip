<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use App\Models\Movement;

class MovementSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $movement01 = new Movement();
        $movement01->des = "Asignación Servidor Procuración de Fondos";
        $movement01->movement_date = "2023-01-16";
        $movement01->placement_id = 8;
        $movement01->asset_id = 1;
        $movement01->obs = "";
        $movement01->save();

        $movement02 = new Movement();
        $movement02->des = "Asignación Servidor Contabilidad";
        $movement02->movement_date = "2023-01-16";
        $movement02->placement_id = 15;
        $movement02->asset_id = 2;
        $movement02->obs = "";
        $movement02->save();

        $movement03 = new Movement();
        $movement03->des = "Asignación Computadora de Escritorio Dirección 01";
        $movement03->movement_date = "2023-01-16";
        $movement03->placement_id = 2;
        $movement03->asset_id = 3;
        $movement03->obs = "";
        $movement03->save();

        $movement04 = new Movement();
        $movement04->des = "Asignación Laptop Dirección 01";
        $movement04->movement_date = "2023-01-16";
        $movement04->placement_id = 2;
        $movement04->asset_id = 4;
        $movement04->obs = "";
        $movement04->save();

        $movement05 = new Movement();
        $movement05->des = "Asignación Computadora de Escritorio Desarrollo Humano 01";
        $movement05->movement_date = "2023-01-16";
        $movement05->placement_id = 3;
        $movement05->asset_id = 5;
        $movement05->obs = "";
        $movement05->save();

        $movement06 = new Movement();
        $movement06->des = "Asignación Computadora de Escritorio Captación 04";
        $movement06->movement_date = "2023-01-16";
        $movement06->placement_id = 5;
        $movement06->asset_id = 6;
        $movement06->obs = "";
        $movement06->save();

        $movement07 = new Movement();
        $movement07->des = "Asignación Computadora de Escritorio Captación 03";
        $movement07->movement_date = "2023-01-16";
        $movement07->placement_id = 6;
        $movement07->asset_id = 7;
        $movement07->obs = "";
        $movement07->save();

        $movement08 = new Movement();
        $movement08->des = "Asignación Computadora de Escritorio Procuración 01";
        $movement08->movement_date = "2023-01-16";
        $movement08->placement_id = 7;
        $movement08->asset_id = 8;
        $movement08->obs = "";
        $movement08->save();

        $movement09 = new Movement();
        $movement09->des = "Asignación Laptop Procuración 01";
        $movement09->movement_date = "2023-01-16";
        $movement09->placement_id = 7;
        $movement09->asset_id = 9;
        $movement09->obs = "";
        $movement09->save();

        $movement10 = new Movement();
        $movement10->des = "Asignación Computadora de Escritorio Captación 02";
        $movement10->movement_date = "2023-01-16";
        $movement10->placement_id = 10;
        $movement10->asset_id = 10;
        $movement10->obs = "";
        $movement10->save();

        $movement11 = new Movement();
        $movement11->des = "Asignación Computadora de Escritorio Captación 01";
        $movement11->movement_date = "2023-01-16";
        $movement11->placement_id = 11;
        $movement11->asset_id = 11;
        $movement11->obs = "";
        $movement11->save();

        $movement12 = new Movement();
        $movement12->des = "Asignación Computadora de Escritorio Proyectos 01";
        $movement12->movement_date = "2023-01-16";
        $movement12->placement_id = 12;
        $movement12->asset_id = 12;
        $movement12->obs = "";
        $movement12->save();

        $movement13 = new Movement();
        $movement13->des = "Asignación Computadora de Escritorio Seguimiento 01";
        $movement13->movement_date = "2023-01-16";
        $movement13->placement_id = 13;
        $movement13->asset_id = 13;
        $movement13->obs = "";
        $movement13->save();

        $movement14 = new Movement();
        $movement14->des = "Asignación Laptop Seguimiento 01";
        $movement14->movement_date = "2023-01-16";
        $movement14->placement_id = 13;
        $movement14->asset_id = 14;
        $movement14->obs = "";
        $movement14->save();

        $movement15 = new Movement();
        $movement15->des = "Asignación Computadora de Escritorio Contabilidad 03";
        $movement15->movement_date = "2023-01-16";
        $movement15->placement_id = 14;
        $movement15->asset_id = 15;
        $movement15->obs = "";
        $movement15->save();

        $movement16 = new Movement();
        $movement16->des = "Asignación Computadora de Escritorio Recolección 01";
        $movement16->movement_date = "2023-01-16";
        $movement16->placement_id = 17;
        $movement16->asset_id = 16;
        $movement16->obs = "";
        $movement16->save();

        $movement17 = new Movement();
        $movement17->des = "Asignación Computadora de Escritorio Contabilidad 02";
        $movement17->movement_date = "2023-01-16";
        $movement17->placement_id = 19;
        $movement17->asset_id = 17;
        $movement17->obs = "";
        $movement17->save();

        $movement18 = new Movement();
        $movement18->des = "Asignación Laptop Contabilidad 02";
        $movement18->movement_date = "2023-01-16";
        $movement18->placement_id = 19;
        $movement18->asset_id = 18;
        $movement18->obs = "";
        $movement18->save();

        $movement19 = new Movement();
        $movement19->des = "Asignación Servidor HP ProLiant Proliant ML 310e Gen8";
        $movement19->movement_date = "2023-01-16";
        $movement19->placement_id = 23;
        $movement19->asset_id = 19;
        $movement19->obs = "";
        $movement19->save();

        $movement20 = new Movement();
        $movement20->des = "Asignación Servidor HP Proliant ML110 G6";
        $movement20->movement_date = "2023-01-16";
        $movement20->placement_id = 23;
        $movement20->asset_id = 20;
        $movement20->obs = "";
        $movement20->save();

        $movement21 = new Movement();
        $movement21->des = "Asignación Laptop HP 6H9F1LA";
        $movement21->movement_date = "2023-01-16";
        $movement21->placement_id = 20;
        $movement21->asset_id = 21;
        $movement21->obs = "";
        $movement21->save();

        $movement22 = new Movement();
        $movement22->des = "Asignación Laptop Lenovo 82H8";
        $movement22->movement_date = "2023-01-16";
        $movement22->placement_id = 21;
        $movement22->asset_id = 22;
        $movement22->obs = "";
        $movement22->save();

        $movement23 = new Movement();
        $movement23->des = "Asignación Laptop Lenovo 20H5A04DLM";
        $movement23->movement_date = "2023-01-16";
        $movement23->placement_id = 22;
        $movement23->asset_id = 23;
        $movement23->obs = "";
        $movement23->save();

        $movement24 = new Movement();
        $movement24->des = "Asignación Laptop HP 6H9F1LA";
        $movement24->movement_date = "2023-01-16";
        $movement24->placement_id = 24;
        $movement24->asset_id = 24;
        $movement24->obs = "";
        $movement24->save();

        $movement25 = new Movement();
        $movement25->des = "Asignación Computadora de Escritorio Lenovo 33951N5";
        $movement25->movement_date = "2023-01-16";
        $movement25->placement_id = 25;
        $movement25->asset_id = 25;
        $movement25->obs = "";
        $movement25->save();

        $movement26 = new Movement();
        $movement26->des = "Asignación Computadora All In One Lenovo 7597C4S";
        $movement26->movement_date = "2023-01-16";
        $movement26->placement_id = 26;
        $movement26->asset_id = 26;
        $movement26->obs = "";
        $movement26->save();

        $movement27 = new Movement();
        $movement27->des = "Asignación Computadora de Escritorio Lenovo 10GSA0A1LS";
        $movement27->movement_date = "2023-01-16";
        $movement27->placement_id = 27;
        $movement27->asset_id = 27;
        $movement27->obs = "";
        $movement27->save();

        $movement28 = new Movement();
        $movement28->des = "Asignación Computadora de Escritorio Lenovo 10B4A0GJLS";
        $movement28->movement_date = "2023-01-16";
        $movement28->placement_id = 28;
        $movement28->asset_id = 28;
        $movement28->obs = "";
        $movement28->save();

        $movement29 = new Movement();
        $movement29->des = "Asignación Computadora de Escritorio Lenovo 33951N5";
        $movement29->movement_date = "2023-01-16";
        $movement29->placement_id = 29;
        $movement29->asset_id = 29;
        $movement29->obs = "";
        $movement29->save();

        $movement30 = new Movement();
        $movement30->des = "Asignación Computadora All In One Lenovo 7597E7S";
        $movement30->movement_date = "2023-01-16";
        $movement30->placement_id = 30;
        $movement30->asset_id = 30;
        $movement30->obs = "";
        $movement30->save();

        $movement31 = new Movement();
        $movement31->des = "Asignación Computadora All In One Lenovo 10BC000ELS";
        $movement31->movement_date = "2023-01-16";
        $movement31->placement_id = 31;
        $movement31->asset_id = 31;
        $movement31->obs = "";
        $movement31->save();

        $movement32 = new Movement();
        $movement32->des = "Asignación Computadora de Escritorio Lenovo 11AAS01W00";
        $movement32->movement_date = "2023-01-16";
        $movement32->placement_id = 32;
        $movement32->asset_id = 32;
        $movement32->obs = "";
        $movement32->save();

        $movement33 = new Movement();
        $movement33->des = "Asignación Laptop Lenovo ThinkPad L440";
        $movement33->movement_date = "2023-01-16";
        $movement33->placement_id = 32;
        $movement33->asset_id = 33;
        $movement33->obs = "";
        $movement33->save();

        $movement34 = new Movement();
        $movement34->des = "Asignación Computadora de Escritorio Lenovo 10ST008MLS";
        $movement34->movement_date = "2023-01-16";
        $movement34->placement_id = 34;
        $movement34->asset_id = 34;
        $movement34->obs = "";
        $movement34->save();

        $movement35 = new Movement();
        $movement35->des = "Asignación Laptop Lenovo 20FVA09500";
        $movement35->movement_date = "2023-01-16";
        $movement35->placement_id = 34;
        $movement35->asset_id = 35;
        $movement35->obs = "";
        $movement35->save();

        $movement36 = new Movement();
        $movement36->des = "Asignación Computadora de Escritorio Lenovo 10AH006BLS";
        $movement36->movement_date = "2023-01-16";
        $movement36->placement_id = 36;
        $movement36->asset_id = 36;
        $movement36->obs = "";
        $movement36->save();

        $movement37 = new Movement();
        $movement37->des = "Asignación Computadora de Escritorio Lenovo 10B4A14ALS";
        $movement37->movement_date = "2023-01-16";
        $movement37->placement_id = 37;
        $movement37->asset_id = 37;
        $movement37->obs = "";
        $movement37->save();

        $movement38 = new Movement();
        $movement38->des = "Asignación Computadora All In One Lenovo 7597E7S";
        $movement38->movement_date = "2023-01-16";
        $movement38->placement_id = 38;
        $movement38->asset_id = 38;
        $movement38->obs = "";
        $movement38->save();

        $movement39 = new Movement();
        $movement39->des = "Asignación Computadora All In One Lenovo 7597E7S";
        $movement39->movement_date = "2023-01-16";
        $movement39->placement_id = 39;
        $movement39->asset_id = 39;
        $movement39->obs = "";
        $movement39->save();

        $movement40 = new Movement();
        $movement40->des = "Asignación Computadora All In One Lenovo 7597E7S";
        $movement40->movement_date = "2023-01-16";
        $movement40->placement_id = 40;
        $movement40->asset_id = 40;
        $movement40->obs = "";
        $movement40->save();

        $movement41 = new Movement();
        $movement41->des = "Asignación Computadora All In One Lenovo 7597C4S";
        $movement41->movement_date = "2023-01-16";
        $movement41->placement_id = 41;
        $movement41->asset_id = 41;
        $movement41->obs = "";
        $movement41->save();

        $movement42 = new Movement();
        $movement42->des = "Asignación Computadora de Escritorio Lenovo 11AAS01W00";
        $movement42->movement_date = "2023-01-16";
        $movement42->placement_id = 42;
        $movement42->asset_id = 42;
        $movement42->obs = "";
        $movement42->save();

        $movement43 = new Movement();
        $movement43->des = "Asignación Laptop Lenovo 80F6";
        $movement43->movement_date = "2023-01-16";
        $movement43->placement_id = 42;
        $movement43->asset_id = 43;
        $movement43->obs = "";
        $movement43->save();

        $movement44 = new Movement();
        $movement44->des = "Asignación Laptop Lenovo ChromeBook";
        $movement44->movement_date = "2023-01-16";
        $movement44->placement_id = 42;
        $movement44->asset_id = 44;
        $movement44->obs = "";
        $movement44->save();

        $movement45 = new Movement();
        $movement45->des = "Asignación Computadora de Escritorio Lenovo 7518B4S";
        $movement45->movement_date = "2023-01-16";
        $movement45->placement_id = 43;
        $movement45->asset_id = 45;
        $movement45->obs = "";
        $movement45->save();

        $movement46 = new Movement();
        $movement46->des = "Asignación Computadora de Escritorio Lenovo 11AAS01W00";
        $movement46->movement_date = "2023-01-16";
        $movement46->placement_id = 44;
        $movement46->asset_id = 46;
        $movement46->obs = "";
        $movement46->save();

        $movement47 = new Movement();
        $movement47->des = "Asignación Laptop Samsung 300E4C";
        $movement47->movement_date = "2023-01-16";
        $movement47->placement_id = 44;
        $movement47->asset_id = 47;
        $movement47->obs = "";
        $movement47->save();

        $movement48 = new Movement();
        $movement48->des = "Asignación Laptop Lenovo 20156";
        $movement48->movement_date = "2023-01-16";
        $movement48->placement_id = 44;
        $movement48->asset_id = 48;
        $movement48->obs = "";
        $movement48->save();

        $movement49 = new Movement();
        $movement49->des = "Asignación Laptop Lenovo 20FVA09500";
        $movement49->movement_date = "2023-01-16";
        $movement49->placement_id = 44;
        $movement49->asset_id = 49;
        $movement49->obs = "";
        $movement49->save();

        $movement50 = new Movement();
        $movement50->des = "Asignación Computadora All In One HP 23-G204la";
        $movement50->movement_date = "2023-01-16";
        $movement50->placement_id = 46;
        $movement50->asset_id = 50;
        $movement50->obs = "";
        $movement50->save();

        $movement51 = new Movement();
        $movement51->des = "Asignación Computadora All In One HP 23-G204la";
        $movement51->movement_date = "2023-01-16";
        $movement51->placement_id = 46;
        $movement51->asset_id = 51;
        $movement51->obs = "";
        $movement51->save();

        $movement52 = new Movement();
        $movement52->des = "Asignación Computadora All In One HP 23-G204la";
        $movement52->movement_date = "2023-01-16";
        $movement52->placement_id = 46;
        $movement52->asset_id = 52;
        $movement52->obs = "";
        $movement52->save();

        $movement53 = new Movement();
        $movement53->des = "Asignación Computadora All In One HP 23-G204la";
        $movement53->movement_date = "2023-01-16";
        $movement53->placement_id = 46;
        $movement53->asset_id = 53;
        $movement53->obs = "";
        $movement53->save();

        $movement54 = new Movement();
        $movement54->des = "Asignación Computadora All In One HP 23-G204la";
        $movement54->movement_date = "2023-01-16";
        $movement54->placement_id = 46;
        $movement54->asset_id = 54;
        $movement54->obs = "";
        $movement54->save();

        $movement55 = new Movement();
        $movement55->des = "Asignación Computadora All In One HP 23-G204la";
        $movement55->movement_date = "2023-01-16";
        $movement55->placement_id = 46;
        $movement55->asset_id = 55;
        $movement55->obs = "";
        $movement55->save();

        $movement56 = new Movement();
        $movement56->des = "Asignación Computadora All In One HP 23-G204la";
        $movement56->movement_date = "2023-01-16";
        $movement56->placement_id = 46;
        $movement56->asset_id = 56;
        $movement56->obs = "";
        $movement56->save();

        $movement57 = new Movement();
        $movement57->des = "Asignación Computadora All In One HP 23-G204la";
        $movement57->movement_date = "2023-01-16";
        $movement57->placement_id = 46;
        $movement57->asset_id = 57;
        $movement57->obs = "";
        $movement57->save();

        $movement58 = new Movement();
        $movement58->des = "Asignación Computadora All In One HP 23-G204la";
        $movement58->movement_date = "2023-01-16";
        $movement58->placement_id = 46;
        $movement58->asset_id = 58;
        $movement58->obs = "";
        $movement58->save();

        $movement59 = new Movement();
        $movement59->des = "Asignación Computadora All In One HP 23-G204la";
        $movement59->movement_date = "2023-01-16";
        $movement59->placement_id = 46;
        $movement59->asset_id = 59;
        $movement59->obs = "";
        $movement59->save();

        $movement60 = new Movement();
        $movement60->des = "Asignación Laptop Lenovo 20FVA3VALM";
        $movement60->movement_date = "2023-01-16";
        $movement60->placement_id = 44;
        $movement60->asset_id = 60;
        $movement60->obs = "";
        $movement60->save();

        $movement61 = new Movement();
        $movement61->des = "Asignación Laptop Lenovo 20FVA09500";
        $movement61->movement_date = "2023-01-16";
        $movement61->placement_id = 44;
        $movement61->asset_id = 61;
        $movement61->obs = "";
        $movement61->save();

        $movement62 = new Movement();
        $movement62->des = "Asignación Computadora de Escritorio Lenovo 33951N5";
        $movement62->movement_date = "2023-01-16";
        $movement62->placement_id = 47;
        $movement62->asset_id = 62;
        $movement62->obs = "";
        $movement62->save();

        // $movement6 = new Movement();
        // $movement6->des = "Asignación ";
        // $movement6->movement_date = "2023-01-16";
        // $movement6->placement_id = PLACEMENT;
        // $movement6->asset_id = ASSET;
        // $movement6->obs = "";
        // $movement6->save();

    }
}
